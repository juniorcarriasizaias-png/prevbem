/**
 * Contato da equipe Prev Bem.
 * O número é definido em Configurações do Site (/admin/configuracoes) e carregado
 * em tempo real pelo SiteSettingsProvider. O valor abaixo é apenas o fallback.
 */
const FALLBACK_NUMBER = "5586999990000";

let currentNumber = FALLBACK_NUMBER;

/** Usado pelo SiteSettingsProvider quando as configurações chegam do banco. */
export function setWhatsAppNumber(value: string | null | undefined) {
  const digits = (value ?? "").replace(/\D/g, "");
  currentNumber = digits || FALLBACK_NUMBER;
}

export function getWhatsAppNumber() {
  return currentNumber;
}

export function formatWhatsApp(value: string = currentNumber) {
  const digits = value.replace(/\D/g, "");
  const local = digits.startsWith("55") ? digits.slice(2) : digits;
  if (local.length < 10) return value;
  const ddd = local.slice(0, 2);
  const rest = local.slice(2);
  return `(${ddd}) ${rest.slice(0, rest.length - 4)}-${rest.slice(-4)}`;
}

export const WHATSAPP_NUMBER = FALLBACK_NUMBER;

/** Compatibilidade: exibição textual do número atual. */
export const WHATSAPP_DISPLAY = formatWhatsApp(FALLBACK_NUMBER);

export const buildWhatsAppUrl = (message: string) =>
  `https://wa.me/${currentNumber}?text=${encodeURIComponent(message)}`;
