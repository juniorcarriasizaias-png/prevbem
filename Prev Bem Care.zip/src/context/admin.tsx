import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { ADMIN_IDENTITY, mockOrders } from "@/data/admin-mock";
import { clinics as seedClinics, services as seedServices, type Clinic, type Service } from "@/data/mock";
import { useOrders, type Order, type OrderStatus } from "@/context/orders";

const STORAGE_KEY = "prevbem-admin-v1";

export type AdminService = Omit<Service, "offeringId" | "catalogItemId"> & {
  available: boolean;
};
export type AdminClinic = {
  id: string;
  name: string;
  address: string;
  neighborhood: string;
  city: string;
  specialties: string[];
};

type InternalNote = { text: string; author: string; at: string };
type OrderOverride = { status?: OrderStatus; internalNotes?: InternalNote[] };

type AdminPatient = {
  name: string;
  phone: string;
  orders: Order[];
  total: number;
  lastOrderAt: string;
};

type AdminState = {
  services: AdminService[];
  clinics: AdminClinic[];
  overrides: Record<string, OrderOverride>;
};

type AdminContextValue = {
  orders: Order[];
  patients: AdminPatient[];
  services: AdminService[];
  clinics: AdminClinic[];
  setOrderStatus: (id: string, status: OrderStatus) => void;
  addOrderNote: (id: string, text: string) => void;
  saveService: (service: AdminService) => void;
  deleteService: (id: string) => void;
  saveClinic: (clinic: AdminClinic) => void;
  deleteClinic: (id: string) => void;
};

const AdminContext = createContext<AdminContextValue | null>(null);

const seedClinicSpecialties = (clinicId: string) =>
  Array.from(new Set(seedServices.filter((s) => s.clinicId === clinicId).map((s) => s.specialty)));

const initialState = (): AdminState => ({
  services: seedServices.map((s) => ({ ...s, available: true })),
  clinics: seedClinics.map((c) => ({ ...c, specialties: seedClinicSpecialties(c.id) })),
  overrides: {},
});

export function AdminProvider({ children }: { children: React.ReactNode }) {
  const { orders: patientOrders, updateOrder } = useOrders();
  const [state, setState] = useState<AdminState>(initialState);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Partial<AdminState>;
        setState((prev) => ({ ...prev, ...parsed }));
      }
    } catch {
      /* ignore */
    }
  }, []);

  const persist = useCallback((updater: (prev: AdminState) => AdminState) => {
    setState((prev) => {
      const next = updater(prev);
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const orders = useMemo(() => {
    const merged = [...patientOrders, ...mockOrders].map((o) => {
      const ov = state.overrides[o.id];
      return ov ? { ...o, ...ov } : o;
    });
    return merged.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  }, [patientOrders, state.overrides]);

  const patients = useMemo<AdminPatient[]>(() => {
    const map = new Map<string, AdminPatient>();
    for (const o of orders) {
      const key = o.patientName.toLowerCase();
      const current =
        map.get(key) ?? { name: o.patientName, phone: o.phone, orders: [], total: 0, lastOrderAt: o.createdAt };
      current.orders.push(o);
      current.total += o.total;
      if (o.createdAt > current.lastOrderAt) current.lastOrderAt = o.createdAt;
      map.set(key, current);
    }
    return [...map.values()].sort((a, b) => (a.lastOrderAt < b.lastOrderAt ? 1 : -1));
  }, [orders]);

  const applyToOrder = useCallback(
    (id: string, patch: OrderOverride) => {
      const isMock = id.startsWith("mock-");
      if (!isMock) updateOrder(id, patch);
      persist((prev) => ({
        ...prev,
        overrides: { ...prev.overrides, [id]: { ...prev.overrides[id], ...patch } },
      }));
    },
    [persist, updateOrder],
  );

  const setOrderStatus = useCallback(
    (id: string, status: OrderStatus) => applyToOrder(id, { status }),
    [applyToOrder],
  );

  const addOrderNote = useCallback(
    (id: string, text: string) => {
      const existing = orders.find((o) => o.id === id)?.internalNotes ?? [];
      applyToOrder(id, {
        internalNotes: [
          ...existing,
          { text, author: ADMIN_IDENTITY.name, at: new Date().toISOString() },
        ],
      });
    },
    [applyToOrder, orders],
  );

  const saveService = useCallback(
    (service: AdminService) =>
      persist((prev) => ({
        ...prev,
        services: prev.services.some((s) => s.id === service.id)
          ? prev.services.map((s) => (s.id === service.id ? service : s))
          : [service, ...prev.services],
      })),
    [persist],
  );

  const deleteService = useCallback(
    (id: string) => persist((prev) => ({ ...prev, services: prev.services.filter((s) => s.id !== id) })),
    [persist],
  );

  const saveClinic = useCallback(
    (clinic: AdminClinic) =>
      persist((prev) => ({
        ...prev,
        clinics: prev.clinics.some((c) => c.id === clinic.id)
          ? prev.clinics.map((c) => (c.id === clinic.id ? clinic : c))
          : [clinic, ...prev.clinics],
      })),
    [persist],
  );

  const deleteClinic = useCallback(
    (id: string) => persist((prev) => ({ ...prev, clinics: prev.clinics.filter((c) => c.id !== id) })),
    [persist],
  );

  const value = useMemo<AdminContextValue>(
    () => ({
      orders,
      patients,
      services: state.services,
      clinics: state.clinics,
      setOrderStatus,
      addOrderNote,
      saveService,
      deleteService,
      saveClinic,
      deleteClinic,
    }),
    [
      orders,
      patients,
      state.services,
      state.clinics,
      setOrderStatus,
      addOrderNote,
      saveService,
      deleteService,
      saveClinic,
      deleteClinic,
    ],
  );

  return <AdminContext.Provider value={value}>{children}</AdminContext.Provider>;
}

export function useAdmin() {
  const ctx = useContext(AdminContext);
  if (!ctx) throw new Error("useAdmin deve ser usado dentro de AdminProvider");
  return ctx;
}
