import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import {
  catalogItems as seedCatalogItems,
  clinicas as seedClinicas,
  offerings as seedOfferings,
  categoriaLabels,
  type CatalogItem,
  type Categoria,
  type Clinica,
  type Offering,
} from "@/data/catalog";

const STORAGE_KEY = "prevbem-catalog-admin-v1";

export type AdminClinica = Clinica & { ativo: boolean };

/** Uma linha da planilha de serviços de uma clínica. */
export type OfferingRow = {
  /** id da Offering existente, ou id temporário para linhas novas */
  id: string;
  catalogItemId?: string | undefined;
  categoria: Categoria;
  nome: string;
  especialidade: string;
  precoDeTabela: string;
  preco: string;
  prazoResultado: string;
  ativo: boolean;
};

type CatalogAdminState = {
  clinicas: AdminClinica[];
  catalogItems: CatalogItem[];
  offerings: Offering[];
};

type CatalogAdminContextValue = CatalogAdminState & {
  clinicaById: (id: string) => AdminClinica | undefined;
  offeringsByClinica: (clinicaId: string) => Offering[];
  saveClinica: (clinica: AdminClinica) => void;
  deleteClinica: (id: string) => void;
  /** Persiste todas as linhas da planilha de uma clínica de uma vez. */
  saveClinicaOfferings: (
    clinicaId: string,
    rows: OfferingRow[],
  ) => { created: number; linked: number; updated: number; removed: number };
  exportFullCatalogCsv: () => string;
};

const CatalogAdminContext = createContext<CatalogAdminContextValue | null>(null);

/* ---------------------------------- utils --------------------------------- */

export const normalizeName = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

export const slugify = (value: string) =>
  normalizeName(value).replace(/\s+/g, "-") || `item-${Date.now()}`;

/** Similaridade simples por bigramas (Dice), 0 a 1. */
export function similarity(a: string, b: string) {
  const x = normalizeName(a);
  const y = normalizeName(b);
  if (!x || !y) return 0;
  if (x === y) return 1;
  const grams = (s: string) => {
    const list: string[] = [];
    for (let i = 0; i < s.length - 1; i += 1) list.push(s.slice(i, i + 2));
    return list;
  };
  const gx = grams(x);
  const gy = grams(y);
  if (!gx.length || !gy.length) return 0;
  const pool = [...gy];
  let hits = 0;
  for (const g of gx) {
    const idx = pool.indexOf(g);
    if (idx >= 0) {
      pool.splice(idx, 1);
      hits += 1;
    }
  }
  return (2 * hits) / (gx.length + gy.length);
}

/** Itens do catálogo parecidos com o nome digitado, na mesma categoria. */
export function findSimilarItems(
  items: CatalogItem[],
  nome: string,
  categoria: Categoria,
  limit = 5,
) {
  const q = normalizeName(nome);
  if (q.length < 3) return [];
  return items
    .filter((i) => i.categoria === categoria)
    .map((item) => {
      const n = normalizeName(item.nome);
      const score = Math.max(
        similarity(item.nome, nome),
        n.includes(q) || q.includes(n) ? 0.9 : 0,
      );
      return { item, score };
    })
    .filter((r) => r.score >= 0.55)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit);
}

const csvCell = (value: string | number | undefined) => {
  const text = value === undefined || value === null ? "" : String(value);
  return /[";\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

const initialState = (): CatalogAdminState => ({
  clinicas: seedClinicas.map((c) => ({ ...c, ativo: true })),
  catalogItems: seedCatalogItems.map((i) => ({ ...i })),
  offerings: seedOfferings.map((o) => ({ ...o })),
});

/* -------------------------------- provider -------------------------------- */

export function CatalogAdminProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<CatalogAdminState>(initialState);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (!stored) return;
      const parsed = JSON.parse(stored) as Partial<CatalogAdminState>;
      setState((prev) => ({ ...prev, ...parsed }));
    } catch {
      /* ignore */
    }
  }, []);

  const persist = useCallback(
    (updater: (prev: CatalogAdminState) => CatalogAdminState) => {
      setState((prev) => {
        const next = updater(prev);
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* ignore */
        }
        return next;
      });
    },
    [],
  );

  const clinicaById = useCallback(
    (id: string) => state.clinicas.find((c) => c.id === id),
    [state.clinicas],
  );

  const offeringsByClinica = useCallback(
    (clinicaId: string) => state.offerings.filter((o) => o.clinicaId === clinicaId),
    [state.offerings],
  );

  const saveClinica = useCallback(
    (clinica: AdminClinica) =>
      persist((prev) => ({
        ...prev,
        clinicas: prev.clinicas.some((c) => c.id === clinica.id)
          ? prev.clinicas.map((c) => (c.id === clinica.id ? clinica : c))
          : [...prev.clinicas, clinica],
      })),
    [persist],
  );

  const deleteClinica = useCallback(
    (id: string) =>
      persist((prev) => ({
        ...prev,
        clinicas: prev.clinicas.filter((c) => c.id !== id),
        offerings: prev.offerings.filter((o) => o.clinicaId !== id),
      })),
    [persist],
  );

  const saveClinicaOfferings = useCallback(
    (clinicaId: string, rows: OfferingRow[]) => {
      const report = { created: 0, linked: 0, updated: 0, removed: 0 };
      persist((prev) => {
        const items = [...prev.catalogItems];
        const nextOfferings: Offering[] = [];

        for (const row of rows) {
          const nome = row.nome.trim();
          const preco = Number(String(row.preco).replace(",", "."));
          if (!nome || !Number.isFinite(preco) || preco <= 0) continue;

          let itemId = row.catalogItemId;
          const linkedItem = itemId ? items.find((i) => i.id === itemId) : undefined;
          if (!linkedItem || linkedItem.categoria !== row.categoria) itemId = undefined;

          if (!itemId) {
            const match = findSimilarItems(items, nome, row.categoria, 1)[0];
            if (match && match.score >= 0.82) {
              itemId = match.item.id;
              report.linked += 1;
            }
          }

          if (!itemId) {
            const base = slugify(nome);
            let candidate = base;
            let suffix = 2;
            while (items.some((i) => i.id === candidate)) {
              candidate = `${base}-${suffix}`;
              suffix += 1;
            }
            itemId = candidate;
            items.push({
              id: candidate,
              nome,
              categoria: row.categoria,
              ...(row.especialidade.trim()
                ? { especialidade: row.especialidade.trim() }
                : {}),
              demanda: 50,
              ativo: true,
            });
            report.created += 1;
          } else if (row.especialidade.trim()) {
            const idx = items.findIndex((i) => i.id === itemId);
            const current = items[idx];
            if (current && !current.especialidade) {
              items[idx] = { ...current, especialidade: row.especialidade.trim() };
            }
          }

          const tabela = Number(String(row.precoDeTabela).replace(",", "."));
          const existing = prev.offerings.find((o) => o.id === row.id);
          if (existing) report.updated += 1;

          nextOfferings.push({
            id: existing?.id ?? `${itemId}--${clinicaId}--${Date.now()}${nextOfferings.length}`,
            catalogItemId: itemId,
            clinicaId,
            preco: Math.round(preco * 100) / 100,
            ...(Number.isFinite(tabela) && tabela > 0 ? { precoDeTabela: tabela } : {}),
            ...(row.prazoResultado.trim()
              ? { prazoResultado: row.prazoResultado.trim() }
              : {}),
            ...(existing?.avaliacao ? { avaliacao: existing.avaliacao } : {}),
            ...(existing?.avaliacoes ? { avaliacoes: existing.avaliacoes } : {}),
            ativo: row.ativo,
          });
        }

        const previousCount = prev.offerings.filter((o) => o.clinicaId === clinicaId).length;
        report.removed = Math.max(0, previousCount - report.updated);

        return {
          ...prev,
          catalogItems: items,
          offerings: [
            ...prev.offerings.filter((o) => o.clinicaId !== clinicaId),
            ...nextOfferings,
          ],
        };
      });
      return report;
    },
    [persist],
  );

  const exportFullCatalogCsv = useCallback(() => {
    const header = [
      "clinica_id",
      "clinica",
      "endereco",
      "telefone",
      "catalog_item_id",
      "servico",
      "categoria",
      "especialidade",
      "preco_tabela",
      "preco_prevbem",
      "prazo_resultado",
      "status",
    ];
    const lines = [header.join(";")];
    for (const offering of state.offerings) {
      const clinica = state.clinicas.find((c) => c.id === offering.clinicaId);
      const item = state.catalogItems.find((i) => i.id === offering.catalogItemId);
      lines.push(
        [
          offering.clinicaId,
          clinica?.nome ?? "",
          clinica?.endereco ?? "",
          clinica?.telefone ?? "",
          offering.catalogItemId,
          item?.nome ?? "",
          item ? categoriaLabels[item.categoria] : "",
          item?.especialidade ?? "",
          offering.precoDeTabela ?? "",
          offering.preco,
          offering.prazoResultado ?? "",
          offering.ativo ? "Ativo" : "Inativo",
        ]
          .map(csvCell)
          .join(";"),
      );
    }
    return lines.join("\n");
  }, [state.offerings, state.clinicas, state.catalogItems]);

  const value = useMemo<CatalogAdminContextValue>(
    () => ({
      ...state,
      clinicaById,
      offeringsByClinica,
      saveClinica,
      deleteClinica,
      saveClinicaOfferings,
      exportFullCatalogCsv,
    }),
    [
      state,
      clinicaById,
      offeringsByClinica,
      saveClinica,
      deleteClinica,
      saveClinicaOfferings,
      exportFullCatalogCsv,
    ],
  );

  return (
    <CatalogAdminContext.Provider value={value}>{children}</CatalogAdminContext.Provider>
  );
}

export function useCatalogAdmin() {
  const ctx = useContext(CatalogAdminContext);
  if (!ctx) throw new Error("useCatalogAdmin deve ser usado dentro de CatalogAdminProvider");
  return ctx;
}
