import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "prevbem-price-suggestions-v1";

export type SuggestionStatus = "Pendente" | "Aprovada" | "Recusada";

/**
 * Sugestão de preço enviada por uma clínica parceira.
 * Sempre vinculada a um serviço (serviceId) que pertence a uma clínica (clinicId).
 */
export type PriceSuggestion = {
  id: string;
  clinicId: string;
  serviceId: string;
  serviceName: string;
  currentPrice: number;
  suggestedPrice: number;
  suggestedListPrice: number;
  note?: string;
  status: SuggestionStatus;
  createdAt: string;
  reviewedAt?: string;
  reviewNote?: string;
};

type ContextValue = {
  suggestions: PriceSuggestion[];
  byClinic: (clinicId: string) => PriceSuggestion[];
  pending: PriceSuggestion[];
  createSuggestion: (
    data: Omit<PriceSuggestion, "id" | "status" | "createdAt">,
  ) => PriceSuggestion;
  reviewSuggestion: (id: string, status: Exclude<SuggestionStatus, "Pendente">, reviewNote?: string) => void;
};

const PriceSuggestionsContext = createContext<ContextValue | null>(null);

export function PriceSuggestionsProvider({ children }: { children: React.ReactNode }) {
  const [suggestions, setSuggestions] = useState<PriceSuggestion[]>([]);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as PriceSuggestion[];
        if (Array.isArray(parsed)) setSuggestions(parsed);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const persist = useCallback((next: PriceSuggestion[]) => {
    setSuggestions(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  }, []);

  const createSuggestion = useCallback<ContextValue["createSuggestion"]>(
    (data) => {
      const created: PriceSuggestion = {
        ...data,
        id: `sug-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        status: "Pendente",
        createdAt: new Date().toISOString(),
      };
      setSuggestions((prev) => {
        const next = [created, ...prev];
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* ignore */
        }
        return next;
      });
      return created;
    },
    [],
  );

  const reviewSuggestion = useCallback<ContextValue["reviewSuggestion"]>(
    (id, status, reviewNote) => {
      setSuggestions((prev) => {
        const next = prev.map((s) =>
          s.id === id
            ? { ...s, status, reviewedAt: new Date().toISOString(), ...(reviewNote ? { reviewNote } : {}) }
            : s,
        );
        try {
          window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
        } catch {
          /* ignore */
        }
        return next;
      });
    },
    [],
  );

  const value = useMemo<ContextValue>(
    () => ({
      suggestions,
      byClinic: (clinicId: string) => suggestions.filter((s) => s.clinicId === clinicId),
      pending: suggestions.filter((s) => s.status === "Pendente"),
      createSuggestion,
      reviewSuggestion,
    }),
    [suggestions, createSuggestion, reviewSuggestion],
  );

  // `persist` fica disponível para futuras operações em lote.
  void persist;

  return (
    <PriceSuggestionsContext.Provider value={value}>{children}</PriceSuggestionsContext.Provider>
  );
}

export function usePriceSuggestions() {
  const ctx = useContext(PriceSuggestionsContext);
  if (!ctx) throw new Error("usePriceSuggestions deve ser usado dentro de PriceSuggestionsProvider");
  return ctx;
}
