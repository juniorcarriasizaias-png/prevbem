import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

const STORAGE_KEY = "prevbem-orders";

export type OrderItem = {
  name: string;
  clinic: string;
  /** Modelo multi-clínica: cada item pertence sempre a uma clínica específica. */
  clinicId?: string;
  unitPrice: number;
  qty: number;
};

export type OrderStatus =
  | "Aguardando pagamento"
  | "Confirmado"
  | "Concluído"
  | "Cancelado";

export type Order = {
  id: string;
  number: string;
  patientName: string;
  phone: string;
  forWhom: "self" | "other";
  beneficiaryName?: string | undefined;
  notes?: string | undefined;
  items: OrderItem[];
  total: number;
  createdAt: string;
  status: OrderStatus;
  internalNotes?: { text: string; author: string; at: string }[];
};

type OrdersContextValue = {
  orders: Order[];
  createOrder: (data: Omit<Order, "id" | "number" | "createdAt" | "status">) => Order;
  updateOrder: (id: string, patch: Partial<Order>) => void;
};

const OrdersContext = createContext<OrdersContextValue | null>(null);

const nextNumber = (orders: Order[]) => {
  const highest = orders.reduce((max, o) => {
    const n = Number(o.number.replace(/\D/g, ""));
    return Number.isFinite(n) && n > max ? n : max;
  }, 122);
  return `PB-${String(highest + 1).padStart(6, "0")}`;
};

export function OrdersProvider({ children }: { children: React.ReactNode }) {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Order[];
        if (Array.isArray(parsed)) setOrders(parsed);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const createOrder = useCallback<OrdersContextValue["createOrder"]>(
    (data) => {
      const created: Order = {
        ...data,
        id: `order-${Date.now()}`,
        number: nextNumber(orders),
        createdAt: new Date().toISOString(),
        status: "Aguardando pagamento",
      };
      const next = [created, ...orders];
      setOrders(next);
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return created;
    },
    [orders],
  );

  const updateOrder = useCallback<OrdersContextValue["updateOrder"]>((id, patch) => {
    setOrders((prev) => {
      const next = prev.map((o) => (o.id === id ? { ...o, ...patch } : o));
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        /* ignore */
      }
      return next;
    });
  }, []);

  const value = useMemo(
    () => ({ orders, createOrder, updateOrder }),
    [orders, createOrder, updateOrder],
  );

  return <OrdersContext.Provider value={value}>{children}</OrdersContext.Provider>;
}

export function useOrders() {
  const ctx = useContext(OrdersContext);
  if (!ctx) throw new Error("useOrders deve ser usado dentro de OrdersProvider");
  return ctx;
}
