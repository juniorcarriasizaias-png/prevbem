import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { supabase } from "@/integrations/supabase/client";
import { formatWhatsApp, setWhatsAppNumber } from "@/config/contact";

export type SiteSettings = {
  id: string;
  cor_primaria: string;
  cor_destaque: string;
  logo_url: string | null;
  nome_site: string;
  whatsapp_numero: string;
  texto_rodape: string;
};

export const DEFAULT_SETTINGS: SiteSettings = {
  id: "",
  cor_primaria: "#5B3F8C",
  cor_destaque: "#E8650A",
  logo_url: null,
  nome_site: "Prev Bem",
  whatsapp_numero: "5586999990000",
  texto_rodape: "© 2026 Prev Bem. Todos os direitos reservados. CNPJ 00.000.000/0001-00",
};

type Ctx = {
  settings: SiteSettings;
  ready: boolean;
  refresh: () => Promise<void>;
  save: (patch: Partial<Omit<SiteSettings, "id">>) => Promise<{ error: string | null }>;
  whatsappDisplay: string;
};

const SiteSettingsContext = createContext<Ctx | null>(null);

const isHex = (v: string) => /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v.trim());

/** Aplica as cores escolhidas no admin como tokens CSS globais. */
export function applyThemeColors(primary: string, accent: string) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  if (isHex(primary)) {
    root.style.setProperty("--primary", primary);
    root.style.setProperty("--primary-dark", `color-mix(in oklab, ${primary} 78%, black)`);
    root.style.setProperty("--primary-light", `color-mix(in oklab, ${primary} 72%, white)`);
    root.style.setProperty("--primary-soft", `color-mix(in oklab, ${primary} 10%, white)`);
    root.style.setProperty("--sidebar-primary", primary);
    root.style.setProperty("--sidebar-accent-foreground", primary);
    root.style.setProperty("--ring", primary);
  }
  if (isHex(accent)) {
    root.style.setProperty("--accent", accent);
    root.style.setProperty("--accent-soft", `color-mix(in oklab, ${accent} 12%, white)`);
  }
}

export function SiteSettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);

  const apply = useCallback((next: SiteSettings) => {
    setSettings(next);
    setWhatsAppNumber(next.whatsapp_numero);
    applyThemeColors(next.cor_primaria, next.cor_destaque);
  }, []);

  const refresh = useCallback(async () => {
    const { data } = await supabase
      .from("site_settings")
      .select("id, cor_primaria, cor_destaque, logo_url, nome_site, whatsapp_numero, texto_rodape")
      .order("criado_em", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (data) apply(data as SiteSettings);
    setReady(true);
  }, [apply]);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const save = useCallback<Ctx["save"]>(
    async (patch) => {
      if (!settings.id) return { error: "Configuração não encontrada no banco." };
      const { data, error } = await supabase
        .from("site_settings")
        .update(patch)
        .eq("id", settings.id)
        .select(
          "id, cor_primaria, cor_destaque, logo_url, nome_site, whatsapp_numero, texto_rodape",
        )
        .maybeSingle();
      if (error) return { error: error.message };
      if (!data) return { error: "Sem permissão para alterar as configurações." };
      apply(data as SiteSettings);
      return { error: null };
    },
    [settings.id, apply],
  );

  const value = useMemo<Ctx>(
    () => ({
      settings,
      ready,
      refresh,
      save,
      whatsappDisplay: formatWhatsApp(settings.whatsapp_numero),
    }),
    [settings, ready, refresh, save],
  );

  return (
    <SiteSettingsContext.Provider value={value}>{children}</SiteSettingsContext.Provider>
  );
}

export function useSiteSettings() {
  const ctx = useContext(SiteSettingsContext);
  if (!ctx) throw new Error("useSiteSettings deve ser usado dentro de SiteSettingsProvider");
  return ctx;
}
