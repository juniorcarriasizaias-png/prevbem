import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import { services } from "@/data/mock";

const STORAGE_KEY = "prevbem-reviews";

export type Review = {
  id: string;
  /** Agendamento avaliado (histórico do paciente) */
  appointmentId: string;
  /** Serviço do catálogo, quando identificado pelo nome */
  serviceId?: string | undefined;
  serviceName: string;
  clinic: string;
  patientName: string;
  rating: number;
  comment: string;
  at: string;
};

export type RatingSummary = { rating: number; reviews: number; mine?: Review | undefined };

type ReviewsContextValue = {
  reviews: Review[];
  addReview: (data: Omit<Review, "id" | "at">) => Review;
  getByAppointment: (appointmentId: string) => Review | undefined;
  summaryFor: (serviceId: string) => RatingSummary;
};

const ReviewsContext = createContext<ReviewsContextValue | null>(null);

/** Resolve o serviço do catálogo a partir do nome usado no histórico. */
export const findServiceIdByName = (name: string) =>
  services.find((s) => s.name.toLowerCase() === name.toLowerCase())?.id;

export function ReviewsProvider({ children }: { children: React.ReactNode }) {
  const [reviews, setReviews] = useState<Review[]>([]);

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Review[];
        if (Array.isArray(parsed)) setReviews(parsed);
      }
    } catch {
      /* ignore */
    }
  }, []);

  const persist = useCallback((next: Review[]) => {
    setReviews(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
  }, []);

  const value = useMemo<ReviewsContextValue>(() => {
    const addReview: ReviewsContextValue["addReview"] = (data) => {
      const created: Review = {
        ...data,
        id: `rv-${Date.now()}`,
        at: new Date().toISOString(),
      };
      persist([created, ...reviews.filter((r) => r.appointmentId !== data.appointmentId)]);
      return created;
    };

    return {
      reviews,
      addReview,
      getByAppointment: (appointmentId) => reviews.find((r) => r.appointmentId === appointmentId),
      summaryFor: (serviceId) => {
        const base = services.find((s) => s.id === serviceId);
        const baseRating = base?.rating ?? 0;
        const baseCount = base?.reviews ?? 0;
        const mine = reviews.filter((r) => r.serviceId === serviceId);
        if (mine.length === 0) return { rating: baseRating, reviews: baseCount };
        const sum = baseRating * baseCount + mine.reduce((acc, r) => acc + r.rating, 0);
        const count = baseCount + mine.length;
        return { rating: sum / count, reviews: count, mine: mine[0] };
      },
    };
  }, [reviews, persist]);

  return <ReviewsContext.Provider value={value}>{children}</ReviewsContext.Provider>;
}

export function useReviews() {
  const ctx = useContext(ReviewsContext);
  if (!ctx) throw new Error("useReviews deve ser usado dentro de ReviewsProvider");
  return ctx;
}
