import type { Session, User } from "@supabase/supabase-js";
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";

import { supabase } from "@/integrations/supabase/client";

export type UserRole = "paciente" | "admin" | "parceiro";

export type PatientUser = {
  id: string;
  name: string;
  email?: string | undefined;
  phone?: string | undefined;
  memberId: string;
  role: UserRole;
  since: string;
};

type Profile = {
  id: string;
  nome_completo: string;
  telefone: string | null;
  role: string;
  criado_em: string;
};

type AuthContextValue = {
  user: PatientUser | null;
  session: Session | null;
  ready: boolean;
  isAdmin: boolean;
  signUp: (data: {
    nomeCompleto: string;
    telefone: string;
    email: string;
    password: string;
  }) => Promise<{ error: string | null; needsConfirmation: boolean }>;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  resetPassword: (email: string) => Promise<{ error: string | null }>;
  updatePassword: (password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

/** Identificação visível ao paciente, derivada de forma estável do id da conta. */
function memberIdFromUuid(id: string) {
  const digits = id.replace(/\D/g, "").padEnd(8, "0");
  return `0086 ${digits.slice(0, 4)} ${digits.slice(4, 8)}`;
}

function toPatientUser(authUser: User, profile: Profile | null): PatientUser {
  const meta = (authUser.user_metadata ?? {}) as Record<string, unknown>;
  const name =
    profile?.nome_completo ||
    (typeof meta["nome_completo"] === "string" ? (meta["nome_completo"] as string) : "") ||
    authUser.email ||
    "Paciente";
  const phone =
    profile?.telefone ??
    (typeof meta["telefone"] === "string" ? (meta["telefone"] as string) : undefined) ??
    undefined;
  const role = (profile?.role as UserRole | undefined) ?? "paciente";

  return {
    id: authUser.id,
    name,
    email: authUser.email ?? undefined,
    phone,
    memberId: memberIdFromUuid(authUser.id),
    role,
    since: profile?.criado_em ?? authUser.created_at,
  };
}

export function AuthProviderComponent({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<PatientUser | null>(null);
  const [ready, setReady] = useState(false);

  const loadProfile = useCallback(async (authUser: User) => {
    const { data } = await supabase
      .from("profiles")
      .select("id, nome_completo, telefone, role, criado_em")
      .eq("id", authUser.id)
      .maybeSingle();
    setUser(toPatientUser(authUser, (data as Profile | null) ?? null));
  }, []);

  useEffect(() => {
    let active = true;

    const { data: sub } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      if (!active) return;
      setSession(nextSession);
      if (nextSession?.user) {
        setUser(toPatientUser(nextSession.user, null));
        void loadProfile(nextSession.user);
      } else {
        setUser(null);
      }
    });

    void supabase.auth.getSession().then(({ data }) => {
      if (!active) return;
      setSession(data.session);
      if (data.session?.user) {
        setUser(toPatientUser(data.session.user, null));
        void loadProfile(data.session.user).finally(() => setReady(true));
      } else {
        setReady(true);
      }
    });

    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signUp = useCallback<AuthContextValue["signUp"]>(
    async ({ nomeCompleto, telefone, email, password }) => {
      const { data, error } = await supabase.auth.signUp({
        email: email.trim(),
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/minha-conta`,
          data: { nome_completo: nomeCompleto.trim(), telefone: telefone.trim() },
        },
      });
      if (error) return { error: error.message, needsConfirmation: false };
      return { error: null, needsConfirmation: data.session === null };
    },
    [],
  );

  const signIn = useCallback<AuthContextValue["signIn"]>(async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    return { error: error?.message ?? null };
  }, []);

  const resetPassword = useCallback<AuthContextValue["resetPassword"]>(async (email) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/redefinir-senha`,
    });
    return { error: error?.message ?? null };
  }, []);

  const updatePassword = useCallback<AuthContextValue["updatePassword"]>(async (password) => {
    const { error } = await supabase.auth.updateUser({ password });
    return { error: error?.message ?? null };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setUser(null);
    setSession(null);
  }, []);

  const value = useMemo(
    () => ({
      user,
      session,
      ready,
      isAdmin: user?.role === "admin",
      signUp,
      signIn,
      resetPassword,
      updatePassword,
      signOut,
    }),
    [user, session, ready, signUp, signIn, resetPassword, updatePassword, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth deve ser usado dentro de AuthProviderComponent");
  return ctx;
}
