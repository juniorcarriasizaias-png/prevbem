import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import { initialCart, services, type Service } from "@/data/mock";

const STORAGE_KEY = "prevbem-cart-v2";

export type CartLine = { service: Service; qty: number };

type Entry = { id: string; qty: number };

type CartContextValue = {
  ids: string[];
  lines: CartLine[];
  count: number;
  subtotal: number;
  savings: number;
  has: (id: string) => boolean;
  add: (id: string) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
};

const CartContext = createContext<CartContextValue | null>(null);

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [entries, setEntries] = useState<Entry[]>(() =>
    initialCart.map((id) => ({ id, qty: 1 })),
  );

  useEffect(() => {
    try {
      const stored = window.localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as Entry[];
        if (Array.isArray(parsed)) {
          setEntries(
            parsed
              .filter((e) => e && typeof e.id === "string")
              .map((e) => ({ id: e.id, qty: Math.max(1, Number(e.qty) || 1) })),
          );
        }
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    } catch {
      /* ignore */
    }
  }, [entries]);

  const add = useCallback((id: string) => {
    setEntries((prev) =>
      prev.some((e) => e.id === id) ? prev : [...prev, { id, qty: 1 }],
    );
  }, []);
  const remove = useCallback((id: string) => {
    setEntries((prev) => prev.filter((e) => e.id !== id));
  }, []);
  const setQty = useCallback((id: string, qty: number) => {
    setEntries((prev) =>
      qty <= 0
        ? prev.filter((e) => e.id !== id)
        : prev.map((e) => (e.id === id ? { ...e, qty: Math.min(qty, 10) } : e)),
    );
  }, []);
  const clear = useCallback(() => setEntries([]), []);

  const value = useMemo<CartContextValue>(() => {
    const lines: CartLine[] = entries
      .map((e) => {
        const service = services.find((s) => s.id === e.id);
        return service ? { service, qty: e.qty } : null;
      })
      .filter((l): l is CartLine => Boolean(l));
    return {
      ids: lines.map((l) => l.service.id),
      lines,
      count: lines.reduce((sum, l) => sum + l.qty, 0),
      subtotal: lines.reduce((sum, l) => sum + l.service.price * l.qty, 0),
      savings: lines.reduce(
        (sum, l) => sum + (l.service.listPrice - l.service.price) * l.qty,
        0,
      ),
      has: (id: string) => lines.some((l) => l.service.id === id),
      add,
      remove,
      setQty,
      clear,
    };
  }, [entries, add, remove, setQty, clear]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart deve ser usado dentro de CartProvider");
  return ctx;
}
