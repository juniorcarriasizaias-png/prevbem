import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";

import { mockOrders } from "@/data/admin-mock";
import { partnerAccounts, type PartnerAccount } from "@/data/partner-mock";
import { clinicById, services as seedServices, type Clinic, type Service } from "@/data/mock";
import { useOrders, type Order, type OrderItem, type OrderStatus } from "@/context/orders";
import { usePriceSuggestions, type PriceSuggestion } from "@/context/price-suggestions";

const SESSION_KEY = "prevbem-partner-session";

/** Pedido visto pela ótica de uma clínica: só os itens dela. */
export type PartnerOrder = {
  id: string;
  number: string;
  patientName: string;
  phone: string;
  status: OrderStatus;
  createdAt: string;
  items: OrderItem[];
  clinicTotal: number;
  orderTotal: number;
};

type PartnerContextValue = {
  account: PartnerAccount | null;
  clinic: Clinic | null;
  selectAccount: (email: string) => boolean;
  signOut: () => void;
  /** Serviços desta clínica (um serviço pertence sempre a uma clínica). */
  services: Service[];
  orders: PartnerOrder[];
  suggestions: PriceSuggestion[];
  suggestPrice: (
    service: Service,
    suggestedPrice: number,
    suggestedListPrice: number,
    note?: string,
  ) => void;
  pendingFor: (serviceId: string) => PriceSuggestion | undefined;
};

const PartnerContext = createContext<PartnerContextValue | null>(null);

const itemBelongs = (item: OrderItem, clinic: Clinic) =>
  item.clinicId ? item.clinicId === clinic.id : item.clinic === clinic.name;

export function PartnerProvider({ children }: { children: React.ReactNode }) {
  const { orders: patientOrders } = useOrders();
  const { suggestions, createSuggestion } = usePriceSuggestions();
  const [account, setAccount] = useState<PartnerAccount | null>(null);

  useEffect(() => {
    try {
      const email = window.localStorage.getItem(SESSION_KEY);
      if (email) setAccount(partnerAccounts.find((a) => a.email === email) ?? null);
    } catch {
      /* ignore */
    }
  }, []);

  const selectAccount = useCallback((email: string) => {
    const found = partnerAccounts.find((a) => a.email === email) ?? null;
    if (found) {
      setAccount(found);
      try {
        window.localStorage.setItem(SESSION_KEY, found.email);
      } catch {
        /* ignore */
      }
    }
    return Boolean(found);
  }, []);

  const signOut = useCallback(() => {
    setAccount(null);
    try {
      window.localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
  }, []);

  const clinic = account ? (clinicById[account.clinicId] ?? null) : null;

  const clinicSuggestions = useMemo(
    () => (clinic ? suggestions.filter((s) => s.clinicId === clinic.id) : []),
    [suggestions, clinic],
  );

  /** Aplica o preço já aprovado pelo admin, quando houver. */
  const clinicServices = useMemo<Service[]>(() => {
    if (!clinic) return [];
    const own = seedServices.filter((s) => s.clinicId === clinic.id);
    return own.map((s) => {
      const approved = clinicSuggestions
        .filter((sug) => sug.serviceId === s.id && sug.status === "Aprovada")
        .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))[0];
      return approved
        ? { ...s, price: approved.suggestedPrice, listPrice: approved.suggestedListPrice }
        : s;
    });
  }, [clinic, clinicSuggestions]);

  const orders = useMemo<PartnerOrder[]>(() => {
    if (!clinic) return [];
    const all: Order[] = [...patientOrders, ...mockOrders];
    return all
      .map((o) => {
        const items = o.items.filter((i) => itemBelongs(i, clinic));
        if (items.length === 0) return null;
        return {
          id: o.id,
          number: o.number,
          patientName: o.forWhom === "other" && o.beneficiaryName ? o.beneficiaryName : o.patientName,
          phone: o.phone,
          status: o.status,
          createdAt: o.createdAt,
          items,
          clinicTotal: items.reduce((sum, i) => sum + i.unitPrice * i.qty, 0),
          orderTotal: o.total,
        } satisfies PartnerOrder;
      })
      .filter((o): o is PartnerOrder => o !== null)
      .sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
  }, [patientOrders, clinic]);

  const suggestPrice = useCallback<PartnerContextValue["suggestPrice"]>(
    (service, suggestedPrice, suggestedListPrice, note) => {
      if (!clinic) return;
      createSuggestion({
        clinicId: clinic.id,
        serviceId: service.id,
        serviceName: service.name,
        currentPrice: service.price,
        suggestedPrice,
        suggestedListPrice,
        ...(note ? { note } : {}),
      });
    },
    [clinic, createSuggestion],
  );

  const value = useMemo<PartnerContextValue>(
    () => ({
      account,
      clinic,
      selectAccount,
      signOut,
      services: clinicServices,
      orders,
      suggestions: clinicSuggestions,
      suggestPrice,
      pendingFor: (serviceId: string) =>
        clinicSuggestions.find((s) => s.serviceId === serviceId && s.status === "Pendente"),
    }),
    [account, clinic, selectAccount, signOut, clinicServices, orders, clinicSuggestions, suggestPrice],
  );

  return <PartnerContext.Provider value={value}>{children}</PartnerContext.Provider>;
}

export function usePartner() {
  const ctx = useContext(PartnerContext);
  if (!ctx) throw new Error("usePartner deve ser usado dentro de PartnerProvider");
  return ctx;
}
