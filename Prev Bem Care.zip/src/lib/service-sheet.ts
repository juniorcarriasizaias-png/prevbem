import * as XLSX from "xlsx";

import type { OfferingRow } from "@/context/catalog-admin";
import { categoriaLabels, categoriaOrder, type Categoria } from "@/data/catalog";

export const SHEET_HEADERS = [
  "Categoria",
  "Nome do Serviço",
  "Especialidade",
  "Preço de Tabela",
  "Preço Prev Bem",
  "Prazo de Resultado",
] as const;

export const SHEET_EXAMPLES: string[][] = [
  ["Exame de laboratório", "Hemograma completo", "Hematologia", "80", "32", "até 24 horas"],
  ["Consulta", "Consulta com cardiologista", "Cardiologia", "350", "180", ""],
];

let rowSeq = 0;
export const newOfferingRow = (): OfferingRow => ({
  id: `nova-${Date.now()}-${(rowSeq += 1)}`,
  categoria: "exame_laboratorial",
  nome: "",
  especialidade: "",
  precoDeTabela: "",
  preco: "",
  prazoResultado: "",
  ativo: true,
});

export const isExameCategoria = (categoria: Categoria) =>
  categoria === "exame_laboratorial" || categoria === "exame_imagem";

const strip = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();

/** Retorna a categoria correspondente ou undefined quando não bate com nenhuma das 4. */
export function matchCategoria(value: string): Categoria | undefined {
  const v = strip(value);
  if (!v) return undefined;
  if (categoriaOrder.includes(v as Categoria)) return v as Categoria;
  if (v.includes("imagem") || v.includes("raio") || v.includes("ultrass")) return "exame_imagem";
  if (v.includes("cirurg") || v.includes("procedimento")) return "cirurgia";
  if (v.includes("consulta")) return "consulta";
  if (v.includes("labor") || v.includes("exame")) return "exame_laboratorial";
  return undefined;
}

export const parseCategoriaLoose = (value: string): Categoria =>
  matchCategoria(value) ?? "exame_laboratorial";

export const parsePrice = (value: string) => {
  const raw = String(value ?? "")
    .replace(/[^\d.,-]/g, "")
    .trim();
  if (!raw) return NaN;
  const normalized =
    raw.includes(",") && raw.lastIndexOf(",") > raw.lastIndexOf(".")
      ? raw.replace(/\./g, "").replace(",", ".")
      : raw.replace(/,/g, "");
  return Number(normalized);
};

export const formatPrice = (value: number) =>
  (Math.round(value * 100) / 100).toFixed(2).replace(".", ",");

/* ------------------------------- template -------------------------------- */

const download = (blob: Blob, filename: string) => {
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
};

export function downloadTemplate(format: "xlsx" | "csv") {
  const data = [[...SHEET_HEADERS], ...SHEET_EXAMPLES];
  if (format === "csv") {
    const csv = data.map((line) => line.join(";")).join("\n");
    download(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" }), "prevbem-modelo-servicos.csv");
    return;
  }
  const sheet = XLSX.utils.aoa_to_sheet(data);
  sheet["!cols"] = [{ wch: 22 }, { wch: 34 }, { wch: 20 }, { wch: 16 }, { wch: 16 }, { wch: 20 }];
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, "Serviços");
  const out = XLSX.write(book, { bookType: "xlsx", type: "array" }) as ArrayBuffer;
  download(
    new Blob([out], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }),
    "prevbem-modelo-servicos.xlsx",
  );
}

/* --------------------------------- parse --------------------------------- */

export type RawSheetRow = {
  id: string;
  categoria: string;
  nome: string;
  especialidade: string;
  precoDeTabela: string;
  preco: string;
  prazoResultado: string;
  selected: boolean;
};

const toRaw = (cells: string[], index: number): RawSheetRow => ({
  id: `imp-${Date.now()}-${index}`,
  categoria: cells[0] ?? "",
  nome: cells[1] ?? "",
  especialidade: cells[2] ?? "",
  precoDeTabela: cells[3] ?? "",
  preco: cells[4] ?? "",
  prazoResultado: cells[5] ?? "",
  selected: false,
});

const looksLikeHeader = (cells: string[]) => {
  const joined = strip(cells.join(" "));
  return joined.includes("categoria") && joined.includes("nome");
};

export function parseGridText(text: string): string[][] {
  return text
    .replace(/\r/g, "")
    .split("\n")
    .filter((line) => line.trim())
    .map((line) =>
      line.includes("\t")
        ? line.split("\t")
        : line.split(/[;,](?=(?:[^"]*"[^"]*")*[^"]*$)/),
    )
    .map((cells) => cells.map((c) => c.trim().replace(/^"|"$/g, "")));
}

function gridToRows(grid: string[][]): RawSheetRow[] {
  const body = grid.length && looksLikeHeader(grid[0]!) ? grid.slice(1) : grid;
  return body
    .filter((cells) => cells.some((c) => String(c).trim()))
    .map((cells, i) => toRaw(cells.map((c) => String(c ?? "").trim()), i));
}

export async function parseSpreadsheetFile(file: File): Promise<RawSheetRow[]> {
  const name = file.name.toLowerCase();
  if (name.endsWith(".csv") || name.endsWith(".txt") || name.endsWith(".tsv")) {
    return gridToRows(parseGridText(await file.text()));
  }
  const buffer = await file.arrayBuffer();
  const book = XLSX.read(buffer, { type: "array" });
  const first = book.SheetNames[0];
  if (!first) return [];
  const sheet = book.Sheets[first]!;
  const grid = XLSX.utils.sheet_to_json<string[]>(sheet, { header: 1, raw: false, defval: "" });
  return gridToRows(grid.map((row) => (row ?? []).map((c) => String(c ?? "").trim())));
}

export const parseSpreadsheetText = (text: string) => gridToRows(parseGridText(text));

/* ------------------------------- validation ------------------------------- */

export type RowValidation = { errors: string[]; categoria?: Categoria };

export function validateRow(row: RawSheetRow): RowValidation {
  const errors: string[] = [];
  const categoria = matchCategoria(row.categoria);
  if (!row.nome.trim()) errors.push("Nome do serviço vazio");
  if (!categoria)
    errors.push(
      `Categoria inválida (use: ${categoriaOrder.map((c) => categoriaLabels[c]).join(", ")})`,
    );
  const preco = parsePrice(row.preco);
  if (!row.preco.trim()) errors.push("Preço Prev Bem vazio");
  else if (!Number.isFinite(preco) || preco <= 0) errors.push("Preço Prev Bem não numérico");
  if (row.precoDeTabela.trim()) {
    const tabela = parsePrice(row.precoDeTabela);
    if (!Number.isFinite(tabela) || tabela <= 0) errors.push("Preço de tabela não numérico");
  }
  return categoria ? { errors, categoria } : { errors };
}

export function rawToOfferingRow(row: RawSheetRow): OfferingRow {
  return {
    ...newOfferingRow(),
    categoria: parseCategoriaLoose(row.categoria),
    nome: row.nome.trim(),
    especialidade: row.especialidade.trim(),
    precoDeTabela: row.precoDeTabela.trim(),
    preco: row.preco.trim(),
    prazoResultado: row.prazoResultado.trim(),
    ativo: true,
  };
}
