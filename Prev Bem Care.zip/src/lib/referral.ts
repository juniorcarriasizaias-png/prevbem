/** Código de indicação mockado, derivado do nome/identificação do paciente. */
export const buildReferralCode = (name?: string | null, memberId?: string | null) => {
  const base = (name ?? "prevbem")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-zA-Z]/g, "")
    .toUpperCase()
    .slice(0, 5) || "AMIGO";
  const digits = (memberId ?? "2026").replace(/\D/g, "").slice(-4) || "2026";
  return `${base}${digits}`;
};

export const REFERRAL_REWARD = 25;
export const REFERRAL_FRIEND_DISCOUNT = 15;

export const buildReferralLink = (code: string) =>
  `https://prevbem.com.br/servicos?indicacao=${code}`;
