import { createFileRoute, Link } from "@tanstack/react-router";
import { Search, Wallet, CalendarCheck, FileText, ShieldCheck } from "lucide-react";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/como-funciona")({
  head: () => ({
    meta: [
      { title: "Como funciona a Prev Bem — agendamento em 4 passos" },
      {
        name: "description",
        content:
          "Entenda como agendar consultas, exames e procedimentos particulares na Prev Bem: buscar, escolher, agendar e receber o resultado.",
      },
      { property: "og:title", content: "Como funciona a Prev Bem" },
      {
        property: "og:description",
        content: "Do primeiro clique ao resultado do exame em quatro passos simples.",
      },
    ],
  }),
  component: HowItWorks,
});

const steps = [
  {
    icon: Search,
    title: "Busque o que você precisa",
    desc: "Pesquise por especialidade, exame ou clínica. Use os filtros de preço, tipo de serviço e localização para encontrar a melhor opção.",
  },
  {
    icon: Wallet,
    title: "Compare preços com transparência",
    desc: "O valor exibido é o valor final para paciente particular. Sem mensalidade, sem carência e sem taxa escondida.",
  },
  {
    icon: CalendarCheck,
    title: "Escolha data e horário",
    desc: "Adicione os serviços ao carrinho, finalize o agendamento e receba a confirmação por WhatsApp e e-mail.",
  },
  {
    icon: FileText,
    title: "Atendimento e resultado digital",
    desc: "Compareça na clínica parceira com um documento com foto. Laudos e receitas ficam salvos na sua área do paciente.",
  },
];

const faqs = [
  {
    q: "Preciso ter plano de saúde?",
    a: "Não. A Prev Bem atende exclusivamente pacientes particulares, sem convênio e sem mensalidade.",
  },
  {
    q: "Quando eu pago?",
    a: "O pagamento é feito diretamente na clínica parceira no dia do atendimento, pelo valor exibido na plataforma.",
  },
  {
    q: "Posso reagendar?",
    a: "Sim, gratuitamente até 24 horas antes do horário marcado, pela área do paciente.",
  },
  {
    q: "Como recebo o resultado dos exames?",
    a: "Você é avisado por notificação e o arquivo digital fica disponível na sua área do paciente.",
  },
];

function HowItWorks() {
  return (
    <div>
      <section className="hero-gradient">
        <div className="mx-auto w-full max-w-4xl px-4 py-16 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl sm:text-5xl">
            Agendar saúde em <span className="text-primary">4 passos</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">
            Sem burocracia, sem ligações e sem incerteza sobre o preço.
          </p>
        </div>
      </section>

      <section className="mx-auto w-full max-w-5xl px-4 py-16 sm:px-6 lg:px-8">
        <ol className="space-y-5">
          {steps.map(({ icon: Icon, title, desc }, i) => (
            <li key={title} className="surface-card flex flex-col gap-5 p-7 sm:flex-row">
              <span className="brand-gradient flex size-14 shrink-0 items-center justify-center rounded-2xl text-primary-foreground">
                <Icon className="size-6" />
              </span>
              <div>
                <p className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
                  Passo {i + 1}
                </p>
                <h2 className="mt-1 text-xl">{title}</h2>
                <p className="mt-2 leading-relaxed text-muted-foreground">{desc}</p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto w-full max-w-5xl px-4 pb-16 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl">Dúvidas frequentes</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {faqs.map((f) => (
            <div key={f.q} className="surface-card p-6">
              <h3 className="inline-flex items-start gap-2 text-base font-extrabold">
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-primary" /> {f.q}
              </h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.a}</p>
            </div>
          ))}
        </div>
        <div className="mt-8 flex flex-wrap gap-3">
          <Button variant="cta" size="lg" asChild>
            <Link to="/servicos">Buscar consultas e exames</Link>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link to="/contato">Falar com a equipe</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
