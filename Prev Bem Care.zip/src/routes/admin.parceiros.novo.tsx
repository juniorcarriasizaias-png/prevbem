import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, ArrowRight, Check, Plus, Upload, X } from "lucide-react";
import { toast } from "sonner";

import {
  slugify,
  useCatalogAdmin,
  type AdminClinica,
  type OfferingRow,
} from "@/context/catalog-admin";
import { categoriaLabels } from "@/data/catalog";
import { newOfferingRow, parsePrice } from "@/lib/service-sheet";
import { ImportSheetDialog } from "@/components/admin/import-sheet-dialog";
import { OfferingSheetTable } from "@/components/admin/offering-sheet-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/admin/parceiros/novo")({
  component: NovaClinicaWizard,
});

const steps = [
  { n: 1, label: "Dados da clínica" },
  { n: 2, label: "Serviços" },
  { n: 3, label: "Revisão final" },
];

const emptyClinica = (): AdminClinica => ({
  id: "",
  nome: "",
  endereco: "",
  telefone: "",
  especialidadesAtendidas: [],
  address: "",
  neighborhood: "",
  city: "Teresina, PI",
  ativo: true,
});

const brl = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

function NovaClinicaWizard() {
  const navigate = useNavigate();
  const { catalogItems, saveClinica, saveClinicaOfferings } = useCatalogAdmin();

  const [step, setStep] = useState(1);
  const [clinica, setClinica] = useState<AdminClinica>(emptyClinica);
  const [tagInput, setTagInput] = useState("");
  const [rows, setRowsState] = useState<OfferingRow[]>([]);
  const [manualOpen, setManualOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);

  const setRows = (updater: (prev: OfferingRow[]) => OfferingRow[]) => setRowsState(updater);

  const addTag = (value: string) => {
    const tag = value.trim();
    if (!tag) return;
    setClinica((prev) =>
      prev.especialidadesAtendidas.includes(tag)
        ? prev
        : { ...prev, especialidadesAtendidas: [...prev.especialidadesAtendidas, tag] },
    );
    setTagInput("");
  };

  const validRows = rows.filter((r) => {
    const preco = parsePrice(r.preco);
    return r.nome.trim() && Number.isFinite(preco) && preco > 0;
  });

  const publish = () => {
    if (validRows.length === 0) {
      toast.error("Adicione ao menos um serviço válido antes de publicar.");
      return;
    }
    const id = slugify(clinica.nome);
    saveClinica({
      ...clinica,
      id,
      address: clinica.address || clinica.endereco,
      ativo: true,
    });
    const report = saveClinicaOfferings(id, validRows);
    toast.success(
      `Clínica publicada com ${validRows.length} serviços · ${report.created} novo(s) item(ns) no catálogo, ${report.linked} vinculado(s).`,
    );
    navigate({ to: "/admin/parceiros/$clinicaId", params: { clinicaId: id } });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <Link
          to="/admin/parceiros"
          className="inline-flex items-center gap-1.5 text-[12px] font-bold text-primary hover:underline"
        >
          <ArrowLeft className="size-3.5" /> Parceiros e catálogo
        </Link>
      </div>

      {/* Stepper */}
      <ol className="flex flex-wrap items-center gap-2 rounded-xl border border-border bg-card p-3">
        {steps.map((s, index) => (
          <li key={s.n} className="flex items-center gap-2">
            <span
              className={`grid size-6 place-items-center rounded-full text-[11px] font-extrabold ${
                step > s.n
                  ? "bg-success/15 text-success"
                  : step === s.n
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
              }`}
            >
              {step > s.n ? <Check className="size-3.5" /> : s.n}
            </span>
            <span
              className={`text-[12px] font-bold ${
                step === s.n ? "text-primary" : "text-muted-foreground"
              }`}
            >
              {s.label}
            </span>
            {index < steps.length - 1 && (
              <span className="mx-1 h-px w-6 bg-border sm:w-10" aria-hidden />
            )}
          </li>
        ))}
      </ol>

      {/* Etapa 1 */}
      {step === 1 && (
        <form
          className="space-y-4 rounded-xl border border-border bg-card p-4"
          onSubmit={(e) => {
            e.preventDefault();
            if (!clinica.nome.trim()) return;
            setStep(2);
          }}
        >
          <h1 className="text-sm font-extrabold">Dados da clínica</h1>
          <div className="grid gap-3 md:grid-cols-2">
            <div className="space-y-1.5">
              <Label className="text-[12px]">Nome da clínica</Label>
              <Input
                className="h-9 text-[13px] font-bold"
                value={clinica.nome}
                onChange={(e) => setClinica({ ...clinica, nome: e.target.value })}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px]">Telefone</Label>
              <Input
                className="h-9 text-[13px]"
                value={clinica.telefone ?? ""}
                onChange={(e) => setClinica({ ...clinica, telefone: e.target.value })}
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px]">Endereço completo</Label>
              <Input
                className="h-9 text-[13px]"
                value={clinica.endereco}
                onChange={(e) =>
                  setClinica({ ...clinica, endereco: e.target.value, address: e.target.value })
                }
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-[12px]">Bairro</Label>
              <Input
                className="h-9 text-[13px]"
                value={clinica.neighborhood}
                onChange={(e) => setClinica({ ...clinica, neighborhood: e.target.value })}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label className="text-[12px]">Especialidades atendidas</Label>
            <div className="flex flex-wrap items-center gap-1.5 rounded-lg border border-input bg-background p-2">
              {clinica.especialidadesAtendidas.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center gap-1 rounded-full bg-primary-soft px-2 py-0.5 text-[11.5px] font-bold text-primary"
                >
                  {tag}
                  <button
                    type="button"
                    aria-label={`Remover ${tag}`}
                    onClick={() =>
                      setClinica({
                        ...clinica,
                        especialidadesAtendidas: clinica.especialidadesAtendidas.filter(
                          (t) => t !== tag,
                        ),
                      })
                    }
                  >
                    <X className="size-3" />
                  </button>
                </span>
              ))}
              <input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === ",") {
                    e.preventDefault();
                    addTag(tagInput);
                  }
                }}
                onBlur={() => addTag(tagInput)}
                placeholder="Digite e pressione Enter"
                className="h-7 min-w-[180px] flex-1 bg-transparent px-1 text-[12.5px] outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button type="submit" variant="cta" size="sm" className="h-9 gap-1.5 text-[12px]">
              Avançar <ArrowRight className="size-3.5" />
            </Button>
          </div>
        </form>
      )}

      {/* Etapa 2 */}
      {step === 2 && (
        <div className="space-y-4">
          <div className="grid gap-3 md:grid-cols-2">
            <section className="flex flex-col justify-between gap-3 rounded-xl border border-border bg-card p-4">
              <div>
                <h2 className="text-[13px] font-extrabold">Adicionar manualmente</h2>
                <p className="mt-1 text-[12px] font-semibold text-muted-foreground">
                  Abra a tabela editável estilo planilha e digite linha por linha, com sugestão
                  automática de itens do catálogo.
                </p>
              </div>
              <Button
                variant="soft"
                size="sm"
                className="h-9 gap-1.5 self-start text-[12px]"
                onClick={() => {
                  setManualOpen(true);
                  if (rows.length === 0) setRows((prev) => [...prev, newOfferingRow()]);
                }}
              >
                <Plus className="size-3.5" /> Abrir tabela editável
              </Button>
            </section>
            <section className="flex flex-col justify-between gap-3 rounded-xl border border-border bg-card p-4">
              <div>
                <h2 className="text-[13px] font-extrabold">Importar de uma planilha Excel/CSV</h2>
                <p className="mt-1 text-[12px] font-semibold text-muted-foreground">
                  Baixe o modelo com as colunas corretas, preencha e importe. Você revisa tudo numa
                  prévia com validação antes de confirmar.
                </p>
              </div>
              <Button
                variant="cta"
                size="sm"
                className="h-9 gap-1.5 self-start text-[12px]"
                onClick={() => setImportOpen(true)}
              >
                <Upload className="size-3.5" /> Importar planilha
              </Button>
            </section>
          </div>

          {(manualOpen || rows.length > 0) && (
            <OfferingSheetTable rows={rows} setRows={setRows} catalogItems={catalogItems} />
          )}

          <div className="flex items-center justify-between gap-3">
            <Button variant="outline" size="sm" className="h-9 text-[12px]" onClick={() => setStep(1)}>
              Voltar
            </Button>
            <div className="flex items-center gap-3">
              <span className="text-[12px] font-semibold text-muted-foreground">
                {validRows.length} serviço(s) válido(s)
              </span>
              <Button
                variant="cta"
                size="sm"
                className="h-9 gap-1.5 text-[12px]"
                disabled={validRows.length === 0}
                onClick={() => setStep(3)}
              >
                Avançar para revisão <ArrowRight className="size-3.5" />
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Etapa 3 */}
      {step === 3 && (
        <div className="space-y-4">
          <section className="rounded-xl border border-border bg-card p-4">
            <h2 className="text-[13px] font-extrabold uppercase tracking-wider text-primary">
              Dados da clínica
            </h2>
            <dl className="mt-2 grid gap-2 text-[12.5px] md:grid-cols-2">
              <Info label="Nome" value={clinica.nome} />
              <Info label="Telefone" value={clinica.telefone || "—"} />
              <Info label="Endereço" value={clinica.endereco || "—"} />
              <Info label="Bairro" value={clinica.neighborhood || "—"} />
              <Info
                label="Especialidades"
                value={clinica.especialidadesAtendidas.join(", ") || "—"}
              />
            </dl>
          </section>

          <section className="rounded-xl border border-border bg-card">
            <div className="flex items-center justify-between border-b border-border p-3">
              <h2 className="text-[13px] font-extrabold uppercase tracking-wider text-primary">
                Serviços a cadastrar ({validRows.length})
              </h2>
              <Button variant="ghost" size="sm" className="h-8 text-[12px]" onClick={() => setStep(2)}>
                Editar serviços
              </Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-left text-[12.5px]">
                <thead className="border-b border-border bg-muted/60 text-[10.5px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="p-2 font-bold">Categoria</th>
                    <th className="p-2 font-bold">Serviço</th>
                    <th className="p-2 font-bold">Especialidade</th>
                    <th className="p-2 font-bold">Tabela</th>
                    <th className="p-2 font-bold">Prev Bem</th>
                    <th className="p-2 font-bold">Prazo</th>
                    <th className="p-2 font-bold">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {validRows.map((row) => (
                    <tr key={row.id}>
                      <td className="p-2 text-muted-foreground">{categoriaLabels[row.categoria]}</td>
                      <td className="p-2 font-bold">{row.nome}</td>
                      <td className="p-2 text-muted-foreground">{row.especialidade || "—"}</td>
                      <td className="p-2 text-muted-foreground line-through">
                        {parsePrice(row.precoDeTabela) > 0 ? brl(parsePrice(row.precoDeTabela)) : "—"}
                      </td>
                      <td className="p-2 font-extrabold text-accent">{brl(parsePrice(row.preco))}</td>
                      <td className="p-2 text-muted-foreground">{row.prazoResultado || "—"}</td>
                      <td className="p-2 font-bold">{row.ativo ? "Ativo" : "Inativo"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <div className="flex items-center justify-between gap-3">
            <Button variant="outline" size="sm" className="h-9 text-[12px]" onClick={() => setStep(2)}>
              Voltar
            </Button>
            <Button variant="cta" size="sm" className="h-9 gap-1.5 text-[12px]" onClick={publish}>
              <Check className="size-3.5" /> Confirmar e publicar clínica
            </Button>
          </div>
        </div>
      )}

      <ImportSheetDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        onImport={(imported) => {
          setRows((prev) => [...prev.filter((r) => r.nome.trim() || r.preco.trim()), ...imported]);
          setManualOpen(true);
          toast.success(`${imported.length} serviço(s) importado(s) da planilha.`);
        }}
      />
    </div>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-muted px-3 py-2">
      <dt className="text-[10.5px] font-extrabold uppercase tracking-wide text-muted-foreground">
        {label}
      </dt>
      <dd className="font-bold">{value}</dd>
    </div>
  );
}
