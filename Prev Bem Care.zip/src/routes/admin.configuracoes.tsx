import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { Building2, ExternalLink, ImageUp, Loader2, Save, Stethoscope, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useSiteSettings } from "@/context/site-settings";

export const Route = createFileRoute("/admin/configuracoes")({
  head: () => ({
    meta: [
      { title: "Configurações do site — Prev Bem" },
      {
        name: "description",
        content:
          "Área interna Prev Bem para ajustar cores da marca, logo, nome do site, WhatsApp de atendimento e texto do rodapé.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Configurações do site — Prev Bem" },
      {
        property: "og:description",
        content: "Ajuste identidade visual, contato e rodapé da plataforma Prev Bem.",
      },
    ],
  }),
  component: AdminSettingsPage,
});

const MAX_LOGO_BYTES = 400 * 1024;

type Tab = "identidade" | "catalogo";

function AdminSettingsPage() {
  const { settings, ready, save } = useSiteSettings();
  const [tab, setTab] = useState<Tab>("identidade");
  const [form, setForm] = useState(settings);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setForm(settings);
  }, [settings]);

  const set = <K extends keyof typeof form>(key: K, value: (typeof form)[K]) =>
    setForm((prev) => ({ ...prev, [key]: value }));

  async function handleFile(file: File) {
    if (!file.type.startsWith("image/")) {
      toast.error("Selecione um arquivo de imagem.");
      return;
    }
    if (file.size > MAX_LOGO_BYTES) {
      toast.error("Imagem muito grande. Use um arquivo de até 400 KB.");
      return;
    }
    const dataUrl = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
    set("logo_url", dataUrl);
  }

  async function handleSave() {
    setSaving(true);
    const { error } = await save({
      cor_primaria: form.cor_primaria,
      cor_destaque: form.cor_destaque,
      logo_url: form.logo_url,
      nome_site: form.nome_site.trim() || "Prev Bem",
      whatsapp_numero: form.whatsapp_numero.replace(/\D/g, ""),
      texto_rodape: form.texto_rodape,
    });
    setSaving(false);
    if (error) toast.error(`Não foi possível salvar: ${error}`);
    else toast.success("Configurações atualizadas em todo o site.");
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-lg font-extrabold">Configurações do site</h1>
        <p className="text-[12px] font-semibold text-muted-foreground">
          Alterações aqui valem para todo o site, inclusive na versão publicada, assim que salvas.
        </p>
      </div>

      <div className="flex gap-1 rounded-lg bg-muted p-1 text-[12px] font-bold">
        {(
          [
            ["identidade", "Identidade e contato"],
            ["catalogo", "Catálogo e Preços"],
          ] as const
        ).map(([value, label]) => (
          <button
            key={value}
            onClick={() => setTab(value)}
            className={`rounded-md px-3 py-1.5 transition-colors ${
              tab === value ? "bg-card shadow-sm text-primary" : "text-muted-foreground"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === "catalogo" ? (
        <CatalogShortcuts />
      ) : (
        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_320px]">
          <div className="space-y-4 rounded-xl border border-border bg-card p-4">
            <fieldset disabled={!ready} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <ColorField
                  label="Cor primária"
                  value={form.cor_primaria}
                  onChange={(v) => set("cor_primaria", v)}
                />
                <ColorField
                  label="Cor de destaque (CTA)"
                  value={form.cor_destaque}
                  onChange={(v) => set("cor_destaque", v)}
                />
              </div>

              <div className="space-y-2">
                <Label className="text-[12px] font-bold">Logo</Label>
                <div className="flex items-center gap-3">
                  <div className="grid size-16 shrink-0 place-items-center rounded-xl border border-border bg-muted">
                    {form.logo_url ? (
                      <img
                        src={form.logo_url}
                        alt="Logo atual"
                        className="size-14 object-contain"
                      />
                    ) : (
                      <span className="text-[10px] font-bold text-muted-foreground">sem logo</span>
                    )}
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <input
                      ref={fileRef}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) void handleFile(file);
                        e.target.value = "";
                      }}
                    />
                    <Button
                      type="button"
                      variant="soft"
                      size="sm"
                      onClick={() => fileRef.current?.click()}
                    >
                      <ImageUp className="size-3.5" /> Enviar imagem
                    </Button>
                    {form.logo_url && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => set("logo_url", null)}
                      >
                        <Trash2 className="size-3.5" /> Remover
                      </Button>
                    )}
                  </div>
                </div>
                <Input
                  value={form.logo_url ?? ""}
                  onChange={(e) => set("logo_url", e.target.value || null)}
                  placeholder="Ou cole a URL de uma imagem"
                  className="h-9 text-[13px]"
                />
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-[12px] font-bold">Nome do site</Label>
                  <Input
                    value={form.nome_site}
                    onChange={(e) => set("nome_site", e.target.value)}
                    className="h-9 text-[13px]"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[12px] font-bold">WhatsApp (somente números)</Label>
                  <Input
                    value={form.whatsapp_numero}
                    onChange={(e) => set("whatsapp_numero", e.target.value)}
                    placeholder="5586999990000"
                    className="h-9 text-[13px]"
                  />
                  <p className="text-[11px] font-semibold text-muted-foreground">
                    Usado no botão “Finalizar pelo WhatsApp” e nos demais redirecionamentos.
                  </p>
                </div>
              </div>

              <div className="space-y-1.5">
                <Label className="text-[12px] font-bold">Texto do rodapé</Label>
                <Textarea
                  value={form.texto_rodape}
                  onChange={(e) => set("texto_rodape", e.target.value)}
                  rows={3}
                  className="text-[13px]"
                />
              </div>
            </fieldset>

            <div className="flex justify-end border-t border-border pt-3">
              <Button size="sm" onClick={() => void handleSave()} disabled={saving || !ready}>
                {saving ? <Loader2 className="size-3.5 animate-spin" /> : <Save className="size-3.5" />}
                Salvar alterações
              </Button>
            </div>
          </div>

          <Preview primary={form.cor_primaria} accent={form.cor_destaque} name={form.nome_site} />
        </div>
      )}
    </div>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="space-y-1.5">
      <Label className="text-[12px] font-bold">{label}</Label>
      <div className="flex items-center gap-2">
        <input
          type="color"
          value={/^#[0-9a-f]{6}$/i.test(value) ? value : "#000000"}
          onChange={(e) => onChange(e.target.value.toUpperCase())}
          className="size-9 cursor-pointer rounded-md border border-border bg-card p-1"
          aria-label={label}
        />
        <Input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-9 font-mono text-[13px] uppercase"
        />
      </div>
    </div>
  );
}

function Preview({
  primary,
  accent,
  name,
}: {
  primary: string;
  accent: string;
  name: string;
}) {
  return (
    <aside className="h-fit space-y-3 rounded-xl border border-border bg-card p-4">
      <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
        Pré-visualização
      </p>
      <div
        className="space-y-3 rounded-xl p-4"
        style={{ background: `color-mix(in oklab, ${primary} 8%, white)` }}
      >
        <div className="rounded-xl bg-white p-4 shadow-sm">
          <p className="text-[11px] font-bold uppercase" style={{ color: primary }}>
            {name || "Prev Bem"}
          </p>
          <p className="mt-1 text-sm font-extrabold text-slate-900">Hemograma completo</p>
          <p className="text-[12px] font-semibold text-slate-500 line-through">R$ 68,00</p>
          <p className="text-xl font-extrabold" style={{ color: accent }}>
            R$ 24,90
          </p>
          <button
            className="mt-3 w-full rounded-full px-4 py-2 text-[12px] font-extrabold text-white"
            style={{ background: accent }}
            type="button"
          >
            Adicionar ao carrinho
          </button>
          <button
            className="mt-2 w-full rounded-full px-4 py-2 text-[12px] font-extrabold text-white"
            style={{ background: primary }}
            type="button"
          >
            Ver detalhes
          </button>
        </div>
      </div>
      <p className="text-[11px] font-semibold text-muted-foreground">
        As cores só valem para o site depois de salvar.
      </p>
    </aside>
  );
}

function CatalogShortcuts() {
  const shortcuts = [
    {
      to: "/admin/parceiros",
      icon: Building2,
      title: "Clínicas e serviços",
      desc: "Cadastro de clínicas parceiras e edição em planilha dos preços de cada serviço.",
    },
    {
      to: "/admin/catalogo",
      icon: Stethoscope,
      title: "Catálogo (legado)",
      desc: "Gestão simples dos serviços antigos do catálogo.",
    },
  ] as const;

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {shortcuts.map((s) => (
        <Link
          key={s.to}
          to={s.to}
          className="group rounded-xl border border-border bg-card p-4 transition-colors hover:border-primary"
        >
          <div className="flex items-center gap-2 text-primary">
            <s.icon className="size-4" />
            <span className="text-sm font-extrabold">{s.title}</span>
            <ExternalLink className="ml-auto size-3.5 opacity-0 transition-opacity group-hover:opacity-100" />
          </div>
          <p className="mt-1.5 text-[12px] font-semibold text-muted-foreground">{s.desc}</p>
        </Link>
      ))}
    </div>
  );
}
