import { createFileRoute, Link } from "@tanstack/react-router";
import { HeartHandshake, ShieldCheck, Sparkles, Users } from "lucide-react";

import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/sobre")({
  head: () => ({
    meta: [
      { title: "Sobre a Prev Bem — saúde particular acessível" },
      {
        name: "description",
        content:
          "Conheça a Prev Bem: um marketplace de saúde que conecta pacientes particulares a clínicas parceiras com preços justos e atendimento acolhedor.",
      },
      { property: "og:title", content: "Sobre a Prev Bem" },
      {
        property: "og:description",
        content: "Nossa missão é tornar o cuidado com a saúde acessível para quem não tem convênio.",
      },
    ],
  }),
  component: About,
});

const values = [
  {
    icon: HeartHandshake,
    title: "Acolhimento",
    desc: "Linguagem simples, sem jargão médico e com suporte humano em cada etapa.",
  },
  {
    icon: ShieldCheck,
    title: "Transparência",
    desc: "Preço final visível antes de agendar. Nenhuma taxa surpresa.",
  },
  {
    icon: Users,
    title: "Acesso",
    desc: "Rede de clínicas e laboratórios parceiros com valores negociados em escala.",
  },
  {
    icon: Sparkles,
    title: "Prevenção",
    desc: "Incentivamos check-ups e acompanhamento contínuo, não só a urgência.",
  },
];

function About() {
  return (
    <div>
      <section className="hero-gradient">
        <div className="mx-auto w-full max-w-4xl px-4 py-16 text-center sm:px-6 lg:px-8">
          <span className="inline-flex items-center gap-2 rounded-full bg-background px-4 py-2 text-xs font-extrabold text-primary shadow-soft">
            Nossa história
          </span>
          <h1 className="mt-6 text-4xl sm:text-5xl">
            Saúde não deveria depender de <span className="text-primary">ter convênio</span>
          </h1>
          <p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-muted-foreground">
            Mais da metade dos brasileiros paga do próprio bolso quando precisa de uma consulta ou
            exame — e quase sempre sem saber quanto vai custar. A Prev Bem nasceu para mudar isso,
            reunindo clínicas parceiras em um só lugar com preços claros e agendamento digital.
          </p>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {values.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="surface-card p-6">
              <span className="flex size-12 items-center justify-center rounded-2xl bg-accent-soft text-accent">
                <Icon className="size-5" />
              </span>
              <h2 className="mt-5 text-lg">{title}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto w-full max-w-5xl px-4 pb-16 sm:px-6 lg:px-8">
        <div className="surface-card grid gap-8 p-8 sm:p-12 md:grid-cols-2">
          <div>
            <h2 className="text-2xl">Nossa missão</h2>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Tornar o cuidado preventivo acessível a qualquer pessoa, com preço justo e experiência
              digital simples — do primeiro clique até o resultado do exame.
            </p>
          </div>
          <div>
            <h2 className="text-2xl">Como remuneramos parceiros</h2>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Clínicas e laboratórios preenchem horários ociosos com pacientes particulares. Você
              paga menos, o parceiro atende mais, e ninguém depende de intermediação de convênio.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
        <div className="brand-gradient flex flex-col items-center gap-6 rounded-3xl p-10 text-center text-primary-foreground sm:p-14">
          <h2 className="max-w-xl text-3xl text-primary-foreground">
            Pronto para cuidar da sua saúde com preço justo?
          </h2>
          <Button variant="cta" size="lg" asChild>
            <Link to="/servicos">Ver consultas e exames</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
