import { createFileRoute, Link } from "@tanstack/react-router";
import { FileText } from "lucide-react";

import { Button } from "@/components/ui/button";
import { WHATSAPP_DISPLAY } from "@/config/contact";

export const Route = createFileRoute("/termos")({
  head: () => ({
    meta: [
      { title: "Termos de Uso | Prev Bem" },
      {
        name: "description",
        content:
          "Regras claras de uso da Prev Bem: como funciona o agendamento, o papel das clínicas parceiras, pagamentos combinados por WhatsApp e responsabilidades de cada parte.",
      },
      { property: "og:title", content: "Termos de Uso | Prev Bem" },
      {
        property: "og:description",
        content: "As regras de uso da plataforma Prev Bem, em linguagem simples.",
      },
    ],
  }),
  component: TermsPage,
});

const sections = [
  {
    title: "1. O que é a Prev Bem",
    body: "A Prev Bem é uma plataforma que reúne consultas, exames e procedimentos de clínicas, laboratórios e profissionais parceiros com preços particulares combinados. Nós intermediamos o agendamento: o atendimento em si é realizado pelo parceiro que você escolher.",
  },
  {
    title: "2. Quem pode usar",
    body: "Você precisa ter 18 anos ou mais para criar um pedido. É possível agendar para outra pessoa (filhos, pais, cônjuge), desde que você tenha autorização dela e informe corretamente o nome de quem será atendido.",
  },
  {
    title: "3. Como funciona o pedido",
    body: "Você escolhe os serviços, informa nome e telefone e nós geramos uma guia digital com um número de pedido. Essa guia é a confirmação do seu interesse — o agendamento é concluído quando nossa equipe confirma o pagamento e a data com a clínica parceira.",
  },
  {
    title: "4. Pagamento",
    body: `Não há cobrança dentro do site. O pagamento (PIX ou cartão) é combinado diretamente com a nossa equipe pelo WhatsApp ${WHATSAPP_DISPLAY}. Nunca pedimos senha, código de segurança ou dados completos de cartão pelo site.`,
  },
  {
    title: "5. Preços e disponibilidade",
    body: "Os preços exibidos são os valores negociados com os parceiros e podem mudar. Vagas e horários dependem da agenda de cada clínica. Se algo mudar depois do seu pedido, avisamos antes de qualquer confirmação.",
  },
  {
    title: "6. Reagendamento e cancelamento",
    body: "Você pode pedir reagendamento ou cancelamento pelo WhatsApp. Se o pagamento já tiver sido feito, tratamos o reembolso conforme a política da clínica parceira e a legislação de consumo.",
  },
  {
    title: "7. Responsabilidades",
    body: "A responsabilidade técnica pelo atendimento, diagnóstico, resultado de exame e conduta clínica é do parceiro e do profissional de saúde que atende você. A Prev Bem responde pela intermediação: informações do catálogo, geração da guia e suporte no agendamento. A plataforma não substitui atendimento de urgência — em emergências, procure um pronto-socorro ou ligue 192.",
  },
  {
    title: "8. Uso adequado da plataforma",
    body: "Use a Prev Bem com informações verdadeiras. Não é permitido criar pedidos falsos, tentar burlar preços, copiar o conteúdo do catálogo para uso comercial ou interferir no funcionamento do site.",
  },
  {
    title: "9. Seus dados",
    body: "O tratamento dos seus dados pessoais segue a nossa Política de Privacidade, escrita em linguagem simples e alinhada à LGPD.",
  },
  {
    title: "10. Mudanças nestes termos",
    body: "Podemos atualizar estes termos para refletir melhorias ou exigências legais. Quando a mudança for relevante, avisamos no site ou pelo WhatsApp. Dúvidas? Fale com a gente.",
  },
];

function TermsPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
      <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft px-4 py-1.5 text-xs font-extrabold uppercase tracking-wide text-primary">
        <FileText className="size-4" /> Termos
      </span>
      <h1 className="mt-4 text-3xl sm:text-4xl">Termos de Uso</h1>
      <p className="mt-3 text-muted-foreground">
        Sem juridiquês: aqui está, em português claro, o que você pode esperar da Prev Bem e o que
        esperamos de você. Última atualização: agosto de 2026.
      </p>

      <div className="mt-10 space-y-5">
        {sections.map((s) => (
          <section key={s.title} className="surface-card p-7">
            <h2 className="text-lg">{s.title}</h2>
            <p className="mt-2 text-sm font-semibold leading-relaxed text-muted-foreground">
              {s.body}
            </p>
          </section>
        ))}
      </div>

      <div className="mt-10 flex flex-wrap gap-3">
        <Button variant="soft" asChild>
          <Link to="/privacidade">Ler a Política de Privacidade</Link>
        </Button>
        <Button variant="ghost" asChild>
          <Link to="/contato">Falar com a equipe</Link>
        </Button>
      </div>
    </div>
  );
}
