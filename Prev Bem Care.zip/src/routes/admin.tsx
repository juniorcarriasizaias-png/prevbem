import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { useState } from "react";
import {
  Building2,
  ClipboardList,
  LayoutDashboard,
  LogOut,
  ShieldCheck,
  Stethoscope,
  Settings,
  Users,
} from "lucide-react";

import { AdminProvider } from "@/context/admin";
import { CatalogAdminProvider } from "@/context/catalog-admin";
import { RoleGuard } from "@/components/auth/role-guard";
import { useAuth } from "@/context/auth";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/admin")({
  head: () => ({
    meta: [
      { title: "Painel administrativo — Prev Bem" },
      {
        name: "description",
        content:
          "Painel interno Prev Bem: pedidos, confirmação manual de pagamentos, catálogo de serviços, clínicas parceiras e pacientes.",
      },
      { name: "robots", content: "noindex, nofollow" },
      { property: "og:title", content: "Painel administrativo — Prev Bem" },
      {
        property: "og:description",
        content: "Área interna da equipe Prev Bem para gestão de pedidos e catálogo.",
      },
    ],
  }),
  component: AdminLayout,
});

const nav = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { to: "/admin/pedidos", label: "Pedidos", icon: ClipboardList, exact: false },
  { to: "/admin/parceiros", label: "Parceiros e Catálogo", icon: Building2, exact: false },
  { to: "/admin/catalogo", label: "Catálogo (legado)", icon: Stethoscope, exact: false },
  { to: "/admin/clinicas", label: "Clínicas (legado)", icon: Building2, exact: false },
  { to: "/admin/pacientes", label: "Pacientes", icon: Users, exact: false },
  { to: "/admin/configuracoes", label: "Configurações do Site", icon: Settings, exact: false },
] as const;

function AdminLayout() {
  return (
    <RoleGuard allow={["admin"]}>
      <AdminProvider>
      <CatalogAdminProvider>
          <AdminShell />
        </CatalogAdminProvider>
      </AdminProvider>
    </RoleGuard>
  );
}


function AdminShell() {
  return (
    <div className="min-h-screen bg-muted/50 text-[13px] text-foreground">
      <div className="mx-auto flex max-w-[1400px]">
        <AdminSidebar />
        <div className="min-w-0 flex-1">
          <AdminTopbar />
          <div className="p-4 md:p-6">
            <Outlet />
          </div>
        </div>
      </div>
    </div>
  );
}

function AdminSidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <aside className="hidden w-56 shrink-0 border-r border-border bg-primary md:block">
      <div className="sticky top-0 flex h-screen flex-col p-4">
        <Link to="/admin" className="flex items-center gap-2 text-primary-foreground">
          <span className="grid size-8 place-items-center rounded-lg bg-primary-foreground/15">
            <ShieldCheck className="size-4" />
          </span>
          <span className="leading-tight">
            <span className="block text-sm font-extrabold">Prev Bem</span>
            <span className="block text-[11px] font-semibold uppercase tracking-wider text-primary-foreground/70">
              Admin
            </span>
          </span>
        </Link>
        <nav className="mt-6 space-y-1">
          {nav.map((item) => {
            const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-2 rounded-lg px-3 py-2 text-[13px] font-bold transition-colors ${
                  active
                    ? "bg-accent text-accent-foreground"
                    : "text-primary-foreground/80 hover:bg-primary-foreground/10 hover:text-primary-foreground"
                }`}
              >
                <item.icon className="size-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="mt-auto rounded-lg bg-primary-foreground/10 p-3 text-[11px] font-semibold text-primary-foreground/80">
          Pagamentos são confirmados manualmente após combinação pelo WhatsApp.
        </div>
      </div>
    </aside>
  );
}

function AdminTopbar() {
  const { user, signOut } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-card/95 backdrop-blur">
      <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-6">
        <div className="min-w-0">
          <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Painel interno
          </p>
          <p className="truncate text-sm font-extrabold">
            {nav.find((n) => (n.exact ? pathname === n.to : pathname.startsWith(n.to)))?.label ??
              "Admin"}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Link
            to="/"
            className="hidden text-[12px] font-bold text-primary hover:underline sm:inline"
          >
            Ver site
          </Link>
          <div className="text-right">
            <p className="text-[12px] font-extrabold leading-tight">{user?.name}</p>
            <p className="text-[11px] font-semibold text-muted-foreground">{user?.email}</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => void signOut()} className="h-8 gap-1.5 text-[12px]">
            <LogOut className="size-3.5" /> Sair
          </Button>
        </div>
      </div>
      <nav className="flex gap-1 overflow-x-auto border-t border-border px-2 py-2 md:hidden">
        {nav.map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className="whitespace-nowrap rounded-lg px-3 py-1.5 text-[12px] font-bold text-muted-foreground hover:bg-muted"
            activeProps={{ className: "bg-primary text-primary-foreground" }}
            activeOptions={{ exact: item.exact ?? false }}
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </header>
  );
}
