import { createFileRoute } from "@tanstack/react-router";
import { Clock, Pencil, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PartnerCard, PartnerSectionTitle } from "@/components/partner/partner-ui";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { usePartner } from "@/context/partner";
import { categoryLabels, formatPrice, type Service } from "@/data/mock";

export const Route = createFileRoute("/parceiro/servicos")({
  component: PartnerServices,
});

const suggestionStyles = {
  Pendente: "bg-accent-soft text-accent",
  Aprovada: "bg-success/12 text-success",
  Recusada: "bg-destructive/10 text-destructive",
} as const;

function PartnerServices() {
  const { services, suggestions, suggestPrice, pendingFor, clinic } = usePartner();
  const [draft, setDraft] = useState<Service | null>(null);
  const [price, setPrice] = useState("");
  const [listPrice, setListPrice] = useState("");
  const [note, setNote] = useState("");

  const openDraft = (service: Service) => {
    setDraft(service);
    setPrice(String(service.price));
    setListPrice(String(service.listPrice));
    setNote("");
  };

  const submit = () => {
    if (!draft) return;
    const newPrice = Number(price);
    const newListPrice = Number(listPrice);
    if (!Number.isFinite(newPrice) || newPrice <= 0) {
      toast.error("Informe um preço Prev Bem válido.");
      return;
    }
    if (!Number.isFinite(newListPrice) || newListPrice < newPrice) {
      toast.error("O preço de tabela deve ser maior ou igual ao preço Prev Bem.");
      return;
    }
    suggestPrice(draft, newPrice, newListPrice, note.trim() || undefined);
    toast.success("Sugestão enviada para aprovação da equipe Prev Bem.");
    setDraft(null);
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">Meus serviços</h1>
        <p className="text-sm font-semibold text-muted-foreground">
          Estes são os serviços da {clinic?.name} publicados na Prev Bem. Cada serviço pertence
          somente à sua clínica. Alterações de preço passam pela aprovação da equipe central.
        </p>
      </div>

      <div className="grid gap-3">
        {services.map((s) => {
          const pending = pendingFor(s.id);
          return (
            <PartnerCard key={s.id} className="p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-extrabold">{s.name}</p>
                    <span className="rounded-full bg-secondary px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-primary">
                      {categoryLabels[s.category]}
                    </span>
                    {pending && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-accent-soft px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-accent">
                        <Clock className="size-3" /> Preço em análise
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-[12px] font-semibold text-muted-foreground">
                    {s.specialty} · {s.duration}
                    {s.resultTime ? ` · resultado em ${s.resultTime}` : ""}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[11px] font-semibold text-muted-foreground line-through">
                    {formatPrice(s.listPrice)}
                  </p>
                  <p className="text-lg font-extrabold text-accent">{formatPrice(s.price)}</p>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap items-center gap-2">
                <Button variant="soft" size="sm" onClick={() => openDraft(s)}>
                  <Pencil /> Sugerir novo preço
                </Button>
                {pending && (
                  <p className="text-[11px] font-semibold text-muted-foreground">
                    Sugerido: {formatPrice(pending.suggestedPrice)} — aguardando aprovação.
                  </p>
                )}
              </div>
            </PartnerCard>
          );
        })}
        {services.length === 0 && (
          <PartnerCard className="p-10 text-center text-[13px] font-semibold text-muted-foreground">
            Sua clínica ainda não tem serviços publicados.
          </PartnerCard>
        )}
      </div>

      <PartnerCard className="p-5">
        <PartnerSectionTitle title="Histórico de sugestões de preço" />
        <ul className="mt-3 divide-y divide-border">
          {suggestions.map((s) => (
            <li key={s.id} className="flex flex-wrap items-center justify-between gap-3 py-2.5">
              <div className="min-w-0">
                <p className="truncate text-[13px] font-extrabold">{s.serviceName}</p>
                <p className="text-[11px] font-semibold text-muted-foreground">
                  {formatPrice(s.currentPrice)} → {formatPrice(s.suggestedPrice)} ·{" "}
                  {new Date(s.createdAt).toLocaleDateString("pt-BR")}
                  {s.reviewNote ? ` · ${s.reviewNote}` : ""}
                </p>
              </div>
              <span
                className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide ${suggestionStyles[s.status]}`}
              >
                {s.status}
              </span>
            </li>
          ))}
          {suggestions.length === 0 && (
            <li className="py-6 text-center text-[12px] font-semibold text-muted-foreground">
              Nenhuma sugestão enviada até agora.
            </li>
          )}
        </ul>
        <p className="mt-4 flex items-start gap-2 rounded-xl bg-secondary/50 p-3 text-[11px] font-semibold text-muted-foreground">
          <ShieldCheck className="mt-0.5 size-3.5 shrink-0 text-primary" />
          Preços só mudam no site depois da aprovação da equipe Prev Bem, para manter a
          previsibilidade para os pacientes.
        </p>
      </PartnerCard>

      <Dialog open={Boolean(draft)} onOpenChange={(open) => !open && setDraft(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">Sugerir preço — {draft?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="sug-price" className="text-[12px]">
                Novo preço Prev Bem (R$)
              </Label>
              <Input
                id="sug-price"
                type="number"
                min={1}
                value={price}
                onChange={(e) => setPrice(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sug-list" className="text-[12px]">
                Preço de tabela (R$)
              </Label>
              <Input
                id="sug-list"
                type="number"
                min={1}
                value={listPrice}
                onChange={(e) => setListPrice(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="sug-note" className="text-[12px]">
                Justificativa (opcional)
              </Label>
              <Textarea
                id="sug-note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Ex.: reajuste de custos do laboratório."
                className="min-h-20 text-[13px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setDraft(null)}>
              Cancelar
            </Button>
            <Button variant="cta" onClick={submit}>
              Enviar para aprovação
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
