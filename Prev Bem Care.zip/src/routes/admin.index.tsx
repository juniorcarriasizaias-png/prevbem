import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarCheck, Clock3, TrendingUp, Wallet } from "lucide-react";

import { useAdmin } from "@/context/admin";
import { formatPrice } from "@/data/mock";

export const Route = createFileRoute("/admin/")({
  component: AdminDashboard,
});

const isSameDay = (iso: string, ref: Date) => {
  const d = new Date(iso);
  return (
    d.getDate() === ref.getDate() &&
    d.getMonth() === ref.getMonth() &&
    d.getFullYear() === ref.getFullYear()
  );
};

const isSameMonth = (iso: string, ref: Date) => {
  const d = new Date(iso);
  return d.getMonth() === ref.getMonth() && d.getFullYear() === ref.getFullYear();
};

function AdminDashboard() {
  const { orders } = useAdmin();
  const now = new Date();

  const today = orders.filter((o) => isSameDay(o.createdAt, now));
  const month = orders.filter((o) => isSameMonth(o.createdAt, now));
  const pending = orders.filter((o) => o.status === "Aguardando pagamento");
  const confirmed = orders.filter((o) => o.status === "Confirmado" || o.status === "Concluído");

  const sum = (list: typeof orders) => list.reduce((s, o) => s + o.total, 0);

  const topServices = Object.values(
    orders
      .flatMap((o) => o.items)
      .reduce<Record<string, { name: string; qty: number; revenue: number }>>((acc, item) => {
        const cur = acc[item.name] ?? { name: item.name, qty: 0, revenue: 0 };
        cur.qty += item.qty;
        cur.revenue += item.qty * item.unitPrice;
        acc[item.name] = cur;
        return acc;
      }, {}),
  )
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 6);

  const topClinics = Object.values(
    orders
      .flatMap((o) => o.items)
      .reduce<Record<string, { name: string; qty: number; revenue: number }>>((acc, item) => {
        const cur = acc[item.clinic] ?? { name: item.clinic, qty: 0, revenue: 0 };
        cur.qty += item.qty;
        cur.revenue += item.qty * item.unitPrice;
        acc[item.clinic] = cur;
        return acc;
      }, {}),
  )
    .sort((a, b) => b.qty - a.qty)
    .slice(0, 6);

  const maxServiceQty = Math.max(1, ...topServices.map((s) => s.qty));
  const maxClinicQty = Math.max(1, ...topClinics.map((c) => c.qty));

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <Metric
          label="Pedidos hoje"
          value={String(today.length)}
          hint={`${formatPrice(sum(today))} em pedidos`}
          icon={CalendarCheck}
        />
        <Metric
          label="Pedidos no mês"
          value={String(month.length)}
          hint={`${formatPrice(sum(month))} em pedidos`}
          icon={TrendingUp}
        />
        <Metric
          label="Aguardando pagamento"
          value={formatPrice(sum(pending))}
          hint={`${pending.length} pedido(s) a confirmar`}
          icon={Clock3}
          tone="accent"
        />
        <Metric
          label="Pagamentos confirmados"
          value={formatPrice(sum(confirmed))}
          hint={`${confirmed.length} pedido(s) confirmados/concluídos`}
          icon={Wallet}
          tone="primary"
        />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Serviços mais vendidos" subtitle="Por quantidade em pedidos">
          {topServices.map((s) => (
            <BarRow key={s.name} label={s.name} qty={s.qty} revenue={s.revenue} max={maxServiceQty} />
          ))}
        </Panel>
        <Panel title="Clínicas com mais agendamentos" subtitle="Por itens agendados">
          {topClinics.map((c) => (
            <BarRow
              key={c.name}
              label={c.name}
              qty={c.qty}
              revenue={c.revenue}
              max={maxClinicQty}
              tone="accent"
            />
          ))}
        </Panel>
      </div>

      <Panel
        title="Pedidos recentes"
        subtitle="Últimos pedidos gerados pelos pacientes"
        action={
          <Link to="/admin/pedidos" className="text-[12px] font-bold text-primary hover:underline">
            Ver todos
          </Link>
        }
      >
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[12.5px]">
            <thead className="text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="py-2 pr-3 font-bold">Pedido</th>
                <th className="py-2 pr-3 font-bold">Paciente</th>
                <th className="py-2 pr-3 font-bold">Itens</th>
                <th className="py-2 pr-3 font-bold">Total</th>
                <th className="py-2 pr-3 font-bold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {orders.slice(0, 8).map((o) => (
                <tr key={o.id} className="hover:bg-muted/60">
                  <td className="py-2 pr-3 font-extrabold">
                    <Link to="/admin/pedidos/$orderId" params={{ orderId: o.id }} className="hover:underline">
                      {o.number}
                    </Link>
                  </td>
                  <td className="py-2 pr-3 font-semibold">{o.patientName}</td>
                  <td className="py-2 pr-3 text-muted-foreground">{o.items.length}</td>
                  <td className="py-2 pr-3 font-bold">{formatPrice(o.total)}</td>
                  <td className="py-2 pr-3">
                    <StatusPill status={o.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Panel>
    </div>
  );
}

function Metric({
  label,
  value,
  hint,
  icon: Icon,
  tone = "muted",
}: {
  label: string;
  value: string;
  hint: string;
  icon: React.ComponentType<{ className?: string }>;
  tone?: "muted" | "accent" | "primary";
}) {
  const toneClass =
    tone === "accent"
      ? "bg-accent-soft text-accent"
      : tone === "primary"
        ? "bg-primary/10 text-primary"
        : "bg-muted text-muted-foreground";
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">{label}</p>
        <span className={`grid size-7 place-items-center rounded-lg ${toneClass}`}>
          <Icon className="size-3.5" />
        </span>
      </div>
      <p className="mt-2 text-xl font-extrabold">{value}</p>
      <p className="text-[11.5px] font-semibold text-muted-foreground">{hint}</p>
    </div>
  );
}

function Panel({
  title,
  subtitle,
  action,
  children,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-xl border border-border bg-card p-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <h2 className="text-sm font-extrabold">{title}</h2>
          {subtitle && (
            <p className="text-[11.5px] font-semibold text-muted-foreground">{subtitle}</p>
          )}
        </div>
        {action}
      </div>
      <div className="mt-3 space-y-2.5">{children}</div>
    </section>
  );
}

function BarRow({
  label,
  qty,
  revenue,
  max,
  tone = "primary",
}: {
  label: string;
  qty: number;
  revenue: number;
  max: number;
  tone?: "primary" | "accent";
}) {
  return (
    <div>
      <div className="flex items-baseline justify-between gap-3">
        <p className="truncate text-[12.5px] font-bold">{label}</p>
        <p className="shrink-0 text-[11.5px] font-semibold text-muted-foreground">
          {qty} un · {formatPrice(revenue)}
        </p>
      </div>
      <div className="mt-1 h-1.5 rounded-full bg-muted">
        <div
          className={`h-1.5 rounded-full ${tone === "accent" ? "bg-accent" : "bg-primary"}`}
          style={{ width: `${Math.round((qty / max) * 100)}%` }}
        />
      </div>
    </div>
  );
}

export function StatusPill({ status }: { status: string }) {
  const map: Record<string, string> = {
    "Aguardando pagamento": "bg-accent-soft text-accent",
    Confirmado: "bg-primary/10 text-primary",
    Concluído: "bg-emerald-100 text-emerald-700",
    Cancelado: "bg-muted text-muted-foreground",
  };
  return (
    <span
      className={`inline-block whitespace-nowrap rounded-full px-2 py-0.5 text-[10.5px] font-extrabold uppercase tracking-wide ${
        map[status] ?? "bg-muted text-muted-foreground"
      }`}
    >
      {status}
    </span>
  );
}
