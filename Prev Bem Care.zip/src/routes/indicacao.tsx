import { createFileRoute, Link } from "@tanstack/react-router";
import { Check, Copy, Gift, MessageCircle, Share2, Users } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { buildWhatsAppUrl } from "@/config/contact";
import { useAuth } from "@/context/auth";
import { formatPrice } from "@/data/mock";
import {
  REFERRAL_FRIEND_DISCOUNT,
  REFERRAL_REWARD,
  buildReferralCode,
  buildReferralLink,
} from "@/lib/referral";

export const Route = createFileRoute("/indicacao")({
  head: () => ({
    meta: [
      { title: "Programa de indicação Prev Bem — indique e ganhe desconto" },
      {
        name: "description",
        content:
          "Compartilhe seu código de indicação Prev Bem pelo WhatsApp: seu amigo ganha desconto no primeiro agendamento e você recebe crédito no próximo.",
      },
      { property: "og:title", content: "Indique amigos e ganhe desconto | Prev Bem" },
      {
        property: "og:description",
        content:
          "Seu código de indicação Prev Bem dá desconto para quem você indica e crédito para você.",
      },
    ],
  }),
  component: Referral,
});

const steps = [
  { title: "Compartilhe seu código", desc: "Envie o link pelo WhatsApp para amigos e familiares." },
  {
    title: "Seu amigo agenda",
    desc: `Ao informar o código no atendimento, ele ganha ${REFERRAL_FRIEND_DISCOUNT}% de desconto.`,
  },
  {
    title: "Você recebe crédito",
    desc: `Depois do atendimento concluído, ${formatPrice(REFERRAL_REWARD)} entram como crédito no seu próximo agendamento.`,
  },
];

function Referral() {
  const { user } = useAuth();
  const [copied, setCopied] = useState(false);
  const code = buildReferralCode(user?.name, user?.memberId);
  const link = buildReferralLink(code);

  const message = [
    "Oi! Uso o Prev Bem para agendar consultas e exames particulares com preço justo em Teresina.",
    "",
    `Use meu código de indicação ${code} e ganhe ${REFERRAL_FRIEND_DISCOUNT}% de desconto no primeiro agendamento:`,
    link,
  ].join("\n");

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(`${code} — ${link}`);
      setCopied(true);
      toast.success("Código e link copiados!");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Não foi possível copiar. Selecione o código manualmente.");
    }
  };

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-12 sm:px-6 lg:px-8">
      <div className="text-center">
        <span className="mx-auto flex size-16 items-center justify-center rounded-3xl bg-accent-soft text-accent">
          <Gift className="size-7" />
        </span>
        <h1 className="mt-5 text-3xl sm:text-4xl">Indique amigos, ganhem os dois</h1>
        <p className="mx-auto mt-3 max-w-2xl text-base font-semibold text-muted-foreground">
          Cuidar da saúde fica mais leve em grupo. Compartilhe seu código: quem você indica economiza{" "}
          {REFERRAL_FRIEND_DISCOUNT}% no primeiro agendamento e você recebe{" "}
          {formatPrice(REFERRAL_REWARD)} de crédito.
        </p>
      </div>

      <div className="surface-card mt-9 space-y-5 p-7">
        <p className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
          {user ? "Seu código de indicação" : "Código de demonstração"}
        </p>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <p className="flex-1 rounded-2xl border-2 border-dashed border-primary/30 bg-secondary/60 px-5 py-4 text-center text-2xl font-extrabold tracking-[0.2em] text-primary">
            {code}
          </p>
          <Button variant="soft" size="lg" onClick={copy}>
            {copied ? <Check /> : <Copy />}
            {copied ? "Copiado" : "Copiar"}
          </Button>
        </div>
        <Input readOnly value={link} aria-label="Link de indicação" className="font-semibold" />
        <div className="flex flex-wrap gap-3">
          <Button variant="cta" size="lg" asChild>
            <a href={buildWhatsAppUrl(message)} target="_blank" rel="noreferrer">
              <MessageCircle /> Compartilhar no WhatsApp
            </a>
          </Button>
          <Button variant="outline" size="lg" asChild>
            <Link to="/clube">
              <Share2 /> Ver o Clube de Vantagens
            </Link>
          </Button>
        </div>
        {!user && (
          <p className="text-xs font-semibold text-muted-foreground">
            <Link to="/entrar" className="font-extrabold text-primary hover:underline">
              Entre na sua conta
            </Link>{" "}
            para gerar o código vinculado ao seu cadastro.
          </p>
        )}
      </div>

      <div className="mt-10 grid gap-5 md:grid-cols-3">
        {steps.map((s, i) => (
          <div key={s.title} className="surface-card p-6">
            <span className="flex size-11 items-center justify-center rounded-2xl bg-primary-soft text-primary">
              <Users className="size-5" />
            </span>
            <p className="mt-4 text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
              Passo {i + 1}
            </p>
            <h2 className="mt-1 text-lg">{s.title}</h2>
            <p className="mt-2 text-sm text-muted-foreground">{s.desc}</p>
          </div>
        ))}
      </div>

      <div className="surface-card mt-8 p-6">
        <h2 className="text-lg">Regras simples</h2>
        <ul className="mt-3 space-y-2 text-sm font-semibold text-muted-foreground">
          <li>· Descontos e créditos são aplicados manualmente pela equipe no WhatsApp.</li>
          <li>· O código deve ser informado antes da confirmação do agendamento.</li>
          <li>· Sem limite de indicações; créditos não são convertidos em dinheiro.</li>
          <li>· Valores demonstrativos nesta versão do Prev Bem.</li>
        </ul>
      </div>
    </div>
  );
}
