import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BadgePercent,
  Bell,
  CalendarCheck,
  CalendarClock,
  CreditCard,
  Download,
  FileText,
  History,
  IdCard,
  LogOut,
  MapPin,
  MessageCircle,
  ReceiptText,
  Settings,
  ShieldCheck,
  Trash2,
  UserRound,
  XCircle,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PatientCard } from "@/components/patient-card";
import {
  formatPrice,
  notifications,
  pastAppointments,
  upcomingAppointments,
  type Appointment,
  type AppointmentStatus,
  type NotificationKind,
} from "@/data/mock";
import { useOrders } from "@/context/orders";
import { useReviews } from "@/context/reviews";
import { ReviewDialog, StarRow } from "@/components/review-dialog";
import { useAuth } from "@/context/auth";
import { buildWhatsAppUrl, WHATSAPP_DISPLAY } from "@/config/contact";

export const Route = createFileRoute("/minha-conta")({
  head: () => ({
    meta: [
      { title: "Área do paciente | Prev Bem" },
      {
        name: "description",
        content:
          "Acompanhe agendamentos, carteirinha digital, guias de pedidos e notificações na sua área do paciente Prev Bem.",
      },
      { property: "og:title", content: "Área do paciente | Prev Bem" },
      {
        property: "og:description",
        content: "Seus agendamentos, carteirinha digital, pedidos e avisos em um só lugar.",
      },
    ],
  }),
  component: Account,
});

const statusStyles: Record<AppointmentStatus, string> = {
  Confirmado: "bg-primary-soft text-primary",
  "Aguardando pagamento": "bg-accent-soft text-accent",
  Concluído: "bg-secondary text-primary",
  Cancelado: "bg-muted text-muted-foreground",
};

const notificationIcons: Record<NotificationKind, typeof Bell> = {
  lembrete: CalendarClock,
  pagamento: CreditCard,
  promocao: BadgePercent,
  resultado: FileText,
};

function AppointmentCard({ appointment, patient }: { appointment: Appointment; patient: string }) {
  const a = appointment;
  const { getByAppointment } = useReviews();
  const myReview = getByAppointment(a.id);
  const isDone = a.status === "Concluído";
  const canManage = a.status === "Confirmado" || a.status === "Aguardando pagamento";

  const wa = (action: "reagendar" | "cancelar") =>
    buildWhatsAppUrl(
      `Olá! Sou ${patient} e gostaria de ${action === "reagendar" ? "reagendar" : "solicitar o cancelamento de"} meu agendamento no Prev Bem.\n\n` +
        `Serviço: ${a.service}\nClínica: ${a.clinic}\nData atual: ${a.date} às ${a.time}\n\n` +
        (action === "reagendar"
          ? "Quais horários vocês têm disponíveis?"
          : "Podem confirmar o cancelamento, por favor?"),
    );

  return (
    <div className="surface-card flex flex-col gap-4 p-5 sm:flex-row sm:items-start">
      <span className="flex size-12 shrink-0 items-center justify-center rounded-2xl bg-secondary text-primary">
        <CalendarCheck className="size-5" />
      </span>
      <div className="min-w-0 flex-1 space-y-1.5">
        <div className="flex flex-wrap items-center gap-2">
          <p className="text-base font-extrabold">{a.service}</p>
          <span
            className={`rounded-full px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide ${statusStyles[a.status]}`}
          >
            {a.status}
          </span>
        </div>
        <p className="inline-flex items-start gap-1.5 text-xs font-semibold text-muted-foreground">
          <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" /> {a.clinic} · {a.address}
        </p>
        <p className="text-xs font-bold text-accent">
          {a.date} às {a.time} · {formatPrice(a.price)}
        </p>
        {a.note && <p className="text-xs font-semibold text-muted-foreground">{a.note}</p>}
        {myReview && (
          <div className="mt-2 rounded-2xl bg-secondary/60 p-3">
            <p className="flex items-center gap-2 text-xs font-extrabold text-primary">
              <StarRow rating={myReview.rating} /> Sua avaliação: {myReview.rating} de 5
            </p>
            {myReview.comment && (
              <p className="mt-1 text-xs font-semibold text-muted-foreground">
                “{myReview.comment}”
              </p>
            )}
          </div>
        )}
      </div>
      {isDone ? (
        <div className="flex flex-wrap gap-2 sm:flex-col">
          <ReviewDialog
            appointmentId={a.id}
            serviceName={a.service}
            clinic={a.clinic}
            patientName={patient}
            existing={myReview}
          />
          <Button variant="soft" size="sm" asChild>
            <Link to="/servicos">Agendar novamente</Link>
          </Button>
        </div>
      ) : canManage ? (
        <div className="flex flex-wrap gap-2 sm:flex-col">
          <Button variant="cta" size="sm" asChild>
            <a href={wa("reagendar")} target="_blank" rel="noreferrer">
              <MessageCircle /> Reagendar
            </a>
          </Button>
          <Button variant="outline" size="sm" asChild>
            <a href={wa("cancelar")} target="_blank" rel="noreferrer">
              <XCircle /> Cancelar
            </a>
          </Button>
        </div>
      ) : (
        <Button variant="soft" size="sm" asChild>
          <Link to="/servicos">Agendar novamente</Link>
        </Button>
      )}
    </div>
  );
}

function SignedOut() {
  return (
    <div className="mx-auto w-full max-w-2xl px-4 py-16 text-center sm:px-6">
      <span className="mx-auto flex size-16 items-center justify-center rounded-3xl bg-primary-soft text-primary">
        <UserRound className="size-7" />
      </span>
      <h1 className="mt-5 text-2xl">Entre para ver sua área do paciente</h1>
      <p className="mt-3 text-sm font-semibold text-muted-foreground">
        Com sua conta Prev Bem você acompanha agendamentos, usa a carteirinha digital e consulta as
        guias dos seus pedidos.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Button variant="cta" asChild>
          <Link to="/entrar">Entrar ou criar conta</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link to="/servicos">Ver consultas e exames</Link>
        </Button>
      </div>
    </div>
  );
}

function Account() {
  const { user, ready, signOut } = useAuth();
  const { orders } = useOrders();
  const unread = notifications.filter((n) => n.unread).length;

  if (!ready) {
    return (
      <div className="mx-auto w-full max-w-6xl px-4 py-16 sm:px-6">
        <div className="h-40 animate-pulse rounded-3xl bg-secondary" />
      </div>
    );
  }

  if (!user) return <SignedOut />;

  const firstName = user.name.split(" ")[0];

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="brand-gradient flex flex-col gap-5 rounded-3xl p-7 text-primary-foreground sm:flex-row sm:items-center sm:justify-between">
        <div className="flex min-w-0 items-center gap-4">
          <span className="flex size-16 shrink-0 items-center justify-center rounded-3xl bg-primary-foreground/15">
            <UserRound className="size-7" />
          </span>
          <div className="min-w-0">
            <p className="text-xs font-bold uppercase tracking-wide text-primary-foreground/70">
              Área do paciente
            </p>
            <h1 className="truncate text-2xl text-primary-foreground">Olá, {firstName}</h1>
            <p className="text-sm text-primary-foreground/80">
              Identificação Prev Bem {user.memberId}
              {user.email ? ` · ${user.email}` : ""}

            </p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-3">
          <div className="rounded-2xl bg-primary-foreground/12 px-5 py-3">
            <p className="text-xl font-extrabold">{upcomingAppointments.length}</p>
            <p className="text-xs font-semibold text-primary-foreground/80">agendamentos futuros</p>
          </div>
          <div className="rounded-2xl bg-primary-foreground/12 px-5 py-3">
            <p className="text-xl font-extrabold">{orders.length}</p>
            <p className="text-xs font-semibold text-primary-foreground/80">pedidos gerados</p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={signOut}
            className="text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground"
          >
            <LogOut /> Sair
          </Button>
        </div>
      </div>

      <Tabs defaultValue="proximos" className="mt-8">
        <TabsList className="h-auto flex-wrap gap-1 rounded-full bg-secondary p-1.5">
          <TabsTrigger value="proximos" className="rounded-full px-5 py-2 font-bold">
            <CalendarCheck className="mr-1.5 size-4" /> Próximos
          </TabsTrigger>
          <TabsTrigger value="carteirinha" className="rounded-full px-5 py-2 font-bold">
            <IdCard className="mr-1.5 size-4" /> Carteirinha
          </TabsTrigger>
          <TabsTrigger value="pedidos" className="rounded-full px-5 py-2 font-bold">
            <ReceiptText className="mr-1.5 size-4" /> Pedidos
            {orders.length > 0 ? ` (${orders.length})` : ""}
          </TabsTrigger>
          <TabsTrigger value="historico" className="rounded-full px-5 py-2 font-bold">
            <History className="mr-1.5 size-4" /> Histórico
          </TabsTrigger>
          <TabsTrigger value="notificacoes" className="rounded-full px-5 py-2 font-bold">
            <Bell className="mr-1.5 size-4" /> Notificações{unread > 0 ? ` (${unread})` : ""}
          </TabsTrigger>
          <TabsTrigger value="configuracoes" className="rounded-full px-5 py-2 font-bold">
            <Settings className="mr-1.5 size-4" /> Configurações
          </TabsTrigger>
        </TabsList>

        <TabsContent value="proximos" className="mt-6 space-y-4">
          {upcomingAppointments.map((a) => (
            <AppointmentCard key={a.id} appointment={a} patient={user.name} />
          ))}
          <div className="surface-card flex flex-col items-start gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm font-semibold text-muted-foreground">
              Reagendamentos e cancelamentos são combinados com nossa equipe pelo WhatsApp, sem
              custo.
            </p>
            <Button variant="cta" asChild>
              <Link to="/servicos">Agendar novo serviço</Link>
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="carteirinha" className="mt-6 grid gap-6 lg:grid-cols-[1.15fr_1fr]">
          <PatientCard name={user.name} memberId={user.memberId} since={user.since} />
          <div className="surface-card space-y-4 p-6">
            <h2 className="text-lg">Como usar sua carteirinha</h2>
            <ul className="space-y-3 text-sm font-semibold text-muted-foreground">
              <li>1. Apresente a carteirinha na recepção da clínica parceira.</li>
              <li>2. Informe o número de identificação Prev Bem e o número do pedido.</li>
              <li>3. O QR code é decorativo nesta versão de demonstração.</li>
            </ul>
            <div className="flex flex-wrap gap-2">
              <Button variant="soft" onClick={() => window.print()}>
                <Download /> Salvar / imprimir
              </Button>
              <Button variant="outline" asChild>
                <a
                  href={buildWhatsAppUrl(
                    `Olá! Sou ${user.name}, identificação Prev Bem ${user.memberId}. Preciso de ajuda com a minha carteirinha digital.`,
                  )}
                  target="_blank"
                  rel="noreferrer"
                >
                  <MessageCircle /> Falar com a equipe
                </a>
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="pedidos" className="mt-6 space-y-4">
          {orders.length === 0 ? (
            <div className="surface-card p-8 text-center">
              <ReceiptText className="mx-auto size-9 text-primary" />
              <h2 className="mt-3 text-lg">Nenhum pedido por aqui ainda</h2>
              <p className="mt-2 text-sm text-muted-foreground">
                Quando você finalizar um pedido, a guia digital aparece aqui com o status do
                pagamento combinado pelo WhatsApp.
              </p>
              <Button variant="cta" className="mt-5" asChild>
                <Link to="/servicos">Ver serviços</Link>
              </Button>
            </div>
          ) : (
            orders.map((o) => (
              <div key={o.id} className="surface-card space-y-4 p-6">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <p className="text-base font-extrabold">Pedido {o.number}</p>
                    <p className="text-xs font-semibold text-muted-foreground">
                      {new Date(o.createdAt).toLocaleDateString("pt-BR")} ·{" "}
                      {o.forWhom === "other" && o.beneficiaryName
                        ? o.beneficiaryName
                        : o.patientName}
                    </p>
                  </div>
                  <span className="rounded-full bg-accent-soft px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-accent">
                    {o.status}
                  </span>
                </div>
                <ul className="space-y-2">
                  {o.items.map((item, i) => (
                    <li
                      key={`${o.id}-${i}`}
                      className="flex items-start justify-between gap-4 text-sm"
                    >
                      <span className="font-bold">
                        {item.name}
                        {item.qty > 1 ? ` (x${item.qty})` : ""}
                        <span className="ml-2 inline-flex items-center gap-1 text-xs font-semibold text-muted-foreground">
                          <MapPin className="size-3 text-primary" /> {item.clinic}
                        </span>
                      </span>
                      <span className="shrink-0 font-extrabold text-primary">
                        {formatPrice(item.unitPrice * item.qty)}
                      </span>
                    </li>
                  ))}
                </ul>
                <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border pt-4">
                  <span className="text-sm font-extrabold">Total: {formatPrice(o.total)}</span>
                  <Button variant="cta" size="sm" asChild>
                    <a
                      href={buildWhatsAppUrl(
                        `Olá! Quero retomar meu pedido ${o.number} no Prev Bem (total ${formatPrice(o.total)}). Aguardo o link de pagamento ou chave PIX.`,
                      )}
                      target="_blank"
                      rel="noreferrer"
                    >
                      <MessageCircle /> Combinar pagamento no WhatsApp
                    </a>
                  </Button>
                </div>
              </div>
            ))
          )}
        </TabsContent>

        <TabsContent value="historico" className="mt-6 space-y-4">
          {pastAppointments.map((a) => (
            <AppointmentCard key={a.id} appointment={a} patient={user.name} />
          ))}
          <div className="surface-card flex flex-col items-start gap-4 p-6 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm font-semibold text-muted-foreground">
              Resultados e laudos digitais ficam disponíveis por 5 anos.
            </p>
            <Button variant="outline">
              <Download /> Baixar todos
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="notificacoes" className="mt-6 space-y-4">
          {notifications.map((n) => {
            const Icon = notificationIcons[n.kind];
            return (
              <div key={n.id} className="surface-card flex gap-4 p-5">
                <span
                  className={
                    n.unread
                      ? "flex size-10 shrink-0 items-center justify-center rounded-2xl bg-accent-soft text-accent"
                      : "flex size-10 shrink-0 items-center justify-center rounded-2xl bg-secondary text-primary"
                  }
                >
                  <Icon className="size-4.5" />
                </span>
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="text-sm font-extrabold">{n.title}</p>
                    {n.unread && (
                      <span className="rounded-full bg-accent px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-accent-foreground">
                        Novo
                      </span>
                    )}
                  </div>
                  <p className="mt-1 text-sm font-semibold text-muted-foreground">{n.body}</p>
                  <p className="mt-1 text-xs font-bold text-muted-foreground">{n.time}</p>
                </div>
              </div>
            );
          })}
        </TabsContent>
        <TabsContent value="configuracoes" className="mt-6 space-y-4">
          <section className="surface-card p-7">
            <div className="flex items-center gap-3">
              <span className="flex size-10 items-center justify-center rounded-2xl bg-primary-soft text-primary">
                <ShieldCheck className="size-5" />
              </span>
              <h2 className="text-xl">Privacidade e seus dados</h2>
            </div>
            <p className="mt-3 text-sm font-semibold leading-relaxed text-muted-foreground">
              Guardamos apenas o necessário para agendar seus atendimentos: nome, telefone e o
              histórico dos seus pedidos. Você pode pedir acesso, correção ou exclusão desses dados
              quando quiser — sem burocracia, direto com a nossa equipe no {WHATSAPP_DISPLAY}.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Button variant="soft" asChild>
                <Link to="/privacidade">Política de Privacidade</Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/termos">Termos de Uso</Link>
              </Button>
            </div>
          </section>

          <section className="surface-card p-7">
            <div className="flex items-center gap-3">
              <span className="flex size-10 items-center justify-center rounded-2xl bg-accent-soft text-accent">
                <Trash2 className="size-5" />
              </span>
              <h2 className="text-xl">Solicitar exclusão dos meus dados</h2>
            </div>
            <p className="mt-3 text-sm font-semibold leading-relaxed text-muted-foreground">
              Ao solicitar, abrimos uma conversa no WhatsApp para confirmar sua identidade e apagamos
              seus dados pessoais em até 15 dias. Pedidos já pagos podem precisar ser mantidos por
              obrigação fiscal — nesse caso avisamos você e mantemos só o mínimo exigido pela lei.
            </p>
            <div className="mt-5 flex flex-wrap gap-3">
              <Button variant="cta" asChild>
                <a
                  href={buildWhatsAppUrl(
                    [
                      "Olá! Sou paciente da Prev Bem e quero solicitar a EXCLUSÃO dos meus dados pessoais (LGPD).",
                      "",
                      `Nome: ${user.name}`,
                      "Confirmo que este é o meu número de contato cadastrado.",
                    ].join("\n"),
                  )}
                  target="_blank"
                  rel="noreferrer"
                >
                  <MessageCircle /> Solicitar exclusão pelo WhatsApp
                </a>
              </Button>
              <Button variant="outline" asChild>
                <a
                  href={buildWhatsAppUrl(
                    [
                      "Olá! Sou paciente da Prev Bem e quero solicitar uma CÓPIA dos meus dados e do meu histórico (LGPD).",
                      "",
                      `Nome: ${user.name}`,
                    ].join("\n"),
                  )}
                  target="_blank"
                  rel="noreferrer"
                >
                  <FileText /> Pedir cópia dos meus dados
                </a>
              </Button>
            </div>
          </section>
        </TabsContent>
      </Tabs>
    </div>
  );
}
