import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MapPin, Pencil, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useAdmin, type AdminClinic } from "@/context/admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/admin/clinicas")({
  component: AdminClinics,
});

const slug = (name: string) =>
  name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || `clinica-${Date.now()}`;

const emptyClinic: AdminClinic = {
  id: "",
  name: "",
  address: "",
  neighborhood: "",
  city: "Teresina, PI",
  specialties: [],
};

function AdminClinics() {
  const { clinics, services, saveClinic, deleteClinic } = useAdmin();
  const [draft, setDraft] = useState<AdminClinic | null>(null);
  const [specialtiesText, setSpecialtiesText] = useState("");

  const openDraft = (clinic: AdminClinic) => {
    setDraft(clinic);
    setSpecialtiesText(clinic.specialties.join(", "));
  };

  return (
    <div className="space-y-4">
      <section className="flex items-center justify-between rounded-xl border border-border bg-card p-4">
        <div>
          <h1 className="text-sm font-extrabold">Clínicas parceiras</h1>
          <p className="text-[11.5px] font-semibold text-muted-foreground">
            {clinics.length} parceiras ativas em Teresina-PI
          </p>
        </div>
        <Button
          variant="cta"
          size="sm"
          className="h-8 gap-1.5 text-[12px]"
          onClick={() => openDraft(emptyClinic)}
        >
          <Plus className="size-3.5" /> Nova clínica
        </Button>
      </section>

      <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
        {clinics.map((c) => {
          const count = services.filter((s) => s.clinicId === c.id).length;
          return (
            <article key={c.id} className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <h2 className="text-[13.5px] font-extrabold">{c.name}</h2>
                  <p className="mt-0.5 inline-flex items-start gap-1 text-[11.5px] font-semibold text-muted-foreground">
                    <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
                    {c.address} — {c.neighborhood}, {c.city}
                  </p>
                </div>
                <div className="flex shrink-0 gap-1">
                  <Button variant="ghost" size="sm" className="h-7 px-2" onClick={() => openDraft(c)}>
                    <Pencil className="size-3.5" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 px-2 text-destructive"
                    onClick={() => {
                      deleteClinic(c.id);
                      toast.success("Clínica removida.");
                    }}
                  >
                    <Trash2 className="size-3.5" />
                  </Button>
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-1">
                {c.specialties.map((s) => (
                  <span
                    key={s}
                    className="rounded-full bg-primary/10 px-2 py-0.5 text-[10.5px] font-extrabold text-primary"
                  >
                    {s}
                  </span>
                ))}
              </div>
              <p className="mt-3 text-[11.5px] font-bold text-muted-foreground">
                {count} serviço(s) no catálogo
              </p>
            </article>
          );
        })}
      </div>

      <Dialog open={Boolean(draft)} onOpenChange={(open) => !open && setDraft(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-base">
              {draft?.id ? "Editar clínica" : "Nova clínica"}
            </DialogTitle>
          </DialogHeader>
          {draft && (
            <form
              className="space-y-3 text-[13px]"
              onSubmit={(e) => {
                e.preventDefault();
                if (!draft.name.trim()) return;
                saveClinic({
                  ...draft,
                  id: draft.id || slug(draft.name),
                  specialties: specialtiesText
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                });
                setDraft(null);
                toast.success("Clínica salva.");
              }}
            >
              <div className="space-y-1.5">
                <Label className="text-[12px]">Nome</Label>
                <Input
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Endereço</Label>
                <Input
                  value={draft.address}
                  onChange={(e) => setDraft({ ...draft, address: e.target.value })}
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Bairro</Label>
                  <Input
                    value={draft.neighborhood}
                    onChange={(e) => setDraft({ ...draft, neighborhood: e.target.value })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Cidade</Label>
                  <Input
                    value={draft.city}
                    onChange={(e) => setDraft({ ...draft, city: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Especialidades atendidas</Label>
                <Input
                  value={specialtiesText}
                  onChange={(e) => setSpecialtiesText(e.target.value)}
                  placeholder="Cardiologia, Imagem, Laboratorial"
                />
                <p className="text-[11px] font-semibold text-muted-foreground">
                  Separe por vírgula.
                </p>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" size="sm" onClick={() => setDraft(null)}>
                  Cancelar
                </Button>
                <Button type="submit" variant="cta" size="sm">
                  Salvar clínica
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
