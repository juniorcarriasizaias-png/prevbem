import { createFileRoute } from "@tanstack/react-router";
import { Mail, MessageCircle, Phone, Clock } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const Route = createFileRoute("/contato")({
  head: () => ({
    meta: [
      { title: "Contato e dúvidas | Prev Bem" },
      {
        name: "description",
        content:
          "Fale com a equipe Prev Bem por WhatsApp, telefone ou e-mail e veja as respostas para as dúvidas mais frequentes sobre agendamentos.",
      },
      { property: "og:title", content: "Contato e dúvidas | Prev Bem" },
      {
        property: "og:description",
        content: "Atendimento humano de segunda a sábado para ajudar no seu agendamento.",
      },
    ],
  }),
  component: Contact,
});

const channels = [
  { icon: MessageCircle, label: "WhatsApp", value: "(11) 90000-0000", note: "Resposta em minutos" },
  { icon: Phone, label: "Telefone", value: "0800 123 4567", note: "Ligação gratuita" },
  { icon: Mail, label: "E-mail", value: "contato@prevbem.com.br", note: "Resposta em até 24h" },
  { icon: Clock, label: "Horário", value: "Seg a Sáb, 8h às 20h", note: "Atendimento humano" },
];

const faqs = [
  {
    q: "Como sei que a clínica é confiável?",
    a: "Todas as clínicas e laboratórios passam por verificação de licença sanitária, registro dos profissionais e avaliação contínua dos pacientes.",
  },
  {
    q: "Consigo agendar para outra pessoa?",
    a: "Sim. Na etapa de finalização você informa os dados do paciente que será atendido, mesmo que seja diferente do titular da conta.",
  },
  {
    q: "Existe cobrança por cancelamento?",
    a: "Não. Cancelamentos feitos com mais de 24 horas de antecedência são gratuitos e sem multa.",
  },
  {
    q: "A Prev Bem atende na minha cidade?",
    a: "Estamos em expansão pelo estado de São Paulo e chegamos a novas regiões todos os meses. Consulte a busca para ver as clínicas próximas.",
  },
];

function Contact() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <header className="max-w-2xl">
        <h1 className="text-3xl sm:text-4xl">Fale com a gente</h1>
        <p className="mt-3 text-muted-foreground">
          Nossa equipe ajuda você a escolher o serviço certo, entender preparos de exames e resolver
          qualquer questão sobre agendamentos.
        </p>
      </header>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {channels.map(({ icon: Icon, label, value, note }) => (
          <div key={label} className="surface-card p-5">
            <span className="flex size-11 items-center justify-center rounded-2xl bg-secondary text-primary">
              <Icon className="size-5" />
            </span>
            <p className="mt-4 text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
              {label}
            </p>
            <p className="mt-1 text-sm font-extrabold">{value}</p>
            <p className="mt-1 text-xs font-semibold text-accent">{note}</p>
          </div>
        ))}
      </div>

      <div className="mt-10 grid gap-8 lg:grid-cols-2">
        <section className="surface-card p-7">
          <h2 className="text-xl">Envie sua dúvida</h2>
          <div className="mt-5 space-y-5">
            {[
              { id: "c-nome", label: "Nome", ph: "Como podemos te chamar?" },
              { id: "c-email", label: "E-mail", ph: "seu@email.com" },
              { id: "c-assunto", label: "Assunto", ph: "Ex.: preparo de exame" },
            ].map((f) => (
              <div key={f.id} className="space-y-2">
                <Label htmlFor={f.id} className="text-sm font-bold">
                  {f.label}
                </Label>
                <Input
                  id={f.id}
                  placeholder={f.ph}
                  className="h-11 rounded-2xl bg-secondary/50 font-semibold"
                />
              </div>
            ))}
            <div className="space-y-2">
              <Label htmlFor="c-msg" className="text-sm font-bold">
                Mensagem
              </Label>
              <Textarea
                id="c-msg"
                placeholder="Escreva sua dúvida com detalhes"
                className="min-h-32 rounded-2xl bg-secondary/50 font-semibold"
              />
            </div>
            <Button variant="cta" size="lg" className="w-full">
              Enviar mensagem
            </Button>
          </div>
        </section>

        <section>
          <h2 className="text-xl">Dúvidas frequentes</h2>
          <Accordion type="single" collapsible className="mt-4 space-y-3">
            {faqs.map((f, i) => (
              <AccordionItem
                key={f.q}
                value={`faq-${i}`}
                className="surface-card border-none px-5 py-1"
              >
                <AccordionTrigger className="text-left text-sm font-extrabold hover:no-underline">
                  {f.q}
                </AccordionTrigger>
                <AccordionContent className="text-sm leading-relaxed text-muted-foreground">
                  {f.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </section>
      </div>
    </div>
  );
}
