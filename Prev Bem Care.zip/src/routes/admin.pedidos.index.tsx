import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";

import { useAdmin } from "@/context/admin";
import { orderStatuses } from "@/data/admin-mock";
import { formatPrice } from "@/data/mock";
import { Input } from "@/components/ui/input";
import { StatusPill } from "@/routes/admin.index";

export const Route = createFileRoute("/admin/pedidos/")({
  component: AdminOrders,
});

function AdminOrders() {
  const { orders } = useAdmin();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<string>("todos");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return orders.filter((o) => {
      const matchesStatus = status === "todos" || o.status === status;
      const matchesQuery =
        !q ||
        o.patientName.toLowerCase().includes(q) ||
        o.number.toLowerCase().includes(q) ||
        o.phone.includes(q);
      return matchesStatus && matchesQuery;
    });
  }, [orders, query, status]);

  return (
    <div className="space-y-4">
      <section className="rounded-xl border border-border bg-card p-4">
        <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="relative w-full md:max-w-sm">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por paciente ou nº do pedido"
              className="h-9 pl-9 text-[13px]"
            />
          </div>
          <div className="flex flex-wrap gap-1.5">
            {["todos", ...orderStatuses].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatus(s)}
                className={`rounded-full px-3 py-1.5 text-[11.5px] font-extrabold transition-colors ${
                  status === s
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/70"
                }`}
              >
                {s === "todos" ? "Todos" : s}
                <span className="ml-1 opacity-70">
                  {s === "todos" ? orders.length : orders.filter((o) => o.status === s).length}
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[12.5px]">
            <thead className="border-b border-border text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="p-3 font-bold">Pedido</th>
                <th className="p-3 font-bold">Paciente</th>
                <th className="p-3 font-bold">WhatsApp</th>
                <th className="p-3 font-bold">Data</th>
                <th className="p-3 font-bold">Itens</th>
                <th className="p-3 font-bold">Total</th>
                <th className="p-3 font-bold">Status</th>
                <th className="p-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((o) => (
                <tr key={o.id} className="hover:bg-muted/60">
                  <td className="p-3 font-extrabold">{o.number}</td>
                  <td className="p-3 font-semibold">{o.patientName}</td>
                  <td className="p-3 text-muted-foreground">{o.phone}</td>
                  <td className="p-3 text-muted-foreground">
                    {new Date(o.createdAt).toLocaleDateString("pt-BR")}
                  </td>
                  <td className="p-3 text-muted-foreground">{o.items.length}</td>
                  <td className="p-3 font-bold">{formatPrice(o.total)}</td>
                  <td className="p-3">
                    <StatusPill status={o.status} />
                  </td>
                  <td className="p-3 text-right">
                    <Link
                      to="/admin/pedidos/$orderId"
                      params={{ orderId: o.id }}
                      className="font-bold text-primary hover:underline"
                    >
                      Abrir
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <p className="p-6 text-center text-[12.5px] font-semibold text-muted-foreground">
            Nenhum pedido encontrado com esses filtros.
          </p>
        )}
      </section>
    </div>
  );
}
