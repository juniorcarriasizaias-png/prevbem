import { createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  ChevronRight,
  ScanLine,
  Search,
  Stethoscope,
  Syringe,
  TestTube,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { ItemOfferingsDialog } from "@/components/item-offerings-dialog";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { useCart } from "@/context/cart";
import {
  activeCatalogItemsByCategoria,
  categoriaOrder,
  categoriaSearchPlaceholders,
  categoriaTabLabels,
  clinicById,
  formatPrice,
  offeringsByCatalogItem,
  type CatalogItem,
  type Categoria,
} from "@/data/mock";

export const Route = createFileRoute("/servicos/")({
  validateSearch: (search: Record<string, unknown>) => {
    const raw = search["categoria"];
    const valid =
      typeof raw === "string" && categoriaOrder.includes(raw as Categoria);
    return valid ? { categoria: raw as Categoria } : {};
  },
  head: () => ({
    meta: [
      { title: "Exames, consultas e cirurgias particulares em Teresina | Prev Bem" },
      {
        name: "description",
        content:
          "Navegue por exames de laboratório, exames de imagem, consultas e cirurgias em clínicas parceiras de Teresina-PI e compare o preço de cada clínica.",
      },
      {
        property: "og:title",
        content: "Catálogo de saúde por categoria | Prev Bem",
      },
      {
        property: "og:description",
        content:
          "Escolha a categoria, busque o serviço e compare os preços de cada clínica antes de agendar.",
      },
    ],
  }),
  component: Catalog,
});

const tabIcons: Record<Categoria, typeof TestTube> = {
  exame_laboratorial: TestTube,
  exame_imagem: ScanLine,
  consulta: Stethoscope,
  cirurgia: Syringe,
};

const normalize = (value: string) =>
  value
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");

function ItemRow({
  item,
  onSelect,
}: {
  item: CatalogItem;
  onSelect: (item: CatalogItem) => void;
}) {
  const offers = offeringsByCatalogItem(item.id);
  const best = offers[0];
  const clinicCount = new Set(offers.map((o) => o.clinicaId)).size;

  return (
    <button
      type="button"
      onClick={() => onSelect(item)}
      className="flex w-full items-center gap-4 rounded-2xl border border-border bg-card p-4 text-left shadow-sm transition hover:border-primary/40 hover:shadow-md"
    >
      <div className="min-w-0 flex-1 space-y-1">
        <p className="truncate text-sm font-extrabold text-foreground">{item.nome}</p>
        <p className="text-xs font-semibold text-muted-foreground">
          {item.especialidade ? `${item.especialidade} · ` : ""}
          {clinicCount} {clinicCount === 1 ? "clínica" : "clínicas"}
          {best?.prazoResultado ? ` · resultado ${best.prazoResultado}` : ""}
        </p>
      </div>
      <div className="shrink-0 text-right">
        <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
          a partir de
        </p>
        <p className="text-lg font-extrabold text-accent">
          {best ? formatPrice(best.preco) : "—"}
        </p>
      </div>
      <ChevronRight className="size-5 shrink-0 text-primary" />
    </button>
  );
}

function Catalog() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const categoria: Categoria =
    "categoria" in search ? search.categoria : "exame_laboratorial";
  const { add } = useCart();
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<CatalogItem | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  const items = useMemo(() => {
    const q = normalize(query.trim());
    return activeCatalogItemsByCategoria(categoria).filter(
      (i) =>
        !q ||
        normalize(i.nome).includes(q) ||
        normalize(i.especialidade ?? "").includes(q),
    );
  }, [categoria, query]);

  const grouped = useMemo(() => {
    const map = new Map<string, CatalogItem[]>();
    for (const item of items) {
      const key = item.especialidade ?? "Outros";
      map.set(key, [...(map.get(key) ?? []), item]);
    }
    return [...map.entries()].sort((a, b) => a[0].localeCompare(b[0], "pt-BR"));
  }, [items]);

  const isGrouped = categoria === "consulta" || categoria === "cirurgia";

  const handleSelect = (item: CatalogItem) => {
    const offers = offeringsByCatalogItem(item.id);
    if (offers.length === 1) {
      const offering = offers[0]!;
      add(offering.id);
      toast.success("Adicionado ao carrinho", {
        description: `${item.nome} — ${clinicById[offering.clinicaId]?.name ?? ""}`,
      });
      return;
    }
    setSelected(item);
    setDialogOpen(true);
  };

  return (
    <div className="mx-auto w-full max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <header className="space-y-3">
        <h1 className="text-3xl sm:text-4xl">O que você precisa hoje?</h1>
        <p className="max-w-2xl text-muted-foreground">
          Escolha a categoria, encontre o serviço e compare o preço de cada clínica parceira
          em Teresina-PI.
        </p>
      </header>

      {/* Abas de categoria */}
      <nav className="mt-8 grid grid-cols-2 gap-3 lg:grid-cols-4">
        {categoriaOrder.map((key) => {
          const Icon = tabIcons[key];
          const active = key === categoria;
          return (
            <button
              key={key}
              type="button"
              onClick={() => {
                setQuery("");
                void navigate({ to: "/servicos", search: { categoria: key } });
              }}
              className={`flex flex-col items-start gap-2 rounded-2xl border p-4 text-left transition ${
                active
                  ? "border-primary bg-primary text-primary-foreground shadow-md"
                  : "border-border bg-card text-foreground shadow-sm hover:border-primary/40"
              }`}
              aria-current={active ? "page" : undefined}
            >
              <span
                className={`flex size-10 items-center justify-center rounded-xl ${
                  active ? "bg-primary-foreground/15" : "bg-secondary text-primary"
                }`}
              >
                <Icon className="size-5" />
              </span>
              <span className="text-sm font-extrabold leading-tight">
                {categoriaTabLabels[key]}
              </span>
              <span
                className={`text-xs font-semibold ${
                  active ? "text-primary-foreground/80" : "text-muted-foreground"
                }`}
              >
                {activeCatalogItemsByCategoria(key).length} opções
              </span>
            </button>
          );
        })}
      </nav>

      {/* Busca da categoria ativa */}
      <div className="surface-card mt-6 p-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={categoriaSearchPlaceholders[categoria]}
            className="h-12 rounded-full border-none bg-secondary/60 pl-12 font-semibold"
            aria-label={categoriaSearchPlaceholders[categoria]}
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              aria-label="Limpar busca"
              className="absolute right-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-primary"
            >
              <X className="size-4" />
            </button>
          )}
        </div>
      </div>

      <p className="mt-6 text-sm font-bold text-muted-foreground">
        {items.length} {items.length === 1 ? "item encontrado" : "itens encontrados"} em{" "}
        {categoriaTabLabels[categoria]}
      </p>

      {items.length === 0 ? (
        <div className="surface-card mt-4 p-8 text-center">
          <p className="text-base font-extrabold">Nada encontrado por aqui</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Tente outro termo ou escolha outra categoria acima.
          </p>
        </div>
      ) : isGrouped ? (
        <Accordion
          type="multiple"
          defaultValue={grouped.map(([spec]) => spec)}
          className="mt-4 space-y-3"
        >
          {grouped.map(([spec, list]) => (
            <AccordionItem
              key={spec}
              value={spec}
              className="surface-card border-none px-4"
            >
              <AccordionTrigger className="text-sm font-extrabold text-primary hover:no-underline">
                {spec}
                <span className="ml-auto mr-2 text-xs font-bold text-muted-foreground">
                  {list.length}
                </span>
              </AccordionTrigger>
              <AccordionContent className="space-y-3 pb-4">
                {list.map((item) => (
                  <ItemRow key={item.id} item={item} onSelect={handleSelect} />
                ))}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      ) : (
        <div className="mt-4 space-y-3">
          {items.map((item) => (
            <ItemRow key={item.id} item={item} onSelect={handleSelect} />
          ))}
        </div>
      )}

      <ItemOfferingsDialog
        item={selected}
        open={dialogOpen}
        onOpenChange={setDialogOpen}
      />
    </div>
  );
}
