import { createFileRoute } from "@tanstack/react-router";
import { Download, TrendingUp } from "lucide-react";
import { useMemo, useState } from "react";
import { toast } from "sonner";

import { PartnerCard, PartnerSectionTitle, StatusPill } from "@/components/partner/partner-ui";
import { Button } from "@/components/ui/button";
import { usePartner } from "@/context/partner";
import { formatPrice } from "@/data/mock";

export const Route = createFileRoute("/parceiro/faturamento")({
  component: PartnerBilling,
});

const periods = [
  { value: "7", label: "Últimos 7 dias" },
  { value: "30", label: "Últimos 30 dias" },
  { value: "90", label: "Últimos 90 dias" },
  { value: "all", label: "Todo o período" },
] as const;

const monthLabel = (iso: string) =>
  new Date(iso).toLocaleDateString("pt-BR", { month: "short", year: "numeric" });

function PartnerBilling() {
  const { orders, clinic } = usePartner();
  const [period, setPeriod] = useState<string>("30");

  const filtered = useMemo(() => {
    if (period === "all") return orders;
    const days = Number(period);
    const limit = Date.now() - days * 86_400_000;
    return orders.filter((o) => new Date(o.createdAt).getTime() >= limit);
  }, [orders, period]);

  const totals = useMemo(() => {
    const sum = (list: typeof filtered) => list.reduce((s, o) => s + o.clinicTotal, 0);
    const confirmed = filtered.filter((o) => o.status === "Confirmado" || o.status === "Concluído");
    const waiting = filtered.filter((o) => o.status === "Aguardando pagamento");
    const canceled = filtered.filter((o) => o.status === "Cancelado");
    const realized = sum(confirmed);
    return {
      gross: sum(filtered),
      realized,
      waiting: sum(waiting),
      canceled: sum(canceled),
      count: filtered.length,
      ticket: confirmed.length ? realized / confirmed.length : 0,
    };
  }, [filtered]);

  const byMonth = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of filtered) {
      if (o.status === "Cancelado") continue;
      const key = monthLabel(o.createdAt);
      map.set(key, (map.get(key) ?? 0) + o.clinicTotal);
    }
    return [...map.entries()].reverse();
  }, [filtered]);

  const max = Math.max(1, ...byMonth.map(([, v]) => v));

  const exportCsv = () => {
    const rows = [
      ["Pedido", "Paciente", "Data", "Status", "Valor da clínica"],
      ...filtered.map((o) => [
        o.number,
        o.patientName,
        new Date(o.createdAt).toLocaleDateString("pt-BR"),
        o.status,
        String(o.clinicTotal).replace(".", ","),
      ]),
    ];
    const csv = rows.map((r) => r.map((c) => `"${c}"`).join(";")).join("\n");
    const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
    const link = document.createElement("a");
    link.href = url;
    link.download = `faturamento-prevbem-${clinic?.id ?? "clinica"}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Relatório exportado em CSV.");
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">Faturamento pela Prev Bem</h1>
          <p className="text-sm font-semibold text-muted-foreground">
            Valores dos agendamentos da {clinic?.name} gerados pela plataforma.
          </p>
        </div>
        <Button variant="soft" size="sm" onClick={exportCsv}>
          <Download /> Exportar CSV
        </Button>
      </div>

      <div className="flex gap-1 overflow-x-auto">
        {periods.map((p) => (
          <button
            key={p.value}
            type="button"
            onClick={() => setPeriod(p.value)}
            className={`shrink-0 rounded-lg px-3 py-1.5 text-[12px] font-bold transition-colors ${
              period === p.value
                ? "bg-primary text-primary-foreground"
                : "bg-secondary text-muted-foreground hover:text-primary"
            }`}
          >
            {p.label}
          </button>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Faturamento realizado", value: formatPrice(totals.realized), tone: "text-success" },
          { label: "A receber (aguardando)", value: formatPrice(totals.waiting), tone: "text-accent" },
          { label: "Ticket médio", value: formatPrice(totals.ticket), tone: "text-primary" },
          { label: "Agendamentos", value: String(totals.count), tone: "text-foreground" },
        ].map((m) => (
          <PartnerCard key={m.label} className="p-4">
            <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              {m.label}
            </p>
            <p className={`mt-2 text-2xl font-extrabold ${m.tone}`}>{m.value}</p>
          </PartnerCard>
        ))}
      </div>

      <PartnerCard className="p-5">
        <PartnerSectionTitle
          title="Evolução por mês"
          action={
            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-muted-foreground">
              <TrendingUp className="size-3.5 text-success" /> Bruto: {formatPrice(totals.gross)}
            </span>
          }
        />
        <ul className="mt-4 space-y-3">
          {byMonth.map(([label, value]) => (
            <li key={label}>
              <div className="flex items-baseline justify-between gap-2">
                <p className="text-[12px] font-bold capitalize">{label}</p>
                <p className="text-[12px] font-extrabold text-primary">{formatPrice(value)}</p>
              </div>
              <div className="mt-1 h-2 rounded-full bg-secondary">
                <div
                  className="h-2 rounded-full bg-primary"
                  style={{ width: `${Math.max(6, (value / max) * 100)}%` }}
                />
              </div>
            </li>
          ))}
          {byMonth.length === 0 && (
            <li className="py-6 text-center text-[12px] font-semibold text-muted-foreground">
              Nenhum faturamento neste período.
            </li>
          )}
        </ul>
      </PartnerCard>

      <PartnerCard className="p-5">
        <PartnerSectionTitle title="Detalhamento" />
        <div className="mt-3 overflow-x-auto">
          <table className="w-full text-left text-[12px]">
            <thead>
              <tr className="border-b border-border text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                <th className="py-2 pr-3">Pedido</th>
                <th className="py-2 pr-3">Paciente</th>
                <th className="py-2 pr-3">Data</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 text-right">Valor</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((o) => (
                <tr key={o.id} className="border-b border-border/60">
                  <td className="py-2 pr-3 font-extrabold">{o.number}</td>
                  <td className="py-2 pr-3 font-semibold">{o.patientName}</td>
                  <td className="py-2 pr-3 font-semibold text-muted-foreground">
                    {new Date(o.createdAt).toLocaleDateString("pt-BR")}
                  </td>
                  <td className="py-2 pr-3">
                    <StatusPill status={o.status} />
                  </td>
                  <td className="py-2 text-right font-extrabold">{formatPrice(o.clinicTotal)}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <p className="py-6 text-center text-[12px] font-semibold text-muted-foreground">
              Sem registros no período selecionado.
            </p>
          )}
        </div>
        {totals.canceled > 0 && (
          <p className="mt-3 text-[11px] font-semibold text-muted-foreground">
            {formatPrice(totals.canceled)} em pedidos cancelados não entram no faturamento.
          </p>
        )}
      </PartnerCard>
    </div>
  );
}
