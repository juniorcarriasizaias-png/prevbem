import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Pencil, Plus, Search, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { useAdmin, type AdminService } from "@/context/admin";
import { usePriceSuggestions } from "@/context/price-suggestions";
import { categoryLabels, clinicById, formatPrice, specialties, type ServiceCategory } from "@/data/mock";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/admin/catalogo")({
  component: AdminCatalog,
});

const slug = (name: string) =>
  name
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "") || `servico-${Date.now()}`;

const emptyService = (clinicId: string): AdminService => ({
  id: "",
  name: "",
  category: "consulta",
  specialty: specialties[0]!,
  clinicId,
  listPrice: 0,
  price: 0,
  rating: 5,
  reviews: 0,
  duration: "30 min",
  demand: 50,
  description: "",
  available: true,
});

function AdminCatalog() {
  const { services, clinics, saveService, deleteService } = useAdmin();
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("todas");
  const [draft, setDraft] = useState<AdminService | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return services.filter(
      (s) =>
        (category === "todas" || s.category === category) &&
        (!q || s.name.toLowerCase().includes(q) || s.specialty.toLowerCase().includes(q)),
    );
  }, [services, query, category]);

  return (
    <div className="space-y-4">
      <PriceSuggestionsPanel />
      <section className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 md:flex-row md:items-center md:justify-between">
        <div className="relative w-full md:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar serviço ou especialidade"
            className="h-9 pl-9 text-[13px]"
          />
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {["todas", ...Object.keys(categoryLabels)].map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCategory(c)}
              className={`rounded-full px-3 py-1.5 text-[11.5px] font-extrabold ${
                category === c
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/70"
              }`}
            >
              {c === "todas" ? "Todas" : categoryLabels[c as ServiceCategory]}
            </button>
          ))}
          <Button
            variant="cta"
            size="sm"
            className="h-8 gap-1.5 text-[12px]"
            onClick={() => setDraft(emptyService(clinics[0]?.id ?? ""))}
          >
            <Plus className="size-3.5" /> Novo serviço
          </Button>
        </div>
      </section>

      <section className="rounded-xl border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[12.5px]">
            <thead className="border-b border-border text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="p-3 font-bold">Serviço</th>
                <th className="p-3 font-bold">Categoria</th>
                <th className="p-3 font-bold">Especialidade</th>
                <th className="p-3 font-bold">Clínica</th>
                <th className="p-3 font-bold">Tabela</th>
                <th className="p-3 font-bold">Prev Bem</th>
                <th className="p-3 font-bold">Disponível</th>
                <th className="p-3" />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((s) => (
                <tr key={s.id} className="hover:bg-muted/60">
                  <td className="p-3 font-bold">{s.name}</td>
                  <td className="p-3 text-muted-foreground">{categoryLabels[s.category]}</td>
                  <td className="p-3 text-muted-foreground">{s.specialty}</td>
                  <td className="p-3 text-muted-foreground">
                    {clinics.find((c) => c.id === s.clinicId)?.name ?? "—"}
                  </td>
                  <td className="p-3 text-muted-foreground line-through">
                    {formatPrice(s.listPrice)}
                  </td>
                  <td className="p-3 font-extrabold text-accent">{formatPrice(s.price)}</td>
                  <td className="p-3">
                    <Toggle
                      checked={s.available}
                      onChange={(checked) => saveService({ ...s, available: checked })}
                    />
                  </td>
                  <td className="p-3">
                    <div className="flex justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2"
                        onClick={() => setDraft(s)}
                      >
                        <Pencil className="size-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-7 px-2 text-destructive"
                        onClick={() => {
                          deleteService(s.id);
                          toast.success("Serviço removido do catálogo.");
                        }}
                      >
                        <Trash2 className="size-3.5" />
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <p className="p-6 text-center text-[12.5px] font-semibold text-muted-foreground">
            Nenhum serviço encontrado.
          </p>
        )}
      </section>

      <Dialog open={Boolean(draft)} onOpenChange={(open) => !open && setDraft(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-base">
              {draft?.id ? "Editar serviço" : "Novo serviço"}
            </DialogTitle>
          </DialogHeader>
          {draft && (
            <form
              className="space-y-3 text-[13px]"
              onSubmit={(e) => {
                e.preventDefault();
                if (!draft.name.trim()) return;
                saveService({ ...draft, id: draft.id || slug(draft.name) });
                setDraft(null);
                toast.success("Catálogo atualizado.");
              }}
            >
              <div className="space-y-1.5">
                <Label className="text-[12px]">Nome</Label>
                <Input
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                  required
                />
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Categoria</Label>
                  <select
                    value={draft.category}
                    onChange={(e) =>
                      setDraft({ ...draft, category: e.target.value as ServiceCategory })
                    }
                    className="h-9 w-full rounded-md border border-input bg-background px-2 text-[13px]"
                  >
                    {Object.entries(categoryLabels).map(([value, label]) => (
                      <option key={value} value={value}>
                        {label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Especialidade</Label>
                  <select
                    value={draft.specialty}
                    onChange={(e) => setDraft({ ...draft, specialty: e.target.value })}
                    className="h-9 w-full rounded-md border border-input bg-background px-2 text-[13px]"
                  >
                    {specialties.map((s) => (
                      <option key={s} value={s}>
                        {s}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Clínica</Label>
                <select
                  value={draft.clinicId}
                  onChange={(e) => setDraft({ ...draft, clinicId: e.target.value })}
                  className="h-9 w-full rounded-md border border-input bg-background px-2 text-[13px]"
                >
                  {clinics.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Preço de tabela</Label>
                  <Input
                    type="number"
                    min={0}
                    value={draft.listPrice}
                    onChange={(e) => setDraft({ ...draft, listPrice: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Preço Prev Bem</Label>
                  <Input
                    type="number"
                    min={0}
                    value={draft.price}
                    onChange={(e) => setDraft({ ...draft, price: Number(e.target.value) })}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[12px]">Duração</Label>
                  <Input
                    value={draft.duration}
                    onChange={(e) => setDraft({ ...draft, duration: e.target.value })}
                  />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[12px]">Descrição</Label>
                <Textarea
                  rows={3}
                  value={draft.description}
                  onChange={(e) => setDraft({ ...draft, description: e.target.value })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg bg-muted p-3">
                <span className="text-[12.5px] font-bold">Disponível para agendamento</span>
                <Toggle
                  checked={draft.available}
                  onChange={(checked) => setDraft({ ...draft, available: checked })}
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" size="sm" onClick={() => setDraft(null)}>
                  Cancelar
                </Button>
                <Button type="submit" variant="cta" size="sm">
                  Salvar serviço
                </Button>
              </DialogFooter>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Sugestões de preço enviadas pelas clínicas no portal do parceiro. */
function PriceSuggestionsPanel() {
  const { pending, reviewSuggestion } = usePriceSuggestions();
  const { services, saveService } = useAdmin();

  if (pending.length === 0) return null;

  const approve = (id: string) => {
    const suggestion = pending.find((s) => s.id === id);
    if (!suggestion) return;
    const service = services.find((s) => s.id === suggestion.serviceId);
    if (service) {
      saveService({
        ...service,
        price: suggestion.suggestedPrice,
        listPrice: suggestion.suggestedListPrice,
      });
    }
    reviewSuggestion(id, "Aprovada", "Preço aprovado pela equipe Prev Bem.");
    toast.success("Preço aprovado e publicado no catálogo.");
  };

  return (
    <section className="rounded-xl border border-accent/40 bg-accent-soft/40 p-4">
      <h2 className="text-[12px] font-extrabold uppercase tracking-wider text-accent">
        Sugestões de preço aguardando aprovação ({pending.length})
      </h2>
      <ul className="mt-3 space-y-2">
        {pending.map((s) => (
          <li
            key={s.id}
            className="flex flex-wrap items-center justify-between gap-3 rounded-lg bg-card p-3"
          >
            <div className="min-w-0">
              <p className="text-[13px] font-extrabold">{s.serviceName}</p>
              <p className="text-[11px] font-semibold text-muted-foreground">
                {clinicById[s.clinicId]?.name ?? s.clinicId} · {formatPrice(s.currentPrice)} →{" "}
                <strong className="text-accent">{formatPrice(s.suggestedPrice)}</strong>
                {s.note ? ` · "${s.note}"` : ""}
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                className="h-8 text-[12px]"
                onClick={() => {
                  reviewSuggestion(s.id, "Recusada", "Sugestão recusada pela equipe Prev Bem.");
                  toast.success("Sugestão recusada.");
                }}
              >
                Recusar
              </Button>
              <Button variant="cta" size="sm" className="h-8 text-[12px]" onClick={() => approve(s.id)}>
                Aprovar
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Toggle({ checked, onChange }: { checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`inline-flex h-5 w-9 shrink-0 items-center rounded-full border transition-colors ${
        checked ? "border-primary bg-primary" : "border-input bg-muted"
      }`}
    >
      <span
        className={`ml-0.5 size-4 rounded-full bg-background shadow transition-transform ${
          checked ? "translate-x-4" : "translate-x-0"
        }`}
      />
    </button>
  );
}
