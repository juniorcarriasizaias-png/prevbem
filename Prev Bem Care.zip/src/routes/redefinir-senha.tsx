import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { KeyRound, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/auth";

export const Route = createFileRoute("/redefinir-senha")({
  head: () => ({
    meta: [
      { title: "Criar nova senha | Prev Bem" },
      {
        name: "description",
        content: "Defina uma nova senha para acessar sua conta Prev Bem com segurança.",
      },
      { property: "og:title", content: "Criar nova senha | Prev Bem" },
      {
        property: "og:description",
        content: "Página segura para redefinir a senha da sua conta Prev Bem.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: ResetPassword,
});

function ResetPassword() {
  const { updatePassword, ready, session } = useAuth();
  const navigate = useNavigate();
  const [senha, setSenha] = useState("");
  const [confirma, setConfirma] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (senha.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres.");
      return;
    }
    if (senha !== confirma) {
      toast.error("As senhas não são iguais.");
      return;
    }
    setLoading(true);
    const { error } = await updatePassword(senha);
    setLoading(false);
    if (error) {
      toast.error(`Não foi possível atualizar a senha: ${error}`);
      return;
    }
    toast.success("Senha atualizada com sucesso!");
    void navigate({ to: "/minha-conta" });
  };

  return (
    <div className="mx-auto w-full max-w-md px-4 py-16 sm:px-6">
      <div className="surface-card space-y-5 p-7">
        <div>
          <h1 className="text-2xl">Criar nova senha</h1>
          <p className="mt-1 text-sm font-semibold text-muted-foreground">
            {ready && !session
              ? "Abra esta página pelo link enviado no seu e-mail para redefinir a senha."
              : "Escolha uma nova senha para a sua conta Prev Bem."}
          </p>
        </div>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="space-y-1.5">
            <Label htmlFor="nova-senha">Nova senha</Label>
            <Input
              id="nova-senha"
              type="password"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              autoComplete="new-password"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="confirma-senha">Confirmar nova senha</Label>
            <Input
              id="confirma-senha"
              type="password"
              value={confirma}
              onChange={(e) => setConfirma(e.target.value)}
              autoComplete="new-password"
              required
            />
          </div>
          <Button type="submit" variant="cta" className="h-12 w-full" disabled={loading}>
            {loading ? <Loader2 className="animate-spin" /> : <KeyRound />}
            Salvar nova senha
          </Button>
        </form>
      </div>
    </div>
  );
}
