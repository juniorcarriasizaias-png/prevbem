import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BadgeCheck,
  Gift,
  Sparkles,
  Search,
  Stethoscope,
  TestTube,
  Syringe,
  ScanLine,
  ShieldCheck,
  Wallet,
  CalendarCheck,
  Star,
  ArrowRight,
} from "lucide-react";

import heroImage from "@/assets/hero-clinic.jpg";
import { ServiceCard } from "@/components/service-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  activeCatalogItemsByCategoria,
  categoriaOrder,
  categoriaTabLabels,
  services,
  type Categoria,
} from "@/data/mock";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Prev Bem — Consultas e exames particulares com preço justo" },
      {
        name: "description",
        content:
          "Agende consultas, exames e procedimentos particulares em clínicas parceiras com preços transparentes e sem convênio. Simples, rápido e acolhedor.",
      },
      { property: "og:title", content: "Prev Bem — Saúde particular com preço justo" },
      {
        property: "og:description",
        content:
          "Marketplace de saúde para pacientes particulares: consultas, exames e procedimentos com preços transparentes.",
      },
    ],
  }),
  component: Home,
});

const categoryIcons = {
  exame_laboratorial: TestTube,
  exame_imagem: ScanLine,
  consulta: Stethoscope,
  cirurgia: Syringe,
} as const;

const categoryDescriptions: Record<Categoria, string> = {
  exame_laboratorial: "Sangue, urina, hormônios e check-ups completos",
  exame_imagem: "Ultrassom, raio-X, tomografia, ressonância e mais",
  consulta: "Especialidades médicas com preço fechado",
  cirurgia: "Procedimentos e cirurgias eletivas em hospital-dia",
};

const categories = categoriaOrder.map((categoria) => ({
  categoria,
  icon: categoryIcons[categoria],
  title: categoriaTabLabels[categoria],
  desc: categoryDescriptions[categoria],
  count: `${activeCatalogItemsByCategoria(categoria).length} opções`,
}));

const proofs = [
  { value: "320 mil", label: "pacientes atendidos" },
  { value: "1.400", label: "clínicas e laboratórios parceiros" },
  { value: "até 70%", label: "de economia vs. preço de tabela" },
  { value: "4,9/5", label: "avaliação média dos pacientes" },
];

const steps = [
  {
    icon: Search,
    title: "Encontre",
    desc: "Busque a especialidade ou exame e compare preços de clínicas próximas.",
  },
  {
    icon: Wallet,
    title: "Escolha",
    desc: "Preço final visível antes de agendar. Sem taxas escondidas.",
  },
  {
    icon: CalendarCheck,
    title: "Agende",
    desc: "Selecione data e horário e receba a confirmação na sua área do paciente.",
  },
];

function Home() {
  const highlights = services.filter((s) => s.popular).slice(0, 4);
  const popular = [...services].sort((a, b) => b.demand - a.demand).slice(0, 8);

  return (
    <div>
      {/* Hero */}
      <section className="hero-gradient">
        <div className="mx-auto grid w-full max-w-7xl items-center gap-12 px-4 py-14 sm:px-6 lg:grid-cols-2 lg:px-8 lg:py-20">
          <div className="space-y-7">
            <span className="inline-flex items-center gap-2 rounded-full border-2 border-accent/30 bg-background px-4 py-2 text-xs font-extrabold uppercase tracking-wide text-accent shadow-soft">
              <ShieldCheck className="size-4" /> Sem mensalidade · sem carência
            </span>
            <h1 className="text-4xl leading-tight text-foreground sm:text-5xl">
              Cuidar da sua saúde ficou <span className="text-primary">simples e acessível</span>
            </h1>
            <p className="max-w-lg text-lg leading-relaxed text-muted-foreground">
              Consultas, exames e procedimentos particulares com preço justo em clínicas parceiras
              perto de você. Você escolhe, agenda e pronto.
            </p>

            <div className="surface-card flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Search className="pointer-events-none absolute left-4 top-1/2 size-5 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Qual especialidade ou exame você precisa?"
                  className="h-13 rounded-full border-none bg-secondary/60 pl-12 text-base font-semibold placeholder:font-medium"
                  aria-label="Buscar especialidade ou exame"
                />
              </div>
              <Button variant="cta" size="lg" asChild>
                <Link to="/servicos">Buscar</Link>
              </Button>
            </div>


          </div>

          <div className="relative">
            <img
              src={heroImage}
              alt="Médica sorrindo durante consulta com paciente em clínica parceira da Prev Bem"
              width={1408}
              height={1104}
              className="w-full rounded-3xl object-cover shadow-card"
            />
            <div className="surface-card absolute -bottom-6 left-4 hidden items-center gap-3 p-4 sm:flex">
              <span className="flex size-11 items-center justify-center rounded-2xl bg-accent-soft text-accent">
                <Star className="size-5 fill-accent" />
              </span>
              <div>
                <p className="text-sm font-extrabold text-foreground">4,9 de 5</p>
                <p className="text-xs font-semibold text-muted-foreground">
                  em 28 mil avaliações reais
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Selo sem mensalidade / sem carência */}
      <section className="mx-auto w-full max-w-7xl px-4 pt-12 sm:px-6 lg:px-8">
        <div className="surface-card flex flex-col items-center gap-6 border-2 border-accent/25 p-7 text-center sm:flex-row sm:text-left">
          <span className="flex size-16 shrink-0 items-center justify-center rounded-3xl bg-accent-soft text-accent">
            <BadgeCheck className="size-8" />
          </span>
          <div className="flex-1">
            <p className="text-xs font-extrabold uppercase tracking-widest text-accent">
              Selo Prev Bem
            </p>
            <h2 className="mt-1 text-2xl">Sem mensalidade, sem carência</h2>
            <p className="mt-2 text-sm font-semibold text-muted-foreground">
              Você não paga nada para usar a plataforma e não existe tempo de espera: escolhe hoje,
              agenda hoje. Acesso imediato, sem burocracia e sem contrato.
            </p>
          </div>
          <div className="flex flex-wrap justify-center gap-2">
            {["Acesso imediato", "Sem contrato", "Preço final visível"].map((t) => (
              <span
                key={t}
                className="rounded-full bg-secondary px-4 py-1.5 text-xs font-extrabold text-primary"
              >
                {t}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Prova social */}
      <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {proofs.map((p) => (
            <div key={p.label} className="surface-card p-6 text-center">
              <dt className="text-3xl font-extrabold text-primary">{p.value}</dt>
              <dd className="mt-1 text-sm font-semibold text-muted-foreground">{p.label}</dd>
            </div>
          ))}
        </dl>
      </section>

      {/* Categorias */}
      <section className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl">Escolha por categoria</h2>
        <p className="mt-2 text-muted-foreground">
          As mesmas quatro abas do catálogo: toque e veja tudo o que está disponível.
        </p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {categories.map(({ icon: Icon, title, categoria, desc, count }) => (
            <Link
              key={title}
              to="/servicos"
              search={{ categoria }}
              className="surface-card group p-6"
            >
              <span className="brand-gradient flex size-12 items-center justify-center rounded-2xl text-primary-foreground">
                <Icon className="size-6" />
              </span>
              <h3 className="mt-5 text-lg">{title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{desc}</p>
              <p className="mt-4 inline-flex items-center gap-1.5 text-sm font-extrabold text-accent">
                {count}
                <ArrowRight className="size-4 transition-transform group-hover:translate-x-1" />
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* Banner destaque */}
      <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="brand-gradient flex flex-col items-start gap-6 rounded-3xl p-8 text-primary-foreground sm:p-12 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl space-y-3">
            <span className="rounded-full bg-primary-foreground/15 px-4 py-1.5 text-xs font-extrabold uppercase tracking-wide">
              Campanha de prevenção
            </span>
            <h2 className="text-3xl text-primary-foreground">
              Check-up completo a partir de R$ 149
            </h2>
            <p className="text-primary-foreground/80">
              Oito exames essenciais para acompanhar sua saúde, com coleta em laboratórios parceiros
              e resultado digital em 24 horas.
            </p>
          </div>
          <Button variant="cta" size="lg" asChild>
            <Link to="/servicos/$serviceId" params={{ serviceId: "check-up-basico" }}>
              Ver o pacote
            </Link>
          </Button>
        </div>
      </section>

      {/* Ofertas */}
      <section className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl sm:text-3xl">Ofertas em destaque</h2>
            <p className="mt-2 text-muted-foreground">Preços especiais nas clínicas parceiras.</p>
          </div>
          <Button variant="outline" asChild>
            <Link to="/servicos">Ver tudo</Link>
          </Button>
        </div>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {highlights.map((s) => (
            <ServiceCard key={s.id} service={s} />
          ))}
        </div>
      </section>

      {/* Clube de Vantagens */}
      <section className="mx-auto w-full max-w-7xl px-4 pt-16 sm:px-6 lg:px-8">
        <div className="surface-card grid gap-8 p-8 sm:p-10 lg:grid-cols-[1.1fr_1fr]">
          <div className="space-y-4">
            <span className="inline-flex items-center gap-2 rounded-full bg-accent-soft px-4 py-1.5 text-xs font-extrabold uppercase tracking-wide text-accent">
              <Sparkles className="size-4" /> Clube de Vantagens · grátis
            </span>
            <h2 className="text-2xl sm:text-3xl">Cadastre-se e ganhe vantagens em cada cuidado</h2>
            <p className="text-muted-foreground">
              Descontos que crescem a cada agendamento, cupons para indicar amigos e cashback
              simbólico para usar no próximo atendimento — tudo sem mensalidade.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button variant="cta" asChild>
                <Link to="/clube">Ver o clube</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link to="/indicacao">
                  <Gift className="size-4" /> Indique e ganhe
                </Link>
              </Button>
            </div>
          </div>
          <ul className="grid gap-3 sm:grid-cols-2">
            {[
              { title: "Até 12%", desc: "de desconto progressivo" },
              { title: "2% de cashback", desc: "no próximo agendamento" },
              { title: "R$ 25", desc: "de crédito por indicação" },
              { title: "15% off", desc: "para o amigo indicado" },
            ].map((b) => (
              <li key={b.title} className="rounded-2xl bg-secondary/70 p-5">
                <p className="text-xl font-extrabold text-primary">{b.title}</p>
                <p className="mt-1 text-sm font-semibold text-muted-foreground">{b.desc}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Como funciona */}
      <section className="mx-auto w-full max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-primary-soft/60 p-8 sm:p-12">
          <h2 className="text-2xl sm:text-3xl">Como funciona</h2>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {steps.map(({ icon: Icon, title, desc }, i) => (
              <div key={title} className="rounded-2xl bg-background p-6 shadow-soft">
                <span className="flex size-11 items-center justify-center rounded-2xl bg-accent-soft text-accent">
                  <Icon className="size-5" />
                </span>
                <p className="mt-4 text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
                  Passo {i + 1}
                </p>
                <h3 className="mt-1 text-lg">{title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
              </div>
            ))}
          </div>
          <Button variant="cta" size="lg" asChild className="mt-8">
            <Link to="/como-funciona">Entender melhor</Link>
          </Button>
        </div>
      </section>

      {/* Mais buscados */}
      <section className="mx-auto w-full max-w-7xl px-4 pb-8 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl">Mais buscados na Prev Bem</h2>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {popular.map((s) => (
            <ServiceCard key={s.id} service={s} />
          ))}
        </div>
      </section>
    </div>
  );
}
