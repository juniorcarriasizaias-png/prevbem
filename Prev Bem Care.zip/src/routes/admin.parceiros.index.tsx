import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Building2, Download, Plus, Search } from "lucide-react";
import { toast } from "sonner";

import { useCatalogAdmin } from "@/context/catalog-admin";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export const Route = createFileRoute("/admin/parceiros/")({
  component: AdminPartners,
});

function AdminPartners() {
  const { clinicas, offerings, exportFullCatalogCsv } = useCatalogAdmin();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return clinicas
      .map((clinica) => {
        const own = offerings.filter((o) => o.clinicaId === clinica.id);
        return {
          clinica,
          total: own.length,
          ativos: own.filter((o) => o.ativo).length,
        };
      })
      .filter(
        ({ clinica }) =>
          !q ||
          clinica.nome.toLowerCase().includes(q) ||
          clinica.endereco.toLowerCase().includes(q),
      );
  }, [clinicas, offerings, query]);

  const exportCsv = () => {
    const csv = exportFullCatalogCsv();
    const blob = new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `prevbem-catalogo-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    toast.success("Catálogo completo exportado em CSV.");
  };

  return (
    <div className="space-y-4">
      <section className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-sm font-extrabold">Parceiros e Catálogo</h1>
          <p className="text-[12px] font-semibold text-muted-foreground">
            {clinicas.length} clínicas parceiras · {offerings.filter((o) => o.ativo).length}{" "}
            ofertas ativas na plataforma
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full sm:w-64">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar clínica"
              className="h-9 pl-9 text-[13px]"
            />
          </div>
          <Button variant="outline" size="sm" className="h-9 gap-1.5 text-[12px]" onClick={exportCsv}>
            <Download className="size-3.5" /> Exportar catálogo completo
          </Button>
          <Button
            variant="cta"
            size="sm"
            className="h-9 gap-1.5 text-[12px]"
            onClick={() => navigate({ to: "/admin/parceiros/novo" })}
          >
            <Plus className="size-3.5" /> Nova clínica
          </Button>

        </div>
      </section>

      <section className="rounded-xl border border-border bg-card">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-[12.5px]">
            <thead className="border-b border-border text-[11px] uppercase tracking-wide text-muted-foreground">
              <tr>
                <th className="p-3 font-bold">Clínica</th>
                <th className="p-3 font-bold">Endereço</th>
                <th className="p-3 font-bold">Telefone</th>
                <th className="p-3 font-bold">Serviços ativos</th>
                <th className="p-3 font-bold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map(({ clinica, total, ativos }) => (
                <tr
                  key={clinica.id}
                  className="cursor-pointer hover:bg-muted/60"
                  onClick={() =>
                    navigate({
                      to: "/admin/parceiros/$clinicaId",
                      params: { clinicaId: clinica.id },
                    })
                  }
                >
                  <td className="p-3">
                    <div className="flex items-center gap-2 font-bold">
                      <span className="grid size-7 shrink-0 place-items-center rounded-lg bg-primary-soft text-primary">
                        <Building2 className="size-3.5" />
                      </span>
                      {clinica.nome}
                    </div>
                  </td>
                  <td className="p-3 text-muted-foreground">{clinica.endereco}</td>
                  <td className="p-3 text-muted-foreground">{clinica.telefone ?? "—"}</td>
                  <td className="p-3 font-extrabold text-accent">
                    {ativos}
                    <span className="font-semibold text-muted-foreground"> / {total}</span>
                  </td>
                  <td className="p-3">
                    <span
                      className={`inline-block rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide ${
                        clinica.ativo
                          ? "bg-success/12 text-success"
                          : "bg-destructive/10 text-destructive"
                      }`}
                    >
                      {clinica.ativo ? "Ativo" : "Inativo"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {rows.length === 0 && (
          <p className="p-6 text-center text-[12.5px] font-semibold text-muted-foreground">
            Nenhuma clínica encontrada.
          </p>
        )}
      </section>

    </div>
  );
}
