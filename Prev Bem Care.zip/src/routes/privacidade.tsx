import { createFileRoute, Link } from "@tanstack/react-router";
import { Database, MessageCircle, ShieldCheck, Share2, UserCheck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { buildWhatsAppUrl, WHATSAPP_DISPLAY } from "@/config/contact";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title: "Política de Privacidade | Prev Bem" },
      {
        name: "description",
        content:
          "Entenda de forma simples quais dados a Prev Bem coleta, para que usa, com quem compartilha e como você exerce seus direitos previstos na LGPD.",
      },
      { property: "og:title", content: "Política de Privacidade | Prev Bem" },
      {
        property: "og:description",
        content: "Transparência total sobre o uso dos seus dados na Prev Bem, conforme a LGPD.",
      },
    ],
  }),
  component: PrivacyPage,
});

const sections = [
  {
    icon: Database,
    title: "Quais dados coletamos",
    body: [
      "Nome completo de quem vai ser atendido (e o seu, se o agendamento for para outra pessoa).",
      "Telefone / WhatsApp, para combinarmos o pagamento e confirmarmos o atendimento.",
      "Histórico de agendamentos e pedidos: serviços escolhidos, clínica, valores e datas.",
      "Observações que você escrever no pedido (por exemplo, preferência de horário).",
      "Dados técnicos básicos de navegação (cookies), para o site funcionar e melhorar.",
    ],
  },
  {
    icon: UserCheck,
    title: "Para que usamos",
    body: [
      "Viabilizar o seu agendamento na clínica ou laboratório parceiro.",
      "Entrar em contato com você por WhatsApp para confirmar o pedido e o pagamento.",
      "Manter o seu histórico na área do paciente, para você consultar quando quiser.",
      "Enviar avisos sobre o seu atendimento (confirmação, lembrete, resultado disponível).",
    ],
  },
  {
    icon: Share2,
    title: "Com quem compartilhamos",
    body: [
      "Com a clínica, laboratório ou profissional parceiro responsável pelo serviço que você escolheu — só o necessário para realizar o atendimento (nome, serviço e contato).",
      "Com prestadores que nos ajudam a operar a plataforma (hospedagem e mensageria), sempre com obrigação de sigilo.",
      "Com autoridades, quando a lei exigir.",
      "Não vendemos seus dados e não usamos suas informações de saúde para publicidade.",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Por quanto tempo guardamos",
    body: [
      "Mantemos seus dados enquanto sua conta estiver ativa e pelo prazo necessário para cumprir obrigações legais e fiscais.",
      "Depois disso, apagamos ou anonimizamos as informações.",
    ],
  },
];

const rights = [
  "Acesso: saber quais dados temos sobre você.",
  "Correção: ajustar informações incompletas ou desatualizadas.",
  "Exclusão: pedir que apaguemos seus dados, quando não houver obrigação legal de mantê-los.",
  "Portabilidade e cópia do histórico dos seus pedidos.",
  "Revogação do consentimento, a qualquer momento.",
];

function PrivacyPage() {
  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-12 sm:px-6 lg:px-8">
      <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft px-4 py-1.5 text-xs font-extrabold uppercase tracking-wide text-primary">
        <ShieldCheck className="size-4" /> LGPD
      </span>
      <h1 className="mt-4 text-3xl sm:text-4xl">Política de Privacidade</h1>
      <p className="mt-3 text-muted-foreground">
        Escrevemos esta política em linguagem simples: você merece entender exatamente o que
        acontece com os seus dados. Última atualização: agosto de 2026.
      </p>

      <div className="mt-10 space-y-6">
        {sections.map((s) => (
          <section key={s.title} className="surface-card p-7">
            <div className="flex items-center gap-3">
              <span className="flex size-10 items-center justify-center rounded-2xl bg-primary-soft text-primary">
                <s.icon className="size-5" />
              </span>
              <h2 className="text-xl">{s.title}</h2>
            </div>
            <ul className="mt-4 space-y-2.5 text-sm font-semibold leading-relaxed text-muted-foreground">
              {s.body.map((line) => (
                <li key={line} className="flex gap-2">
                  <span className="mt-2 size-1.5 shrink-0 rounded-full bg-accent" />
                  {line}
                </li>
              ))}
            </ul>
          </section>
        ))}

        <section className="surface-card p-7">
          <h2 className="text-xl">Seus direitos como titular</h2>
          <p className="mt-2 text-sm font-semibold text-muted-foreground">
            A LGPD garante que você tem controle sobre os seus dados. Você pode pedir:
          </p>
          <ul className="mt-4 space-y-2.5 text-sm font-semibold leading-relaxed text-muted-foreground">
            {rights.map((line) => (
              <li key={line} className="flex gap-2">
                <span className="mt-2 size-1.5 shrink-0 rounded-full bg-accent" />
                {line}
              </li>
            ))}
          </ul>
          <div className="mt-6 rounded-2xl bg-secondary/60 p-5">
            <p className="text-sm font-bold">
              Para exercer qualquer um desses direitos, fale com a nossa equipe no{" "}
              {WHATSAPP_DISPLAY} ou escreva para privacidade@prevbem.com.br. Respondemos em até 15
              dias.
            </p>
            <Button variant="cta" className="mt-4" asChild>
              <a
                href={buildWhatsAppUrl(
                  "Olá! Gostaria de tratar de um assunto sobre os meus dados pessoais (LGPD) na Prev Bem.",
                )}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle /> Falar sobre meus dados
              </a>
            </Button>
          </div>
        </section>

        <section className="surface-card p-7">
          <h2 className="text-xl">Cookies</h2>
          <p className="mt-2 text-sm font-semibold leading-relaxed text-muted-foreground">
            Cookies essenciais mantêm seu carrinho e seu login funcionando — sem eles o site não
            funciona. Os cookies opcionais nos ajudam a entender quais páginas são mais úteis. Na
            primeira visita você escolhe se aceita os opcionais, e pode mudar essa escolha limpando
            os dados do site no seu navegador.
          </p>
        </section>
      </div>

      <div className="mt-10 flex flex-wrap gap-3">
        <Button variant="soft" asChild>
          <Link to="/termos">Ler os Termos de Uso</Link>
        </Button>
        <Button variant="ghost" asChild>
          <Link to="/contato">Tirar uma dúvida</Link>
        </Button>
      </div>
    </div>
  );
}
