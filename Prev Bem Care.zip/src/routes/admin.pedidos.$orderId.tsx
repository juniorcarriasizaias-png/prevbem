import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowLeft, CheckCircle2, MessageCircle, StickyNote } from "lucide-react";
import { toast } from "sonner";

import { useAdmin } from "@/context/admin";
import { orderStatuses } from "@/data/admin-mock";
import { formatPrice } from "@/data/mock";
import { buildWhatsAppUrl } from "@/config/contact";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { StatusPill } from "@/routes/admin.index";

export const Route = createFileRoute("/admin/pedidos/$orderId")({
  component: AdminOrderDetail,
});

function AdminOrderDetail() {
  const { orderId } = Route.useParams();
  const { orders, setOrderStatus, addOrderNote } = useAdmin();
  const [note, setNote] = useState("");
  const order = orders.find((o) => o.id === orderId);

  if (!order) {
    return (
      <div className="rounded-xl border border-border bg-card p-6">
        <p className="text-sm font-extrabold">Pedido não encontrado</p>
        <Link to="/admin/pedidos" className="mt-2 inline-block text-[12.5px] font-bold text-primary">
          Voltar para pedidos
        </Link>
      </div>
    );
  }

  const whatsappUrl = buildWhatsAppUrl(
    `Olá, ${order.patientName}! Sou da equipe Prev Bem e estou falando sobre o pedido ${order.number} (${formatPrice(order.total)}).`,
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Link
            to="/admin/pedidos"
            className="inline-flex items-center gap-1 text-[12.5px] font-bold text-muted-foreground hover:text-foreground"
          >
            <ArrowLeft className="size-3.5" /> Pedidos
          </Link>
          <span className="text-muted-foreground">/</span>
          <h1 className="text-sm font-extrabold">{order.number}</h1>
          <StatusPill status={order.status} />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild variant="outline" size="sm" className="h-8 gap-1.5 text-[12px]">
            <a href={whatsappUrl} target="_blank" rel="noreferrer">
              <MessageCircle className="size-3.5" /> Falar no WhatsApp
            </a>
          </Button>
          <Button
            variant="cta"
            size="sm"
            className="h-8 gap-1.5 text-[12px]"
            disabled={order.status === "Confirmado"}
            onClick={() => {
              setOrderStatus(order.id, "Confirmado");
              toast.success(`Pagamento do pedido ${order.number} confirmado manualmente.`);
            }}
          >
            <CheckCircle2 className="size-3.5" /> Marcar pagamento confirmado
          </Button>
        </div>
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          <section className="rounded-xl border border-border bg-card p-4">
            <h2 className="text-sm font-extrabold">Dados do paciente</h2>
            <dl className="mt-3 grid gap-3 sm:grid-cols-2 text-[12.5px]">
              <Field label="Nome de quem agendou" value={order.patientName} />
              <Field label="WhatsApp" value={order.phone} />
              <Field
                label="Para quem é"
                value={order.forWhom === "other" ? "Para terceiro" : "Para o próprio paciente"}
              />
              <Field label="Beneficiário" value={order.beneficiaryName || order.patientName} />
              <Field
                label="Gerado em"
                value={`${new Date(order.createdAt).toLocaleDateString("pt-BR")} às ${new Date(
                  order.createdAt,
                ).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}`}
              />
              <Field label="Observação do paciente" value={order.notes || "—"} />
            </dl>
          </section>

          <section className="rounded-xl border border-border bg-card">
            <h2 className="border-b border-border p-4 text-sm font-extrabold">Itens do pedido</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[12.5px]">
                <thead className="border-b border-border text-[11px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="p-3 font-bold">Serviço</th>
                    <th className="p-3 font-bold">Clínica</th>
                    <th className="p-3 font-bold">Qtd</th>
                    <th className="p-3 font-bold">Unitário</th>
                    <th className="p-3 font-bold">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {order.items.map((item, i) => (
                    <tr key={`${item.name}-${i}`}>
                      <td className="p-3 font-bold">{item.name}</td>
                      <td className="p-3 text-muted-foreground">{item.clinic}</td>
                      <td className="p-3">{item.qty}</td>
                      <td className="p-3">{formatPrice(item.unitPrice)}</td>
                      <td className="p-3 font-bold">{formatPrice(item.unitPrice * item.qty)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex items-center justify-between border-t border-border p-4">
              <span className="text-[12px] font-bold uppercase tracking-wide text-muted-foreground">
                Total do pedido
              </span>
              <span className="text-base font-extrabold text-accent">{formatPrice(order.total)}</span>
            </div>
          </section>
        </div>

        <div className="space-y-4">
          <section className="rounded-xl border border-border bg-card p-4">
            <h2 className="text-sm font-extrabold">Situação do pedido</h2>
            <p className="mt-1 text-[11.5px] font-semibold text-muted-foreground">
              O pagamento é combinado por WhatsApp (PIX ou cartão) e confirmado manualmente aqui.
            </p>
            <div className="mt-3 grid gap-1.5">
              {orderStatuses.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => {
                    setOrderStatus(order.id, s);
                    toast.success(`Status alterado para "${s}".`);
                  }}
                  className={`rounded-lg border px-3 py-2 text-left text-[12.5px] font-bold transition-colors ${
                    order.status === s
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border hover:bg-muted"
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </section>

          <section className="rounded-xl border border-border bg-card p-4">
            <h2 className="inline-flex items-center gap-1.5 text-sm font-extrabold">
              <StickyNote className="size-4 text-primary" /> Observações internas
            </h2>
            <div className="mt-3 space-y-2">
              {(order.internalNotes ?? []).length === 0 && (
                <p className="text-[12px] font-semibold text-muted-foreground">
                  Nenhuma observação registrada.
                </p>
              )}
              {(order.internalNotes ?? []).map((n, i) => (
                <div key={i} className="rounded-lg bg-muted p-2.5">
                  <p className="text-[12.5px] font-semibold">{n.text}</p>
                  <p className="mt-1 text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">
                    {n.author} · {new Date(n.at).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              ))}
            </div>
            <form
              className="mt-3 space-y-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (!note.trim()) return;
                addOrderNote(order.id, note.trim());
                setNote("");
                toast.success("Observação interna adicionada.");
              }}
            >
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="Ex.: paciente pediu para agendar na parte da manhã."
                className="text-[12.5px]"
              />
              <Button type="submit" size="sm" className="h-8 w-full text-[12px]">
                Salvar observação
              </Button>
            </form>
          </section>
        </div>
      </div>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-[10.5px] font-bold uppercase tracking-wide text-muted-foreground">
        {label}
      </dt>
      <dd className="font-bold">{value}</dd>
    </div>
  );
}
