import { createFileRoute, Link } from "@tanstack/react-router";
import {
  BadgePercent,
  Coins,
  Gift,
  MessageCircle,
  ShieldCheck,
  Sparkles,
  Ticket,
  TrendingUp,
  UserRound,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { buildWhatsAppUrl } from "@/config/contact";
import { useAuth } from "@/context/auth";
import { formatPrice } from "@/data/mock";
import { REFERRAL_FRIEND_DISCOUNT, REFERRAL_REWARD } from "@/lib/referral";

export const Route = createFileRoute("/clube")({
  head: () => ({
    meta: [
      { title: "Clube de Vantagens Prev Bem — descontos, cupons e cashback" },
      {
        name: "description",
        content:
          "Pacientes cadastrados no Prev Bem ganham descontos progressivos, cupons de indicação e cashback simbólico para usar nos próximos agendamentos.",
      },
      { property: "og:title", content: "Clube de Vantagens Prev Bem" },
      {
        property: "og:description",
        content:
          "Descontos progressivos, cupons para indicar amigos e cashback nos próximos agendamentos — sem mensalidade e sem carência.",
      },
    ],
  }),
  component: Club,
});

const tiers = [
  {
    name: "Bem-vindo",
    range: "1º agendamento",
    discount: "5%",
    perks: ["Preço Prev Bem garantido", "Guia digital do atendimento", "Suporte no WhatsApp"],
  },
  {
    name: "Cuidado contínuo",
    range: "a partir do 3º agendamento",
    discount: "8%",
    perks: ["Desconto ampliado no catálogo", "Prioridade em encaixes de horário", "Cupom de indicação"],
    highlight: true,
  },
  {
    name: "Família Prev Bem",
    range: "a partir do 6º agendamento",
    discount: "12%",
    perks: ["Desconto máximo do clube", "Extensivo a até 4 dependentes", "Cashback dobrado"],
  },
];

const benefits = [
  {
    icon: TrendingUp,
    title: "Desconto progressivo",
    desc: "Quanto mais você cuida da saúde com a gente, maior o desconto aplicado no atendimento.",
  },
  {
    icon: Ticket,
    title: "Cupons de indicação",
    desc: `Indique amigos e cada um começa com ${REFERRAL_FRIEND_DISCOUNT}% de desconto no primeiro agendamento.`,
  },
  {
    icon: Coins,
    title: "Cashback simbólico",
    desc: "2% do valor de cada atendimento concluído volta como crédito para o próximo agendamento.",
  },
  {
    icon: Gift,
    title: "Campanhas exclusivas",
    desc: "Check-ups e campanhas de prevenção com preços especiais, avisados na sua área do paciente.",
  },
];

function Club() {
  const { user } = useAuth();
  const cashback = 18.4;

  return (
    <div className="pb-4">
      <section className="hero-gradient">
        <div className="mx-auto grid w-full max-w-7xl items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.1fr_1fr] lg:px-8">
          <div className="space-y-6">
            <span className="inline-flex items-center gap-2 rounded-full bg-background px-4 py-2 text-xs font-extrabold text-primary shadow-soft">
              <Sparkles className="size-4" /> Clube de Vantagens · gratuito
            </span>
            <h1 className="text-4xl leading-tight sm:text-5xl">
              Vantagens de quem cuida da saúde <span className="text-primary">com constância</span>
            </h1>
            <p className="max-w-lg text-lg leading-relaxed text-muted-foreground">
              Ao criar sua conta no Prev Bem você entra automaticamente no clube: descontos que
              crescem, cupons para indicar quem você ama e cashback simbólico nos próximos
              agendamentos.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button variant="cta" size="lg" asChild>
                <Link to={user ? "/servicos" : "/entrar"}>
                  {user ? "Usar minhas vantagens" : "Criar minha conta grátis"}
                </Link>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/indicacao">Programa de indicação</Link>
              </Button>
            </div>
            <p className="inline-flex items-center gap-2 text-xs font-bold text-primary">
              <ShieldCheck className="size-4" /> Sem mensalidade, sem carência e sem letras miúdas
            </p>
          </div>

          <div className="surface-card space-y-5 p-7">
            <div className="flex items-center gap-3">
              <span className="flex size-12 items-center justify-center rounded-2xl bg-accent-soft text-accent">
                <UserRound className="size-6" />
              </span>
              <div>
                <p className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
                  Seu clube
                </p>
                <p className="text-lg font-extrabold">
                  {user ? user.name : "Entre para ver seu nível"}
                </p>
              </div>
            </div>
            <dl className="grid gap-3 sm:grid-cols-2">
              <div className="rounded-2xl bg-secondary/70 p-4">
                <dt className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
                  Nível atual
                </dt>
                <dd className="mt-1 text-xl font-extrabold text-primary">
                  {user ? "Cuidado contínuo" : "—"}
                </dd>
              </div>
              <div className="rounded-2xl bg-accent-soft/70 p-4">
                <dt className="text-xs font-extrabold uppercase tracking-wide text-muted-foreground">
                  Cashback disponível
                </dt>
                <dd className="mt-1 text-xl font-extrabold text-accent">
                  {user ? formatPrice(cashback) : formatPrice(0)}
                </dd>
              </div>
            </dl>
            <p className="text-xs font-semibold leading-relaxed text-muted-foreground">
              Os benefícios são aplicados manualmente pela nossa equipe no atendimento pelo
              WhatsApp, na hora de confirmar o seu agendamento. Basta avisar que você é do clube.
            </p>
            <Button variant="soft" className="w-full" asChild>
              <a
                href={buildWhatsAppUrl(
                  `Olá! Sou${user ? ` ${user.name},` : ""} do Clube de Vantagens Prev Bem e quero usar meus benefícios no próximo agendamento.`,
                )}
                target="_blank"
                rel="noreferrer"
              >
                <MessageCircle /> Resgatar pelo WhatsApp
              </a>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl">O que você ganha</h2>
        <p className="mt-2 text-muted-foreground">Tudo liberado desde o primeiro agendamento.</p>
        <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {benefits.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="surface-card p-6">
              <span className="brand-gradient flex size-12 items-center justify-center rounded-2xl text-primary-foreground">
                <Icon className="size-6" />
              </span>
              <h3 className="mt-5 text-lg">{title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 sm:px-6 lg:px-8">
        <h2 className="text-2xl sm:text-3xl">Níveis de desconto progressivo</h2>
        <div className="mt-8 grid gap-5 lg:grid-cols-3">
          {tiers.map((t) => (
            <div
              key={t.name}
              className={
                t.highlight
                  ? "surface-card border-2 border-accent/40 p-6 ring-4 ring-accent-soft/40"
                  : "surface-card p-6"
              }
            >
              <div className="flex items-center justify-between gap-3">
                <div>
                  <h3 className="text-lg">{t.name}</h3>
                  <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                    {t.range}
                  </p>
                </div>
                <span className="rounded-2xl bg-accent-soft px-3 py-2 text-xl font-extrabold text-accent">
                  {t.discount}
                </span>
              </div>
              <ul className="mt-5 space-y-2.5 text-sm font-semibold text-muted-foreground">
                {t.perks.map((p) => (
                  <li key={p} className="flex items-start gap-2">
                    <BadgePercent className="mt-0.5 size-4 shrink-0 text-primary" /> {p}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <p className="mt-6 text-xs font-semibold text-muted-foreground">
          Percentuais e cashback são cumulativos até o limite de 20% por atendimento. Valores
          demonstrativos desta versão do Prev Bem.
        </p>
      </section>

      <section className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="brand-gradient flex flex-col items-start gap-6 rounded-3xl p-8 text-primary-foreground sm:p-12 lg:flex-row lg:items-center lg:justify-between">
          <div className="max-w-xl space-y-3">
            <h2 className="text-3xl text-primary-foreground">
              Indique um amigo e ganhe {formatPrice(REFERRAL_REWARD)}
            </h2>
            <p className="text-primary-foreground/80">
              Seu amigo economiza {REFERRAL_FRIEND_DISCOUNT}% no primeiro agendamento e você recebe
              crédito para usar no próximo.
            </p>
          </div>
          <Button variant="cta" size="lg" asChild>
            <Link to="/indicacao">Pegar meu código</Link>
          </Button>
        </div>
      </section>
    </div>
  );
}
