import { createFileRoute, Link } from "@tanstack/react-router";
import { CalendarCheck, CircleDollarSign, Clock, Stethoscope } from "lucide-react";
import { useMemo } from "react";

import { usePartner } from "@/context/partner";
import { formatPrice } from "@/data/mock";
import { StatusPill, PartnerCard, PartnerSectionTitle } from "@/components/partner/partner-ui";

export const Route = createFileRoute("/parceiro/")({
  component: PartnerDashboard,
});

const isSameMonth = (iso: string) => {
  const d = new Date(iso);
  const now = new Date();
  return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
};

function PartnerDashboard() {
  const { clinic, orders, services, suggestions } = usePartner();

  const metrics = useMemo(() => {
    const month = orders.filter((o) => isSameMonth(o.createdAt));
    const waiting = orders.filter((o) => o.status === "Aguardando pagamento");
    const confirmed = orders.filter((o) => o.status === "Confirmado" || o.status === "Concluído");
    return {
      monthCount: month.length,
      monthTotal: month.reduce((s, o) => s + o.clinicTotal, 0),
      waitingTotal: waiting.reduce((s, o) => s + o.clinicTotal, 0),
      waitingCount: waiting.length,
      confirmedTotal: confirmed.reduce((s, o) => s + o.clinicTotal, 0),
      confirmedCount: confirmed.length,
    };
  }, [orders]);

  const topServices = useMemo(() => {
    const map = new Map<string, { name: string; qty: number; total: number }>();
    for (const o of orders) {
      for (const i of o.items) {
        const cur = map.get(i.name) ?? { name: i.name, qty: 0, total: 0 };
        cur.qty += i.qty;
        cur.total += i.unitPrice * i.qty;
        map.set(i.name, cur);
      }
    }
    return [...map.values()].sort((a, b) => b.qty - a.qty).slice(0, 5);
  }, [orders]);

  const pendingSuggestions = suggestions.filter((s) => s.status === "Pendente").length;
  const maxQty = topServices[0]?.qty ?? 1;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold">Visão geral</h1>
        <p className="text-sm font-semibold text-muted-foreground">
          Dados exclusivos da {clinic?.name} — você vê apenas os agendamentos e serviços da sua
          clínica.
        </p>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <PartnerCard className="p-4">
          <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            <CalendarCheck className="size-3.5 text-primary" /> Agendamentos no mês
          </p>
          <p className="mt-2 text-2xl font-extrabold">{metrics.monthCount}</p>
          <p className="text-[12px] font-semibold text-muted-foreground">
            {formatPrice(metrics.monthTotal)} em serviços
          </p>
        </PartnerCard>
        <PartnerCard className="p-4">
          <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            <Clock className="size-3.5 text-accent" /> Aguardando pagamento
          </p>
          <p className="mt-2 text-2xl font-extrabold text-accent">
            {formatPrice(metrics.waitingTotal)}
          </p>
          <p className="text-[12px] font-semibold text-muted-foreground">
            {metrics.waitingCount} pedido(s)
          </p>
        </PartnerCard>
        <PartnerCard className="p-4">
          <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            <CircleDollarSign className="size-3.5 text-success" /> Confirmados
          </p>
          <p className="mt-2 text-2xl font-extrabold text-success">
            {formatPrice(metrics.confirmedTotal)}
          </p>
          <p className="text-[12px] font-semibold text-muted-foreground">
            {metrics.confirmedCount} pedido(s)
          </p>
        </PartnerCard>
        <PartnerCard className="p-4">
          <p className="flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            <Stethoscope className="size-3.5 text-primary" /> Serviços na plataforma
          </p>
          <p className="mt-2 text-2xl font-extrabold">{services.length}</p>
          <p className="text-[12px] font-semibold text-muted-foreground">
            {pendingSuggestions} sugestão(ões) em análise
          </p>
        </PartnerCard>
      </div>

      <div className="grid gap-4 lg:grid-cols-[1.3fr_1fr]">
        <PartnerCard className="p-5">
          <PartnerSectionTitle
            title="Agendamentos recentes"
            action={
              <Link to="/parceiro/agendamentos" className="text-[12px] font-bold text-primary hover:underline">
                Ver todos
              </Link>
            }
          />
          <ul className="mt-3 divide-y divide-border">
            {orders.slice(0, 6).map((o) => (
              <li key={o.id} className="flex items-center justify-between gap-3 py-2.5">
                <div className="min-w-0">
                  <p className="truncate text-[13px] font-extrabold">{o.patientName}</p>
                  <p className="truncate text-[11px] font-semibold text-muted-foreground">
                    {o.number} · {o.items.map((i) => i.name).join(", ")}
                  </p>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[13px] font-extrabold">{formatPrice(o.clinicTotal)}</p>
                  <StatusPill status={o.status} />
                </div>
              </li>
            ))}
            {orders.length === 0 && (
              <li className="py-6 text-center text-[12px] font-semibold text-muted-foreground">
                Nenhum agendamento recebido ainda.
              </li>
            )}
          </ul>
        </PartnerCard>

        <PartnerCard className="p-5">
          <PartnerSectionTitle title="Seus serviços mais procurados" />
          <ul className="mt-3 space-y-3">
            {topServices.map((s) => (
              <li key={s.name}>
                <div className="flex items-baseline justify-between gap-2">
                  <p className="truncate text-[12px] font-bold">{s.name}</p>
                  <p className="shrink-0 text-[12px] font-extrabold text-primary">{s.qty}x</p>
                </div>
                <div className="mt-1 h-2 rounded-full bg-secondary">
                  <div
                    className="h-2 rounded-full bg-primary"
                    style={{ width: `${Math.max(8, (s.qty / maxQty) * 100)}%` }}
                  />
                </div>
              </li>
            ))}
            {topServices.length === 0 && (
              <li className="py-6 text-center text-[12px] font-semibold text-muted-foreground">
                Sem dados suficientes ainda.
              </li>
            )}
          </ul>
        </PartnerCard>
      </div>
    </div>
  );
}
