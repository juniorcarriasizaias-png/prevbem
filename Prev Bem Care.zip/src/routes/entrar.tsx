import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { HeartHandshake, Loader2, LogIn, ShieldCheck, Sparkles, UserPlus } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/context/auth";

export const Route = createFileRoute("/entrar")({
  head: () => ({
    meta: [
      { title: "Entrar ou criar conta | Prev Bem" },
      {
        name: "description",
        content:
          "Acesse sua conta Prev Bem com e-mail e senha para ver agendamentos, carteirinha digital e histórico de pedidos.",
      },
      { property: "og:title", content: "Entrar ou criar conta | Prev Bem" },
      {
        property: "og:description",
        content: "Login com e-mail e senha para acompanhar seus agendamentos.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SignIn,
});

type Mode = "login" | "signup" | "reset";

function SignIn() {
  const { user, ready, signIn, signUp, resetPassword } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState<Mode>("login");
  const [loading, setLoading] = useState(false);
  const [nome, setNome] = useState("");
  const [telefone, setTelefone] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  useEffect(() => {
    if (ready && user) void navigate({ to: "/minha-conta", replace: true });
  }, [ready, user, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await signIn(email, senha);
    setLoading(false);
    if (error) {
      toast.error(
        error.toLowerCase().includes("invalid")
          ? "E-mail ou senha inválidos."
          : `Não foi possível entrar: ${error}`,
      );
      return;
    }
    toast.success("Bem-vindo(a) de volta ao Prev Bem!");
    void navigate({ to: "/minha-conta" });
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (nome.trim().length < 3) {
      toast.error("Informe seu nome completo.");
      return;
    }
    const digits = telefone.replace(/\D/g, "");
    if (digits.length < 10 || digits.length > 13) {
      toast.error("Informe um WhatsApp válido com DDD.");
      return;
    }
    if (senha.length < 6) {
      toast.error("A senha deve ter pelo menos 6 caracteres.");
      return;
    }
    setLoading(true);
    const { error, needsConfirmation } = await signUp({
      nomeCompleto: nome,
      telefone,
      email,
      password: senha,
    });
    setLoading(false);
    if (error) {
      const low = error.toLowerCase();
      toast.error(
        low.includes("already")
          ? "Este e-mail já possui cadastro. Faça login."
          : low.includes("weak") || low.includes("pwned")
            ? "Essa senha é muito comum. Escolha uma senha mais forte."
            : `Não foi possível criar a conta: ${error}`,
      );
      return;
    }
    if (needsConfirmation) {
      toast.success("Cadastro criado! Confirme o e-mail que enviamos para ativar sua conta.");
      setMode("login");
      return;
    }
    toast.success("Conta criada com sucesso!");
    void navigate({ to: "/minha-conta" });
  };

  const handleReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await resetPassword(email);
    setLoading(false);
    if (error) {
      toast.error(`Não foi possível enviar o e-mail: ${error}`);
      return;
    }
    toast.success("Enviamos um link de redefinição para o seu e-mail.");
    setMode("login");
  };

  return (
    <div className="mx-auto grid w-full max-w-6xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.05fr_1fr] lg:items-center lg:px-8">
      <div className="space-y-6">
        <span className="inline-flex items-center gap-2 rounded-full bg-primary-soft px-4 py-1.5 text-xs font-extrabold uppercase tracking-wide text-primary">
          <Sparkles className="size-3.5" /> Área do paciente
        </span>
        <h1 className="text-3xl sm:text-4xl">Sua saúde organizada em um só lugar</h1>
        <p className="text-base font-semibold text-muted-foreground">
          Crie sua conta para acompanhar agendamentos, acessar sua carteirinha digital Prev Bem,
          rever guias de pedidos e receber lembretes de preparo dos exames.
        </p>
        <ul className="space-y-3">
          {[
            "Próximos agendamentos com status atualizado",
            "Carteirinha digital para apresentar na clínica",
            "Histórico de pedidos e guias para baixar",
            "Reagendamento e cancelamento pelo WhatsApp",
          ].map((item) => (
            <li key={item} className="flex items-start gap-3 text-sm font-bold">
              <ShieldCheck className="mt-0.5 size-4 shrink-0 text-accent" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      <div className="surface-card space-y-5 p-7">
        <div className="grid grid-cols-2 gap-1 rounded-2xl bg-secondary p-1">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`rounded-xl px-3 py-2 text-sm font-extrabold transition-colors ${
              mode !== "signup" ? "bg-background text-primary shadow-sm" : "text-muted-foreground"
            }`}
          >
            Entrar
          </button>
          <button
            type="button"
            onClick={() => setMode("signup")}
            className={`rounded-xl px-3 py-2 text-sm font-extrabold transition-colors ${
              mode === "signup" ? "bg-background text-primary shadow-sm" : "text-muted-foreground"
            }`}
          >
            Criar conta
          </button>
        </div>

        {mode === "signup" && (
          <form className="space-y-4" onSubmit={handleSignUp}>
            <div className="space-y-1.5">
              <Label htmlFor="nome">Nome completo</Label>
              <Input
                id="nome"
                value={nome}
                maxLength={100}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Como devemos te chamar?"
                autoComplete="name"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="telefone">WhatsApp / telefone</Label>
              <Input
                id="telefone"
                value={telefone}
                maxLength={20}
                inputMode="tel"
                onChange={(e) => setTelefone(e.target.value)}
                placeholder="(86) 9 9999-0000"
                autoComplete="tel"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-email">E-mail</Label>
              <Input
                id="signup-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@email.com"
                autoComplete="email"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="signup-senha">Senha</Label>
              <Input
                id="signup-senha"
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                placeholder="Mínimo de 6 caracteres"
                autoComplete="new-password"
                required
              />
            </div>
            <Button type="submit" variant="cta" className="h-12 w-full" disabled={loading}>
              {loading ? <Loader2 className="animate-spin" /> : <UserPlus />}
              Criar minha conta
            </Button>
          </form>
        )}

        {mode === "login" && (
          <form className="space-y-4" onSubmit={handleLogin}>
            <div className="space-y-1.5">
              <Label htmlFor="login-email">E-mail</Label>
              <Input
                id="login-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@email.com"
                autoComplete="email"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="login-senha">Senha</Label>
              <Input
                id="login-senha"
                type="password"
                value={senha}
                onChange={(e) => setSenha(e.target.value)}
                autoComplete="current-password"
                required
              />
            </div>
            <Button type="submit" variant="cta" className="h-12 w-full" disabled={loading}>
              {loading ? <Loader2 className="animate-spin" /> : <LogIn />}
              Entrar
            </Button>
            <button
              type="button"
              onClick={() => setMode("reset")}
              className="w-full text-center text-xs font-extrabold text-primary underline-offset-4 hover:underline"
            >
              Esqueci minha senha
            </button>
          </form>
        )}

        {mode === "reset" && (
          <form className="space-y-4" onSubmit={handleReset}>
            <div>
              <h2 className="text-xl">Recuperar acesso</h2>
              <p className="mt-1 text-sm font-semibold text-muted-foreground">
                Informe seu e-mail e enviaremos um link para criar uma nova senha.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="reset-email">E-mail</Label>
              <Input
                id="reset-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@email.com"
                autoComplete="email"
                required
              />
            </div>
            <Button type="submit" variant="cta" className="h-12 w-full" disabled={loading}>
              {loading ? <Loader2 className="animate-spin" /> : <ShieldCheck />}
              Enviar link de redefinição
            </Button>
            <button
              type="button"
              onClick={() => setMode("login")}
              className="w-full text-center text-xs font-extrabold text-primary underline-offset-4 hover:underline"
            >
              Voltar para o login
            </button>
          </form>
        )}

        <p className="inline-flex items-start gap-2 rounded-2xl bg-secondary/70 px-4 py-3 text-xs font-semibold text-primary">
          <HeartHandshake className="mt-0.5 size-4 shrink-0" />
          O pagamento dos serviços é sempre combinado com nossa equipe pelo WhatsApp — nunca pedimos
          dados de cartão pelo site.
        </p>

        <p className="text-center text-xs font-semibold text-muted-foreground">
          Prefere olhar os serviços primeiro?{" "}
          <Link to="/servicos" className="font-extrabold text-primary underline-offset-4 hover:underline">
            Ver catálogo
          </Link>
        </p>
      </div>
    </div>
  );
}
