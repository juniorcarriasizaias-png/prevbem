import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ChevronDown, MessageCircle, Search } from "lucide-react";

import { useAdmin } from "@/context/admin";
import { formatPrice } from "@/data/mock";
import { buildWhatsAppUrl } from "@/config/contact";
import { Input } from "@/components/ui/input";
import { StatusPill } from "@/routes/admin.index";

export const Route = createFileRoute("/admin/pacientes")({
  component: AdminPatients,
});

function AdminPatients() {
  const { patients } = useAdmin();
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return patients.filter(
      (p) => !q || p.name.toLowerCase().includes(q) || p.phone.includes(q),
    );
  }, [patients, query]);

  return (
    <div className="space-y-4">
      <section className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-sm font-extrabold">Pacientes</h1>
          <p className="text-[11.5px] font-semibold text-muted-foreground">
            {patients.length} pacientes com pedidos registrados
          </p>
        </div>
        <div className="relative w-full md:max-w-sm">
          <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Buscar por nome ou telefone"
            className="h-9 pl-9 text-[13px]"
          />
        </div>
      </section>

      <div className="space-y-2">
        {filtered.map((p) => {
          const expanded = open === p.name;
          return (
            <section key={p.name} className="rounded-xl border border-border bg-card">
              <button
                type="button"
                onClick={() => setOpen(expanded ? null : p.name)}
                className="flex w-full items-center justify-between gap-3 p-4 text-left"
              >
                <div className="min-w-0">
                  <p className="truncate text-[13.5px] font-extrabold">{p.name}</p>
                  <p className="text-[11.5px] font-semibold text-muted-foreground">
                    {p.phone} · último pedido em{" "}
                    {new Date(p.lastOrderAt).toLocaleDateString("pt-BR")}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-4">
                  <div className="text-right">
                    <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                      Pedidos
                    </p>
                    <p className="text-[13px] font-extrabold">{p.orders.length}</p>
                  </div>
                  <div className="hidden text-right sm:block">
                    <p className="text-[11px] font-bold uppercase tracking-wide text-muted-foreground">
                      Total
                    </p>
                    <p className="text-[13px] font-extrabold text-accent">{formatPrice(p.total)}</p>
                  </div>
                  <ChevronDown
                    className={`size-4 text-muted-foreground transition-transform ${
                      expanded ? "rotate-180" : ""
                    }`}
                  />
                </div>
              </button>

              {expanded && (
                <div className="border-t border-border p-4">
                  <a
                    href={buildWhatsAppUrl(
                      `Olá, ${p.name}! Sou da equipe Prev Bem e gostaria de falar sobre seus agendamentos.`,
                    )}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-[12px] font-bold text-primary hover:underline"
                  >
                    <MessageCircle className="size-3.5" /> Falar com o paciente no WhatsApp
                  </a>
                  <div className="mt-3 overflow-x-auto">
                    <table className="w-full text-left text-[12.5px]">
                      <thead className="text-[11px] uppercase tracking-wide text-muted-foreground">
                        <tr>
                          <th className="py-2 pr-3 font-bold">Pedido</th>
                          <th className="py-2 pr-3 font-bold">Data</th>
                          <th className="py-2 pr-3 font-bold">Itens</th>
                          <th className="py-2 pr-3 font-bold">Total</th>
                          <th className="py-2 pr-3 font-bold">Status</th>
                          <th className="py-2" />
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-border">
                        {p.orders.map((o) => (
                          <tr key={o.id}>
                            <td className="py-2 pr-3 font-extrabold">{o.number}</td>
                            <td className="py-2 pr-3 text-muted-foreground">
                              {new Date(o.createdAt).toLocaleDateString("pt-BR")}
                            </td>
                            <td className="py-2 pr-3 text-muted-foreground">
                              {o.items.map((i) => i.name).join(", ")}
                            </td>
                            <td className="py-2 pr-3 font-bold">{formatPrice(o.total)}</td>
                            <td className="py-2 pr-3">
                              <StatusPill status={o.status} />
                            </td>
                            <td className="py-2 text-right">
                              <Link
                                to="/admin/pedidos/$orderId"
                                params={{ orderId: o.id }}
                                className="font-bold text-primary hover:underline"
                              >
                                Abrir
                              </Link>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </section>
          );
        })}
        {filtered.length === 0 && (
          <p className="rounded-xl border border-border bg-card p-6 text-center text-[12.5px] font-semibold text-muted-foreground">
            Nenhum paciente encontrado.
          </p>
        )}
      </div>
    </div>
  );
}
