import { createFileRoute, Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import {
  CheckCircle2,
  Download,
  MapPin,
  MessageCircle,
  Printer,
  ReceiptText,
  Share2,
  ShieldCheck,
  ShoppingCart,
} from "lucide-react";
import { toast } from "sonner";

import { OrderVoucher } from "@/components/order-voucher";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { buildWhatsAppUrl } from "@/config/contact";
import { useSiteSettings } from "@/context/site-settings";
import { useCart } from "@/context/cart";
import { useOrders, type Order } from "@/context/orders";
import { formatPrice, getClinic } from "@/data/mock";

export const Route = createFileRoute("/finalizar")({
  head: () => ({
    meta: [
      { title: "Finalizar pedido | Prev Bem" },
      {
        name: "description",
        content:
          "Informe seus dados, gere a guia digital do seu agendamento e combine o pagamento (PIX ou cartão) com a equipe Prev Bem pelo WhatsApp.",
      },
      { property: "og:title", content: "Finalizar pedido | Prev Bem" },
      {
        property: "og:description",
        content: "Guia digital do agendamento e finalização pelo WhatsApp, sem pagamento no site.",
      },
    ],
  }),
  component: Checkout,
});

const buildMessage = (order: Order) => {
  const items = order.items
    .map((i) => `• ${i.name} (${i.clinic})${i.qty > 1 ? ` x${i.qty}` : ""} — ${formatPrice(i.unitPrice * i.qty)}`)
    .join("\n");
  return [
    "Olá! Gostaria de finalizar meu agendamento no Prev Bem.",
    "",
    `Pedido: ${order.number}`,
    `Paciente: ${order.forWhom === "other" && order.beneficiaryName ? order.beneficiaryName : order.patientName}`,
    `Contato: ${order.phone}`,
    "Itens:",
    items,
    `Valor total: ${formatPrice(order.total)}`,
    "",
    "Aguardo o link de pagamento ou chave PIX.",
  ].join("\n");
};

function Checkout() {
  const { lines, subtotal, clear } = useCart();
  const { createOrder } = useOrders();
  const { whatsappDisplay } = useSiteSettings();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [forWhom, setForWhom] = useState<"self" | "other">("self");
  const [beneficiaryName, setBeneficiaryName] = useState("");
  const [notes, setNotes] = useState("");
  const [acceptedPrivacy, setAcceptedPrivacy] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);
  const voucherRef = useRef<HTMLDivElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      toast.error("Precisamos do seu nome e telefone para gerar a guia.");
      return;
    }
    if (forWhom === "other" && !beneficiaryName.trim()) {
      toast.error("Informe o nome da pessoa que será atendida.");
      return;
    }
    if (!acceptedPrivacy) {
      toast.error("É preciso aceitar a Política de Privacidade para gerar a guia.");
      return;
    }
    const created = createOrder({
      patientName: name.trim(),
      phone: phone.trim(),
      forWhom,
      beneficiaryName: forWhom === "other" ? beneficiaryName.trim() : undefined,
      notes: notes.trim() || undefined,
      items: lines.map(({ service, qty }) => ({
        name: service.name,
        clinic: getClinic(service).name,
        clinicId: service.clinicId,
        unitPrice: service.price,
        qty,
      })),
      total: subtotal,
    });
    setOrder(created);
    clear();
    toast.success(`Guia ${created.number} gerada com sucesso!`);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDownload = async () => {
    if (!voucherRef.current) return;
    try {
      const { default: html2canvas } = await import("html2canvas-pro");
      const canvas = await html2canvas(voucherRef.current, { scale: 2, backgroundColor: "#ffffff" });
      const link = document.createElement("a");
      link.download = `guia-prevbem-${order?.number ?? "pedido"}.png`;
      link.href = canvas.toDataURL("image/png");
      link.click();
      toast.success("Guia salva como imagem.");
    } catch {
      toast.error("Não foi possível gerar a imagem. Use a opção Imprimir.");
    }
  };

  const handleShare = async () => {
    if (!order) return;
    const text = buildMessage(order);
    try {
      if (navigator.share) {
        await navigator.share({ title: `Guia Prev Bem ${order.number}`, text });
      } else {
        await navigator.clipboard.writeText(text);
        toast.success("Resumo do pedido copiado.");
      }
    } catch {
      /* usuário cancelou */
    }
  };

  if (order) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
        <div data-print-hide className="text-center">
          <span className="mx-auto flex size-14 items-center justify-center rounded-3xl bg-success/12 text-success">
            <CheckCircle2 className="size-7" />
          </span>
          <h1 className="mt-4 text-3xl sm:text-4xl">Sua guia está pronta!</h1>
          <p className="mx-auto mt-2 max-w-xl text-muted-foreground">
            Guardamos o pedido <strong>{order.number}</strong> no seu histórico com o status
            “Aguardando pagamento”. Agora é só falar com a nossa equipe pelo WhatsApp para combinar o
            pagamento por PIX ou cartão — leva menos de um minuto.
          </p>
        </div>

        <div className="mt-8">
          <OrderVoucher ref={voucherRef} order={order} />
        </div>

        <div data-print-hide className="mt-6 space-y-4">
          <Button variant="cta" size="lg" className="w-full" asChild>
            <a href={buildWhatsAppUrl(buildMessage(order))} target="_blank" rel="noreferrer">
              <MessageCircle /> Finalizar pelo WhatsApp
            </a>
          </Button>
          <p className="text-center text-xs font-semibold text-muted-foreground">
            Nossa equipe atende no {whatsappDisplay}. O pagamento é combinado apenas por lá — nunca
            pedimos dados de cartão no site.
          </p>
          <div className="grid gap-3 sm:grid-cols-3">
            <Button variant="soft" onClick={handleDownload}>
              <Download /> Baixar imagem
            </Button>
            <Button variant="soft" onClick={() => window.print()}>
              <Printer /> Imprimir
            </Button>
            <Button variant="soft" onClick={handleShare}>
              <Share2 /> Compartilhar
            </Button>
          </div>
          <div className="surface-card flex flex-col items-start gap-3 p-6 sm:flex-row sm:items-center sm:justify-between">
            <p className="text-sm font-semibold text-muted-foreground">
              Acompanhe este pedido na sua área do paciente.
            </p>
            <div className="flex gap-2">
              <Button variant="outline" asChild>
                <Link to="/minha-conta">Ver meus pedidos</Link>
              </Button>
              <Button variant="ghost" asChild>
                <Link to="/servicos">Agendar outro</Link>
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (lines.length === 0) {
    return (
      <div className="mx-auto w-full max-w-3xl px-4 py-16 text-center sm:px-6">
        <ShoppingCart className="mx-auto size-10 text-primary" />
        <h1 className="mt-4 text-2xl">Nada para finalizar por aqui</h1>
        <p className="mt-2 text-muted-foreground">
          Adicione consultas, exames ou procedimentos ao carrinho para gerar sua guia.
        </p>
        <Button variant="cta" className="mt-6" asChild>
          <Link to="/servicos">Ver serviços</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <ol className="flex flex-wrap items-center gap-3 text-xs font-extrabold uppercase tracking-wide">
        {["Carrinho", "Seus dados", "Guia e WhatsApp"].map((step, i) => (
          <li key={step} className="flex items-center gap-2">
            <span
              className={
                i <= 1
                  ? "flex size-7 items-center justify-center rounded-full bg-primary text-primary-foreground"
                  : "flex size-7 items-center justify-center rounded-full bg-secondary text-muted-foreground"
              }
            >
              {i + 1}
            </span>
            <span className={i <= 1 ? "text-primary" : "text-muted-foreground"}>{step}</span>
            {i < 2 && <span className="mx-1 h-px w-8 bg-border" />}
          </li>
        ))}
      </ol>

      <h1 className="mt-6 text-3xl sm:text-4xl">Finalizar pedido</h1>
      <p className="mt-2 max-w-2xl text-muted-foreground">
        Preencha seus dados para gerarmos a guia digital do agendamento. Não há pagamento nesta
        etapa: o PIX ou cartão é combinado com carinho pela nossa equipe no WhatsApp.
      </p>

      <form onSubmit={handleSubmit} className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <section className="surface-card p-7">
            <h2 className="text-xl">Seus dados</h2>
            <div className="mt-5 grid gap-5 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="nome" className="text-sm font-bold">
                  Nome completo
                </Label>
                <Input
                  id="nome"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Maria Souza"
                  className="h-11 rounded-2xl bg-secondary/50 font-semibold"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="telefone" className="text-sm font-bold">
                  Telefone / WhatsApp
                </Label>
                <Input
                  id="telefone"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(86) 90000-0000"
                  className="h-11 rounded-2xl bg-secondary/50 font-semibold"
                  required
                />
              </div>
            </div>
          </section>

          <section className="surface-card p-7">
            <h2 className="text-xl">Para quem é o agendamento?</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Você pode agendar para você ou para alguém que ama.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              {[
                { value: "self" as const, label: "Para mim" },
                { value: "other" as const, label: "Para outra pessoa" },
              ].map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setForWhom(opt.value)}
                  aria-pressed={forWhom === opt.value}
                  className={
                    forWhom === opt.value
                      ? "rounded-2xl bg-primary px-5 py-3 text-sm font-extrabold text-primary-foreground"
                      : "rounded-2xl bg-secondary/60 px-5 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
                  }
                >
                  {opt.label}
                </button>
              ))}
            </div>
            {forWhom === "other" && (
              <div className="mt-5 max-w-md space-y-2">
                <Label htmlFor="beneficiario" className="text-sm font-bold">
                  Nome de quem será atendido
                </Label>
                <Input
                  id="beneficiario"
                  value={beneficiaryName}
                  onChange={(e) => setBeneficiaryName(e.target.value)}
                  placeholder="João Souza"
                  className="h-11 rounded-2xl bg-secondary/50 font-semibold"
                />
              </div>
            )}
          </section>

          <section className="surface-card p-7">
            <h2 className="text-xl">Observações (opcional)</h2>
            <Textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Preferência de dia/horário, alergias, necessidade de acessibilidade…"
              className="mt-4 min-h-28 rounded-2xl bg-secondary/50 font-semibold"
            />
          </section>
        </div>

        <aside className="h-fit lg:sticky lg:top-24">
          <div className="surface-card space-y-4 p-6">
            <h2 className="text-lg">Resumo do pedido</h2>
            <ul className="space-y-4">
              {lines.map(({ service, qty }) => (
                <li
                  key={service.id}
                  className="space-y-1 border-b border-border pb-4 last:border-none"
                >
                  <p className="text-sm font-extrabold">
                    {service.name}
                    {qty > 1 ? ` (x${qty})` : ""}
                  </p>
                  <p className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                    <MapPin className="size-3.5 text-primary" /> {getClinic(service).name}
                  </p>
                  <p className="text-sm font-extrabold text-primary">
                    {formatPrice(service.price * qty)}
                  </p>
                </li>
              ))}
            </ul>
            <div className="flex items-baseline justify-between">
              <span className="text-sm font-extrabold">Valor total</span>
              <span className="text-xl font-extrabold text-primary">{formatPrice(subtotal)}</span>
            </div>
            <label
              htmlFor="aceite-privacidade"
              className="flex cursor-pointer items-start gap-3 rounded-2xl bg-secondary/50 p-4"
            >
              <Checkbox
                id="aceite-privacidade"
                checked={acceptedPrivacy}
                onCheckedChange={(v) => setAcceptedPrivacy(v === true)}
                className="mt-0.5"
                aria-required
              />
              <span className="text-xs font-semibold leading-relaxed text-muted-foreground">
                Li e concordo com a{" "}
                <Link to="/privacidade" className="font-extrabold text-primary underline">
                  Política de Privacidade
                </Link>{" "}
                e os{" "}
                <Link to="/termos" className="font-extrabold text-primary underline">
                  Termos de Uso
                </Link>
                . Autorizo o uso do meu nome e telefone para realizar o agendamento e o
                compartilhamento com a clínica parceira responsável pelo atendimento.
              </span>
            </label>
            <Button
              type="submit"
              variant="cta"
              size="lg"
              className="w-full"
              disabled={!acceptedPrivacy}
            >
              <ReceiptText /> Finalizar pedido
            </Button>
            <ul className="space-y-2 text-xs font-semibold text-muted-foreground">
              <li className="flex items-start gap-2">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" /> Geramos uma guia
                digital com o resumo do seu pedido.
              </li>
              <li className="flex items-start gap-2">
                <MessageCircle className="mt-0.5 size-4 shrink-0 text-success" /> O pagamento (PIX ou
                cartão) é combinado no WhatsApp com a equipe.
              </li>
              <li className="flex items-start gap-2">
                <ShieldCheck className="mt-0.5 size-4 shrink-0 text-success" /> Nenhum dado de
                pagamento é solicitado neste site.
              </li>
            </ul>
            <Button variant="ghost" className="w-full" asChild>
              <Link to="/carrinho">Voltar ao carrinho</Link>
            </Button>
          </div>
        </aside>
      </form>
    </div>
  );
}
