import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import {
  ShieldCheck,
  Star,
  MapPin,
  Clock,
  FileText,
  FileClock,
  Flame,
  CalendarCheck,
  Check,
  ShoppingCart,
  ChevronRight,
} from "lucide-react";
import { toast } from "sonner";

import { ServiceCard } from "@/components/service-card";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/cart";
import {
  alternativesFor,
  categoryLabels,
  clinicById,
  formatPrice,
  getClinic,
  services,
} from "@/data/mock";

export const Route = createFileRoute("/servicos/$serviceId")({
  loader: ({ params }) => {
    const service = services.find((s) => s.id === params.serviceId);
    if (!service) throw notFound();
    return { service };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Serviço indisponível | Prev Bem" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const { service } = loaderData;
    const clinic = getClinic(service);
    const title = `${service.name} — ${formatPrice(service.price)} | Prev Bem`;
    const description = `${service.name} em ${clinic.name} (${clinic.neighborhood}, ${clinic.city}) por ${formatPrice(service.price)}. Agende como paciente particular na Prev Bem.`;
    return {
      meta: [
        { title },
        { name: "description", content: description },
        { property: "og:title", content: title },
        { property: "og:description", content: description },
      ],
    };
  },
  component: ServiceDetail,
});

function ServiceDetail() {
  const { service } = Route.useLoaderData();
  const { add, has } = useCart();
  const clinic = getClinic(service);
  const inCart = has(service.id);
  const discount = Math.round((1 - service.price / service.listPrice) * 100);

  const alternatives = alternativesFor(service);
  const cheapest = [service, ...alternatives].sort((a, b) => a.price - b.price)[0]!;

  const related = services
    .filter(
      (s) =>
        s.id !== service.id &&
        (s.specialty === service.specialty ||
          s.category === service.category ||
          s.clinicId === service.clinicId),
    )
    .sort((a, b) => {
      const score = (s: typeof service) =>
        (s.specialty === service.specialty ? 2 : 0) + (s.clinicId === service.clinicId ? 1 : 0);
      return score(b) - score(a) || b.demand - a.demand;
    })
    .slice(0, 3);

  const addToCart = () => {
    add(service.id);
    toast.success(inCart ? "Já está no carrinho" : "Adicionado ao carrinho", {
      description: service.name,
    });
  };

  return (
    <div className="mx-auto w-full max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <nav className="flex items-center gap-1.5 text-xs font-bold text-muted-foreground">
        <Link to="/" className="hover:text-primary">
          Início
        </Link>
        <ChevronRight className="size-3.5" />
        <Link to="/servicos" className="hover:text-primary">
          Serviços
        </Link>
        <ChevronRight className="size-3.5" />
        <span className="text-primary">{service.name}</span>
      </nav>

      <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <div className="surface-card p-7">
            <div className="flex flex-wrap items-center gap-3">
              <span className="rounded-full bg-secondary px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-primary">
                {categoryLabels[service.category]}
              </span>
              {service.popular && (
                <span className="inline-flex items-center gap-1 rounded-full bg-accent-soft px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-accent">
                  <Flame className="size-3" /> Mais procurado
                </span>
              )}
              <span className="inline-flex items-center gap-1 text-xs font-bold text-muted-foreground">
                <Star className="size-3.5 fill-accent text-accent" /> {service.rating.toFixed(1)} ·{" "}
                {service.reviews} avaliações
              </span>
            </div>
            <h1 className="mt-4 text-3xl sm:text-4xl">{service.name}</h1>
            <p className="mt-2 font-semibold text-muted-foreground">{service.specialty}</p>
            <p className="mt-6 leading-relaxed text-muted-foreground">{service.description}</p>

            <dl className="mt-7 grid gap-4 sm:grid-cols-3">
              <div className="rounded-2xl bg-secondary/60 p-4">
                <dt className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-primary">
                  <Clock className="size-3.5" /> Duração
                </dt>
                <dd className="mt-1 text-sm font-bold">{service.duration}</dd>
              </div>
              <div className="rounded-2xl bg-secondary/60 p-4">
                <dt className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-primary">
                  <FileClock className="size-3.5" /> Resultado
                </dt>
                <dd className="mt-1 text-sm font-bold">
                  {service.resultTime ?? "Não se aplica"}
                </dd>
              </div>
              <div className="rounded-2xl bg-secondary/60 p-4">
                <dt className="flex items-center gap-1.5 text-xs font-extrabold uppercase text-primary">
                  <CalendarCheck className="size-3.5" /> Agenda
                </dt>
                <dd className="mt-1 text-sm font-bold">Horários nesta semana</dd>
              </div>
            </dl>
          </div>

          {service.prep && (
            <div className="surface-card p-7">
              <h2 className="text-xl">Preparo necessário</h2>
              <p className="mt-4 flex items-start gap-2.5 rounded-2xl bg-accent-soft p-4 text-sm font-semibold leading-relaxed text-foreground">
                <FileText className="mt-0.5 size-4 shrink-0 text-accent" />
                {service.prep}
              </p>
              <p className="mt-4 text-sm text-muted-foreground">
                Dúvidas sobre o preparo? A equipe Prev Bem envia um lembrete por WhatsApp um dia
                antes do seu atendimento.
              </p>
            </div>
          )}

          <div className="surface-card p-7">
            <h2 className="text-xl">Clínica responsável</h2>
            <div className="mt-4 flex flex-wrap items-center gap-4">
              <span className="brand-gradient flex size-14 items-center justify-center rounded-2xl text-lg font-extrabold text-primary-foreground">
                {clinic.name.slice(0, 2).toUpperCase()}
              </span>
              <div>
                <p className="text-base font-extrabold">{clinic.name}</p>
                <p className="inline-flex items-start gap-1.5 text-sm font-semibold text-muted-foreground">
                  <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
                  {clinic.address}, {clinic.neighborhood} — {clinic.city}
                </p>
              </div>
            </div>
            <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
              Parceira Prev Bem desde 2023, com equipe multidisciplinar, estrutura acessível e
              atendimento humanizado.
            </p>
          </div>

          {alternatives.length > 0 && (
            <div className="surface-card p-7">
              <h2 className="text-xl">Compare preços em outras clínicas</h2>
              <p className="mt-1.5 text-sm font-semibold text-muted-foreground">
                O mesmo serviço está disponível em {alternatives.length + 1} clínicas parceiras de
                Teresina. Escolha a que for melhor para você.
              </p>
              <ul className="mt-5 space-y-3">
                {[service, ...alternatives]
                  .sort((a, b) => a.price - b.price)
                  .map((option) => {
                    const optionClinic = clinicById[option.clinicId]!;
                    const isCurrent = option.id === service.id;
                    return (
                      <li
                        key={option.id}
                        className={`flex flex-wrap items-center justify-between gap-3 rounded-2xl border-2 p-4 ${
                          isCurrent ? "border-primary/40 bg-secondary/50" : "border-border"
                        }`}
                      >
                        <div className="min-w-0">
                          <p className="text-sm font-extrabold">
                            {optionClinic.name}
                            {option.id === cheapest.id && (
                              <span className="ml-2 rounded-full bg-success/15 px-2 py-0.5 text-[11px] font-extrabold uppercase tracking-wide text-success">
                                Menor preço
                              </span>
                            )}
                          </p>
                          <p className="inline-flex items-start gap-1.5 text-xs font-semibold text-muted-foreground">
                            <MapPin className="mt-0.5 size-3 shrink-0 text-primary" />
                            {optionClinic.neighborhood} — {optionClinic.city}
                          </p>
                          {option.resultTime && (
                            <p className="text-xs font-semibold text-muted-foreground">
                              Resultado {option.resultTime}
                            </p>
                          )}
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="text-right">
                            <p className="text-xs font-semibold text-muted-foreground line-through">
                              {formatPrice(option.listPrice)}
                            </p>
                            <p className="text-lg font-extrabold text-accent">
                              {formatPrice(option.price)}
                            </p>
                          </div>
                          {isCurrent ? (
                            <span className="text-xs font-extrabold uppercase tracking-wide text-primary">
                              Selecionada
                            </span>
                          ) : (
                            <Button variant="soft" size="sm" asChild>
                              <Link
                                to="/servicos/$serviceId"
                                params={{ serviceId: option.id }}
                              >
                                Ver oferta
                              </Link>
                            </Button>
                          )}
                        </div>
                      </li>
                    );
                  })}
              </ul>
            </div>
          )}

          <div className="surface-card p-7">
            <h2 className="text-xl">O que está incluído</h2>
            <ul className="mt-4 space-y-3 text-sm font-semibold text-muted-foreground">
              {[
                "Atendimento com profissional registrado no CRM/CRO",
                "Laudo ou receita digital na sua área do paciente",
                "Reagendamento gratuito até 24h antes",
                "Suporte da Prev Bem por WhatsApp",
              ].map((item) => (
                <li key={item} className="flex items-start gap-2.5">
                  <ShieldCheck className="mt-0.5 size-4 shrink-0 text-success" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <aside className="h-fit lg:sticky lg:top-24">
          <div className="surface-card space-y-5 p-6">
            <div>
              <p className="text-sm font-semibold text-muted-foreground line-through">
                Preço de tabela {formatPrice(service.listPrice)}
              </p>
              <p className="text-4xl font-extrabold text-accent">{formatPrice(service.price)}</p>
              <p className="mt-1 text-xs font-extrabold uppercase tracking-wide text-success">
                {discount}% de economia com a Prev Bem
              </p>
              <p className="mt-1 text-xs font-semibold text-muted-foreground">
                Valor final para paciente particular
              </p>
            </div>

            <Button
              variant={inCart ? "soft" : "cta"}
              size="lg"
              className="w-full"
              onClick={addToCart}
            >
              {inCart ? <Check /> : <ShoppingCart />}
              {inCart ? "No carrinho" : "Adicionar ao carrinho"}
            </Button>
            <Button variant="outline" size="lg" className="w-full" asChild>
              <Link to="/carrinho">Ir para o carrinho</Link>
            </Button>

            <p className="rounded-2xl bg-secondary/60 p-4 text-xs font-semibold leading-relaxed text-foreground">
              Você escolhe data e horário na etapa de finalização. A confirmação chega por e-mail e
              na área do paciente.
            </p>
          </div>
        </aside>
      </div>

      {related.length > 0 && (
        <section className="mt-14">
          <h2 className="text-2xl">Serviços relacionados</h2>
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {related.map((s) => (
              <ServiceCard key={s.id} service={s} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
