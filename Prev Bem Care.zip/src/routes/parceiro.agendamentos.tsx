import { createFileRoute } from "@tanstack/react-router";
import { MessageCircle, Search } from "lucide-react";
import { useMemo, useState } from "react";

import { PartnerCard, StatusPill } from "@/components/partner/partner-ui";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { buildWhatsAppUrl } from "@/config/contact";
import { usePartner } from "@/context/partner";
import { orderStatuses } from "@/data/admin-mock";
import { formatPrice } from "@/data/mock";

export const Route = createFileRoute("/parceiro/agendamentos")({
  component: PartnerOrders,
});

const formatDate = (iso: string) =>
  new Date(iso).toLocaleString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

function PartnerOrders() {
  const { orders, clinic } = usePartner();
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<string>("todos");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return orders.filter(
      (o) =>
        (status === "todos" || o.status === status) &&
        (!q ||
          o.patientName.toLowerCase().includes(q) ||
          o.number.toLowerCase().includes(q) ||
          o.items.some((i) => i.name.toLowerCase().includes(q))),
    );
  }, [orders, query, status]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">Agendamentos recebidos</h1>
        <p className="text-sm font-semibold text-muted-foreground">
          Pedidos gerados na Prev Bem para a {clinic?.name}. O pagamento é confirmado pela equipe
          Prev Bem antes do atendimento.
        </p>
      </div>

      <PartnerCard className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por paciente, pedido ou serviço"
              className="h-9 pl-9 text-[13px]"
            />
          </div>
          <div className="flex gap-1 overflow-x-auto">
            {["todos", ...orderStatuses].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setStatus(s)}
                className={`shrink-0 rounded-lg px-3 py-1.5 text-[12px] font-bold transition-colors ${
                  status === s
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary text-muted-foreground hover:text-primary"
                }`}
              >
                {s === "todos" ? "Todos" : s}
              </button>
            ))}
          </div>
        </div>
      </PartnerCard>

      <div className="space-y-3">
        {filtered.map((o) => (
          <PartnerCard key={o.id} className="p-5">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="text-[13px] font-extrabold">{o.number}</p>
                  <StatusPill status={o.status} />
                </div>
                <p className="mt-1 text-sm font-extrabold">{o.patientName}</p>
                <p className="text-[12px] font-semibold text-muted-foreground">
                  {o.phone} · gerado em {formatDate(o.createdAt)}
                </p>
              </div>
              <div className="text-right">
                <p className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                  Sua clínica
                </p>
                <p className="text-lg font-extrabold text-primary">{formatPrice(o.clinicTotal)}</p>
              </div>
            </div>

            <ul className="mt-4 divide-y divide-border rounded-xl bg-secondary/40 px-3">
              {o.items.map((i) => (
                <li key={i.name} className="flex items-center justify-between gap-3 py-2">
                  <p className="truncate text-[12px] font-bold">
                    {i.name}
                    {i.qty > 1 ? ` (x${i.qty})` : ""}
                  </p>
                  <p className="shrink-0 text-[12px] font-extrabold">
                    {formatPrice(i.unitPrice * i.qty)}
                  </p>
                </li>
              ))}
            </ul>

            <div className="mt-4 flex flex-wrap items-center gap-2">
              <Button variant="soft" size="sm" asChild>
                <a
                  href={buildWhatsAppUrl(
                    `Olá! Sou da ${clinic?.name} e gostaria de tratar do pedido ${o.number} (paciente ${o.patientName}).`,
                  )}
                  target="_blank"
                  rel="noreferrer"
                >
                  <MessageCircle /> Falar com a Prev Bem
                </a>
              </Button>
              <p className="text-[11px] font-semibold text-muted-foreground">
                Valor total do pedido do paciente: {formatPrice(o.orderTotal)}
              </p>
            </div>
          </PartnerCard>
        ))}
        {filtered.length === 0 && (
          <PartnerCard className="p-10 text-center text-[13px] font-semibold text-muted-foreground">
            Nenhum agendamento encontrado com esses filtros.
          </PartnerCard>
        )}
      </div>
    </div>
  );
}
