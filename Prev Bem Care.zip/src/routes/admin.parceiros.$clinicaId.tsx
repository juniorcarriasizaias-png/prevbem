import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowLeft, Plus, Save, Search, Upload } from "lucide-react";
import { toast } from "sonner";

import { useCatalogAdmin, type AdminClinica, type OfferingRow } from "@/context/catalog-admin";
import { categoriaLabels, categoriaOrder } from "@/data/catalog";
import { newOfferingRow } from "@/lib/service-sheet";
import { ImportSheetDialog } from "@/components/admin/import-sheet-dialog";
import {
  OfferingSheetTable,
  SheetToggle,
} from "@/components/admin/offering-sheet-table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export const Route = createFileRoute("/admin/parceiros/$clinicaId")({
  component: ClinicaDetail,
});

function ClinicaDetail() {
  const { clinicaId } = Route.useParams();
  const { clinicaById, offeringsByClinica, catalogItems, saveClinica, saveClinicaOfferings } =
    useCatalogAdmin();
  const clinica = clinicaById(clinicaId);

  const initialRows = useMemo<OfferingRow[]>(() => {
    return offeringsByClinica(clinicaId).map((o) => {
      const item = catalogItems.find((i) => i.id === o.catalogItemId);
      return {
        id: o.id,
        catalogItemId: o.catalogItemId,
        categoria: item?.categoria ?? "exame_laboratorial",
        nome: item?.nome ?? "",
        especialidade: item?.especialidade ?? "",
        precoDeTabela: o.precoDeTabela ? String(o.precoDeTabela) : "",
        preco: String(o.preco),
        prazoResultado: o.prazoResultado ?? "",
        ativo: o.ativo,
      };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [clinicaId]);

  const [rows, setRowsState] = useState<OfferingRow[]>(initialRows);
  const [dirty, setDirty] = useState(false);
  const [query, setQuery] = useState("");
  const [categoriaFilter, setCategoriaFilter] = useState<string>("todas");
  const [importOpen, setImportOpen] = useState(false);
  const [header, setHeader] = useState<AdminClinica | null>(null);

  const setRows = (updater: (prev: OfferingRow[]) => OfferingRow[]) => {
    setRowsState(updater);
    setDirty(true);
  };

  if (!clinica) {
    return (
      <div className="rounded-xl border border-border bg-card p-6 text-[13px] font-semibold">
        Clínica não encontrada.{" "}
        <Link to="/admin/parceiros" className="text-primary hover:underline">
          Voltar para a lista
        </Link>
      </div>
    );
  }

  const draft = header ?? clinica;

  const visible = rows.filter(
    (r) =>
      (categoriaFilter === "todas" || r.categoria === categoriaFilter) &&
      (!query.trim() ||
        r.nome.toLowerCase().includes(query.trim().toLowerCase()) ||
        r.especialidade.toLowerCase().includes(query.trim().toLowerCase())),
  );

  const ativos = rows.filter((r) => r.ativo).length;

  const save = () => {
    const report = saveClinicaOfferings(clinicaId, rows);
    if (header) {
      saveClinica(header);
      setHeader(null);
    }
    setDirty(false);
    toast.success(
      `Alterações salvas · ${report.created} novo(s) item(ns) no catálogo, ${report.linked} vinculado(s) a itens existentes.`,
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <Link
          to="/admin/parceiros"
          className="inline-flex items-center gap-1.5 text-[12px] font-bold text-primary hover:underline"
        >
          <ArrowLeft className="size-3.5" /> Parceiros e catálogo
        </Link>
        {dirty && (
          <span className="rounded-full bg-accent-soft px-2.5 py-1 text-[11px] font-extrabold text-accent">
            Alterações não salvas
          </span>
        )}
      </div>

      {/* Cabeçalho editável da clínica */}
      <section className="rounded-xl border border-border bg-card p-4">
        <div className="grid gap-3 md:grid-cols-2">
          <div className="space-y-1.5">
            <Label className="text-[11px] uppercase tracking-wide">Nome da clínica</Label>
            <Input
              className="h-9 text-[13px] font-bold"
              value={draft.nome}
              onChange={(e) => {
                setHeader({ ...draft, nome: e.target.value });
                setDirty(true);
              }}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[11px] uppercase tracking-wide">Endereço</Label>
            <Input
              className="h-9 text-[13px]"
              value={draft.endereco}
              onChange={(e) => {
                setHeader({ ...draft, endereco: e.target.value, address: e.target.value });
                setDirty(true);
              }}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[11px] uppercase tracking-wide">Telefone</Label>
            <Input
              className="h-9 text-[13px]"
              value={draft.telefone ?? ""}
              onChange={(e) => {
                setHeader({ ...draft, telefone: e.target.value });
                setDirty(true);
              }}
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-[11px] uppercase tracking-wide">
              Especialidades atendidas (separadas por vírgula)
            </Label>
            <Input
              className="h-9 text-[13px]"
              value={draft.especialidadesAtendidas.join(", ")}
              onChange={(e) => {
                setHeader({
                  ...draft,
                  especialidadesAtendidas: e.target.value
                    .split(",")
                    .map((s) => s.trim())
                    .filter(Boolean),
                });
                setDirty(true);
              }}
            />
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between rounded-lg bg-muted px-3 py-2">
          <span className="text-[12px] font-bold">Clínica ativa na plataforma</span>
          <SheetToggle
            checked={draft.ativo}
            onChange={(checked) => {
              setHeader({ ...draft, ativo: checked });
              setDirty(true);
            }}
          />
        </div>
      </section>

      {/* Barra de ferramentas da planilha */}
      <section className="flex flex-col gap-3 rounded-xl border border-border bg-card p-4 lg:flex-row lg:items-center lg:justify-between">
        <div>
          <h2 className="text-[13px] font-extrabold uppercase tracking-wider text-primary">
            Serviços ofertados
          </h2>
          <p className="text-[12px] font-semibold text-muted-foreground">
            {rows.length} serviços cadastrados, {ativos} ativos
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative w-full sm:w-56">
            <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar na tabela"
              className="h-9 pl-9 text-[13px]"
            />
          </div>
          <select
            value={categoriaFilter}
            onChange={(e) => setCategoriaFilter(e.target.value)}
            className="h-9 rounded-md border border-input bg-background px-2 text-[12.5px] font-semibold"
          >
            <option value="todas">Todas as categorias</option>
            {categoriaOrder.map((c) => (
              <option key={c} value={c}>
                {categoriaLabels[c]}
              </option>
            ))}
          </select>
          <Button
            variant="outline"
            size="sm"
            className="h-9 gap-1.5 text-[12px]"
            onClick={() => setImportOpen(true)}
          >
            <Upload className="size-3.5" /> Importar planilha
          </Button>
          <Button
            variant="soft"
            size="sm"
            className="h-9 gap-1.5 text-[12px]"
            onClick={() => setRows((prev) => [...prev, newOfferingRow()])}
          >
            <Plus className="size-3.5" /> Adicionar serviço
          </Button>
          <Button
            variant="cta"
            size="sm"
            className="h-9 gap-1.5 text-[12px]"
            onClick={save}
            disabled={!dirty}
          >
            <Save className="size-3.5" /> Salvar alterações
          </Button>
        </div>
      </section>

      <OfferingSheetTable
        rows={rows}
        setRows={setRows}
        catalogItems={catalogItems}
        visibleRows={visible}
      />

      <ImportSheetDialog
        open={importOpen}
        onOpenChange={setImportOpen}
        onImport={(imported) => {
          setRows((prev) => [...prev, ...imported]);
          toast.success(`${imported.length} linha(s) importada(s). Revise e salve.`);
        }}
      />
    </div>
  );
}
