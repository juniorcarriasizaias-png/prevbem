import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, MapPin, Minus, Plus, ShoppingCart, Tag, Trash2, MessageCircle } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCart } from "@/context/cart";
import { formatPrice, getClinic } from "@/data/mock";

export const Route = createFileRoute("/carrinho")({
  head: () => ({
    meta: [
      { title: "Meu carrinho | Prev Bem" },
      {
        name: "description",
        content:
          "Revise os serviços de saúde selecionados, ajuste quantidades e siga para gerar sua guia de agendamento na Prev Bem.",
      },
      { property: "og:title", content: "Meu carrinho | Prev Bem" },
      {
        property: "og:description",
        content: "Confira os serviços escolhidos antes de gerar sua guia de agendamento.",
      },
    ],
  }),
  component: Cart,
});

function Cart() {
  const { lines, subtotal, savings, count, remove, setQty } = useCart();

  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-3xl sm:text-4xl">Meu carrinho</h1>
      <p className="mt-2 text-muted-foreground">
        {count} {count === 1 ? "item selecionado" : "itens selecionados"}. Revise antes de gerar sua
        guia de agendamento.
      </p>

      {lines.length === 0 ? (
        <div className="surface-card mt-8 p-10 text-center">
          <ShoppingCart className="mx-auto size-10 text-primary" />
          <h2 className="mt-4 text-lg">Seu carrinho está vazio</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Explore o catálogo e adicione consultas, exames ou procedimentos.
          </p>
          <Button variant="cta" className="mt-5" asChild>
            <Link to="/servicos">Ver serviços</Link>
          </Button>
        </div>
      ) : (
        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
          <div className="space-y-4">
            {lines.map(({ service, qty }) => {
              const clinic = getClinic(service);
              return (
                <div key={service.id} className="surface-card flex flex-col gap-4 p-6 sm:flex-row">
                  <span className="brand-gradient flex size-14 shrink-0 items-center justify-center rounded-2xl text-lg font-extrabold text-primary-foreground">
                    {clinic.name.slice(0, 2).toUpperCase()}
                  </span>
                  <div className="flex-1 space-y-1.5">
                    <h2 className="text-base font-extrabold">{service.name}</h2>
                    <p className="text-sm font-semibold text-muted-foreground">
                      {service.specialty}
                    </p>
                    <p className="inline-flex items-start gap-1.5 text-xs font-semibold text-muted-foreground">
                      <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
                      {clinic.name} · {clinic.address}, {clinic.neighborhood} — {clinic.city}
                    </p>
                    {service.prep && (
                      <p className="text-xs font-bold text-accent">Preparo: {service.prep}</p>
                    )}
                    <div className="flex items-center gap-2 pt-2">
                      <Button
                        variant="soft"
                        size="icon"
                        className="size-9 rounded-full"
                        aria-label={`Diminuir quantidade de ${service.name}`}
                        onClick={() => setQty(service.id, qty - 1)}
                      >
                        <Minus />
                      </Button>
                      <span
                        className="min-w-9 text-center text-sm font-extrabold"
                        aria-label={`Quantidade de ${service.name}`}
                      >
                        {qty}
                      </span>
                      <Button
                        variant="soft"
                        size="icon"
                        className="size-9 rounded-full"
                        aria-label={`Aumentar quantidade de ${service.name}`}
                        onClick={() => setQty(service.id, qty + 1)}
                      >
                        <Plus />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between gap-4 sm:flex-col sm:items-end">
                    <div className="text-right">
                      <p className="text-xs font-semibold text-muted-foreground line-through">
                        {formatPrice(service.listPrice * qty)}
                      </p>
                      <p className="text-lg font-extrabold text-accent">
                        {formatPrice(service.price * qty)}
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      aria-label={`Remover ${service.name}`}
                      onClick={() => remove(service.id)}
                    >
                      <Trash2 /> Remover
                    </Button>
                  </div>
                </div>
              );
            })}

            <div className="surface-card flex flex-col gap-3 p-6 sm:flex-row sm:items-center">
              <div className="relative flex-1">
                <Tag className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Cupom de desconto"
                  className="h-11 rounded-full border-none bg-secondary/60 pl-11 font-semibold"
                  aria-label="Cupom de desconto"
                />
              </div>
              <Button variant="soft">Aplicar</Button>
            </div>

            <Link
              to="/servicos"
              className="inline-flex items-center gap-1.5 text-sm font-extrabold text-primary hover:underline"
            >
              Continuar procurando serviços <ArrowRight className="size-4" />
            </Link>
          </div>

          <aside className="h-fit lg:sticky lg:top-24">
            <div className="surface-card space-y-4 p-6">
              <h2 className="text-lg">Resumo</h2>
              <dl className="space-y-3 text-sm font-semibold">
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Subtotal</dt>
                  <dd>{formatPrice(subtotal)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Economia Prev Bem</dt>
                  <dd className="text-success">- {formatPrice(savings)}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-muted-foreground">Taxa de serviço</dt>
                  <dd className="text-success">Grátis</dd>
                </div>
              </dl>
              <div className="flex items-baseline justify-between border-t border-border pt-4">
                <span className="text-sm font-extrabold">Total</span>
                <span className="text-2xl font-extrabold text-primary">
                  {formatPrice(subtotal)}
                </span>
              </div>
              <Button variant="cta" size="lg" className="w-full" asChild>
                <Link to="/finalizar">Finalizar pedido</Link>
              </Button>
              <p className="inline-flex items-start gap-2 rounded-2xl bg-primary-soft px-4 py-3 text-xs font-semibold text-primary">
                <MessageCircle className="mt-0.5 size-4 shrink-0" />
                Nenhum pagamento acontece no site: geramos sua guia e você combina o PIX ou cartão
                direto com nossa equipe pelo WhatsApp, com todo cuidado.
              </p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
