import { createFileRoute, Link, Outlet, useRouterState } from "@tanstack/react-router";
import { CalendarRange, Handshake, LayoutDashboard, LogOut, Stethoscope, Wallet } from "lucide-react";

import { PartnerProvider, usePartner } from "@/context/partner";
import { RoleGuard } from "@/components/auth/role-guard";
import { partnerAccounts } from "@/data/partner-mock";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/parceiro")({
  head: () => ({
    meta: [
      { title: "Portal do parceiro — Prev Bem" },
      {
        name: "description",
        content:
          "Portal das clínicas parceiras Prev Bem: agendamentos recebidos, gestão dos próprios serviços e preços, e relatório de faturamento pela plataforma.",
      },
      { property: "og:title", content: "Portal do parceiro — Prev Bem" },
      {
        property: "og:description",
        content: "Área exclusiva das clínicas parceiras da Prev Bem.",
      },
      { name: "robots", content: "noindex" },
    ],
  }),
  component: PartnerLayout,
});

const nav = [
  { to: "/parceiro", label: "Visão geral", icon: LayoutDashboard, exact: true },
  { to: "/parceiro/agendamentos", label: "Agendamentos", icon: CalendarRange, exact: false },
  { to: "/parceiro/servicos", label: "Meus serviços", icon: Stethoscope, exact: false },
  { to: "/parceiro/faturamento", label: "Faturamento", icon: Wallet, exact: false },
] as const;

function PartnerLayout() {
  return (
    <RoleGuard allow={["admin", "parceiro"]}>
      <PartnerProvider>
        <PartnerShell />
      </PartnerProvider>
    </RoleGuard>
  );
}

function PartnerShell() {
  const { account } = usePartner();
  if (!account) return <PartnerLogin />;

  return (
    <div className="min-h-screen bg-primary-soft/40">
      <PartnerTopbar />
      <div className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6">
        <Outlet />
      </div>
    </div>
  );
}

function PartnerTopbar() {
  const { account, clinic, signOut } = usePartner();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-20 border-b border-primary/15 bg-card/95 backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary-soft text-primary">
            <Handshake className="size-4.5" />
          </span>
          <div className="min-w-0">
            <p className="text-[11px] font-bold uppercase tracking-wider text-primary">
              Portal do parceiro
            </p>
            <p className="truncate text-sm font-extrabold">{clinic?.name}</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <div className="hidden text-right sm:block">
            <p className="text-[12px] font-extrabold leading-tight">{account?.contactName}</p>
            <p className="text-[11px] font-semibold text-muted-foreground">{account?.role}</p>
          </div>
          <Button variant="outline" size="sm" onClick={signOut} className="h-8 gap-1.5 text-[12px]">
            <LogOut className="size-3.5" /> Sair
          </Button>
        </div>
      </div>
      <nav className="mx-auto flex w-full max-w-6xl gap-1 overflow-x-auto border-t border-border/70 px-2 py-2 sm:px-4">
        {nav.map((item) => {
          const active = item.exact ? pathname === item.to : pathname.startsWith(item.to);
          return (
            <Link
              key={item.to}
              to={item.to}
              className={`flex shrink-0 items-center gap-1.5 rounded-xl px-3 py-1.5 text-[12px] font-bold transition-colors ${
                active
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-secondary hover:text-primary"
              }`}
            >
              <item.icon className="size-3.5" />
              {item.label}
            </Link>
          );
        })}
      </nav>
    </header>
  );
}

function PartnerLogin() {
  const { selectAccount } = usePartner();

  return (
    <div className="grid min-h-screen place-items-center bg-primary-soft/60 px-4 py-12">
      <div className="w-full max-w-sm rounded-3xl border border-primary/15 bg-card p-7 shadow-soft">
        <div className="flex items-center gap-2.5">
          <span className="grid size-10 place-items-center rounded-xl bg-primary-soft text-primary">
            <Handshake className="size-5" />
          </span>
          <div>
            <h1 className="text-base font-extrabold">Prev Bem · Parceiros</h1>
            <p className="text-[12px] font-semibold text-muted-foreground">
              Escolha a clínica que você administra
            </p>
          </div>
        </div>

        <div className="mt-6 space-y-2">
          {partnerAccounts.map((account) => (
            <button
              key={account.email}
              type="button"
              onClick={() => selectAccount(account.email)}
              className="w-full rounded-2xl border border-border px-4 py-3 text-left transition-colors hover:border-primary hover:bg-secondary"
            >
              <span className="block text-[13px] font-extrabold">{account.contactName}</span>
              <span className="block text-[11px] font-semibold text-muted-foreground">
                {account.email}
              </span>
            </button>
          ))}
        </div>

        <p className="mt-4 rounded-2xl bg-secondary/70 p-3 text-[11px] font-semibold text-muted-foreground">
          O acesso a esta área é liberado pelo papel da sua conta no banco de dados Prev Bem.
        </p>
      </div>
    </div>
  );
}
