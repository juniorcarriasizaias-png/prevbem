import { Link } from "@tanstack/react-router";
import { Check, Clock, FileClock, Flame, MapPin, ShoppingCart, Star } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { useCart } from "@/context/cart";
import { useReviews } from "@/context/reviews";
import { categoryLabels, formatPrice, getClinic, type Service } from "@/data/mock";

export function ServiceCard({ service }: { service: Service }) {
  const { add, has } = useCart();
  const { summaryFor } = useReviews();
  const summary = summaryFor(service.id);
  const clinic = getClinic(service);
  const inCart = has(service.id);
  const discount = Math.round((1 - service.price / service.listPrice) * 100);

  return (
    <article className="surface-card flex flex-col gap-4 p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="rounded-full bg-secondary px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-primary">
            {categoryLabels[service.category]}
          </span>
          {service.popular && (
            <span className="inline-flex items-center gap-1 rounded-full bg-accent-soft px-2.5 py-1 text-[11px] font-extrabold uppercase tracking-wide text-accent">
              <Flame className="size-3" /> Mais procurado
            </span>
          )}
        </div>
        <span
          className="inline-flex items-center gap-1 text-xs font-bold text-muted-foreground"
          title={`Média de ${summary.rating.toFixed(1)} em ${summary.reviews} avaliações de pacientes`}
        >
          <Star className="size-3.5 fill-accent text-accent" />
          {summary.rating.toFixed(1)}
          <span className="font-medium">({summary.reviews})</span>
        </span>
      </div>

      <div className="space-y-1.5">
        <h3 className="text-base font-extrabold leading-snug text-foreground">
          <Link
            to="/servicos/$serviceId"
            params={{ serviceId: service.id }}
            className="hover:text-primary"
          >
            {service.name}
          </Link>
        </h3>
        <p className="text-sm font-semibold text-muted-foreground">{service.specialty}</p>
      </div>

      <ul className="space-y-1.5 text-xs font-semibold text-muted-foreground">
        <li className="flex items-start gap-1.5">
          <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
          <span>
            {clinic.name} · {clinic.address}, {clinic.neighborhood} — {clinic.city}
          </span>
        </li>
        <li className="flex items-center gap-1.5">
          <Clock className="size-3.5 text-primary" /> {service.duration}
        </li>
        {service.resultTime && (
          <li className="flex items-center gap-1.5">
            <FileClock className="size-3.5 text-primary" /> Resultado {service.resultTime}
          </li>
        )}
      </ul>

      <div className="mt-auto space-y-4 border-t border-border pt-4">
        <div className="flex items-end justify-between gap-3">
          <div>
            <p className="text-xs font-semibold text-muted-foreground line-through">
              De {formatPrice(service.listPrice)}
            </p>
            <p className="text-2xl font-extrabold text-accent">{formatPrice(service.price)}</p>
            <p className="text-[11px] font-extrabold uppercase tracking-wide text-success">
              {discount}% de economia
            </p>
          </div>
          <Button variant="ghost" size="sm" asChild>
            <Link to="/servicos/$serviceId" params={{ serviceId: service.id }}>
              Detalhes
            </Link>
          </Button>
        </div>
        <Button
          variant={inCart ? "soft" : "cta"}
          className="w-full"
          onClick={() => {
            add(service.id);
            toast.success(inCart ? "Já está no carrinho" : "Adicionado ao carrinho", {
              description: service.name,
            });
          }}
        >
          {inCart ? <Check /> : <ShoppingCart />}
          {inCart ? "No carrinho" : "Adicionar ao carrinho"}
        </Button>
      </div>
    </article>
  );
}
