import { Link } from "@tanstack/react-router";
import { HeartPulse } from "lucide-react";

import { useSiteSettings } from "@/context/site-settings";

export function Logo({ inverted = false }: { inverted?: boolean }) {
  const { settings } = useSiteSettings();

  return (
    <Link to="/" className="flex items-center gap-2.5">
      {settings.logo_url ? (
        <img
          src={settings.logo_url}
          alt={`Logo ${settings.nome_site}`}
          className="size-10 rounded-2xl object-contain"
        />
      ) : (
        <span
          className={
            inverted
              ? "flex size-10 items-center justify-center rounded-2xl bg-primary-foreground/15 text-primary-foreground"
              : "brand-gradient flex size-10 items-center justify-center rounded-2xl text-primary-foreground"
          }
        >
          <HeartPulse className="size-5" strokeWidth={2.5} />
        </span>
      )}
      <span className="flex flex-col leading-none">
        <span
          className={
            inverted
              ? "text-xl font-extrabold text-primary-foreground"
              : "text-xl font-extrabold text-primary"
          }
        >
          {settings.nome_site}
        </span>
        <span
          className={
            inverted
              ? "text-[11px] font-semibold text-primary-foreground/70"
              : "text-[11px] font-semibold text-muted-foreground"
          }
        >
          saúde acessível
        </span>
      </span>
    </Link>
  );
}
