import { useState } from "react";
import { Check, Percent, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { findSimilarItems, type OfferingRow } from "@/context/catalog-admin";
import { categoriaLabels, categoriaOrder, type CatalogItem, type Categoria } from "@/data/catalog";
import { formatPrice, isExameCategoria, newOfferingRow, parsePrice } from "@/lib/service-sheet";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const parsePasteGrid = (text: string) =>
  text
    .replace(/\r/g, "")
    .split("\n")
    .filter((line) => line.trim())
    .map((line) =>
      line.includes("\t") ? line.split("\t") : line.split(/[;,](?=(?:[^"]*"[^"]*")*[^"]*$)/),
    )
    .map((cells) => cells.map((c) => c.trim().replace(/^"|"$/g, "")));

export function OfferingSheetTable({
  rows,
  setRows,
  catalogItems,
  visibleRows,
}: {
  rows: OfferingRow[];
  setRows: (updater: (prev: OfferingRow[]) => OfferingRow[]) => void;
  catalogItems: CatalogItem[];
  /** subconjunto exibido (busca/filtro); default: todas */
  visibleRows?: OfferingRow[];
}) {
  const visible = visibleRows ?? rows;
  const [selected, setSelected] = useState<string[]>([]);
  const [percent, setPercent] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const selectedRows = rows.filter((r) => selected.includes(r.id));
  const allVisibleSelected =
    visible.length > 0 && visible.every((r) => selected.includes(r.id));

  const update = (id: string, patch: Partial<OfferingRow>) =>
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...patch } : r)));

  const patchSelected = (patch: Partial<OfferingRow>) =>
    setRows((prev) => prev.map((r) => (selected.includes(r.id) ? { ...r, ...patch } : r)));

  const addRow = () => setRows((prev) => [...prev, newOfferingRow()]);

  const applyPercent = () => {
    const pct = Number(percent.replace(",", "."));
    if (!Number.isFinite(pct) || pct === 0) {
      toast.error("Informe um percentual válido (ex.: 10 ou -5).");
      return;
    }
    setRows((prev) =>
      prev.map((row) => {
        if (!selected.includes(row.id)) return row;
        const base = parsePrice(row.preco);
        if (!Number.isFinite(base) || base <= 0) return row;
        const next = Math.max(0.01, base * (1 + pct / 100));
        return { ...row, preco: formatPrice(next) };
      }),
    );
    setPercent("");
    toast.success(`Preço reajustado em ${pct}% para ${selected.length} serviço(s).`);
  };

  const handlePaste = (rowId: string, event: React.ClipboardEvent<HTMLInputElement>) => {
    const text = event.clipboardData.getData("text/plain");
    if (!/\t|\n/.test(text)) return;
    event.preventDefault();
    const grid = parsePasteGrid(text);
    setRows((prev) => {
      const startIndex = prev.findIndex((r) => r.id === rowId);
      const next = [...prev];
      grid.forEach((cells, offset) => {
        const target = next[startIndex + offset] ?? newOfferingRow();
        const patched: OfferingRow = {
          ...target,
          nome: cells[0] ?? target.nome,
          especialidade: cells[1] ?? target.especialidade,
          precoDeTabela: cells[2] ?? target.precoDeTabela,
          preco: cells[3] ?? target.preco,
          prazoResultado: cells[4] ?? target.prazoResultado,
        };
        if (startIndex + offset < next.length) next[startIndex + offset] = patched;
        else next.push(patched);
      });
      return next;
    });
    toast.success(`${grid.length} linha(s) colada(s) da planilha.`);
  };

  return (
    <section className="rounded-xl border border-border bg-card">
      {selectedRows.length >= 2 && (
        <div className="flex flex-wrap items-center gap-2 border-b border-border bg-primary-soft/60 px-3 py-2">
          <span className="text-[12px] font-extrabold text-primary">
            {selectedRows.length} selecionados
          </span>
          <div className="flex items-center gap-1">
            <input
              value={percent}
              onChange={(e) => setPercent(e.target.value)}
              inputMode="decimal"
              placeholder="±%"
              aria-label="Percentual de reajuste"
              className="h-8 w-20 rounded-md border border-input bg-background px-2 text-[12px] font-bold outline-none focus:border-primary"
            />
            <Button variant="soft" size="sm" className="h-8 gap-1 text-[12px]" onClick={applyPercent}>
              <Percent className="size-3.5" /> Reajustar preço
            </Button>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="h-8 text-[12px]"
            onClick={() => patchSelected({ ativo: true })}
          >
            Ativar selecionados
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="h-8 text-[12px]"
            onClick={() => patchSelected({ ativo: false })}
          >
            Desativar selecionados
          </Button>
          <select
            aria-label="Mover para categoria"
            value=""
            onChange={(e) => {
              if (!e.target.value) return;
              patchSelected({ categoria: e.target.value as Categoria });
              toast.success("Categoria reatribuída em massa.");
              e.target.value = "";
            }}
            className="h-8 rounded-md border border-input bg-background px-2 text-[12px] font-semibold"
          >
            <option value="">Mover para categoria…</option>
            {categoriaOrder.map((c) => (
              <option key={c} value={c}>
                {categoriaLabels[c]}
              </option>
            ))}
          </select>
          <Button
            variant="ghost"
            size="sm"
            className="h-8 gap-1 text-[12px] text-destructive"
            onClick={() => setConfirmDelete(true)}
          >
            <Trash2 className="size-3.5" /> Excluir selecionados
          </Button>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full min-w-[1120px] text-left text-[12.5px]">
          <thead className="border-b border-border bg-muted/60 text-[10.5px] uppercase tracking-wide text-muted-foreground">
            <tr>
              <th className="p-2 font-bold">
                <input
                  type="checkbox"
                  aria-label="Selecionar todos os serviços"
                  checked={allVisibleSelected}
                  onChange={(e) =>
                    setSelected(e.target.checked ? visible.map((r) => r.id) : [])
                  }
                />
              </th>
              <th className="p-2 font-bold">Categoria</th>
              <th className="p-2 font-bold">Nome do serviço</th>
              <th className="p-2 font-bold">Especialidade</th>
              <th className="p-2 font-bold">Preço tabela</th>
              <th className="p-2 font-bold">Preço Prev Bem*</th>
              <th className="p-2 font-bold">Prazo resultado</th>
              <th className="p-2 font-bold">Status</th>
              <th className="p-2" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {visible.map((row) => (
              <ServiceRow
                key={row.id}
                row={row}
                selected={selected.includes(row.id)}
                onSelect={(checked) =>
                  setSelected((prev) =>
                    checked ? [...prev, row.id] : prev.filter((id) => id !== row.id),
                  )
                }
                onChange={(patch) => update(row.id, patch)}
                onRemove={() => setRows((prev) => prev.filter((r) => r.id !== row.id))}
                onPaste={(e) => handlePaste(row.id, e)}
                similar={findSimilarItems(catalogItems, row.nome, row.categoria)}
              />
            ))}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between gap-3 border-t border-border p-3">
        <p className="text-[11px] font-semibold text-muted-foreground">
          Dica: cole um bloco de planilha na coluna “Nome do serviço” para preencher várias linhas de
          uma vez. Selecione 2 ou mais linhas para editar em massa.
        </p>
        <Button variant="soft" size="sm" className="h-8 shrink-0 gap-1.5 text-[12px]" onClick={addRow}>
          <Plus className="size-3.5" /> Adicionar serviço
        </Button>
      </div>

      {visible.length === 0 && (
        <p className="p-6 text-center text-[12.5px] font-semibold text-muted-foreground">
          Nenhum serviço nessa visualização.
        </p>
      )}

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir {selectedRows.length} serviços?</AlertDialogTitle>
            <AlertDialogDescription>
              As linhas selecionadas serão removidas da tabela. A ação só é definitiva depois de
              salvar.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => {
                setRows((prev) => prev.filter((r) => !selected.includes(r.id)));
                setSelected([]);
                toast.success("Serviços removidos.");
              }}
            >
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}

function ServiceRow({
  row,
  selected,
  onSelect,
  onChange,
  onRemove,
  onPaste,
  similar,
}: {
  row: OfferingRow;
  selected: boolean;
  onSelect: (checked: boolean) => void;
  onChange: (patch: Partial<OfferingRow>) => void;
  onRemove: () => void;
  onPaste: (event: React.ClipboardEvent<HTMLInputElement>) => void;
  similar: { item: { id: string; nome: string; especialidade?: string }; score: number }[];
}) {
  const [focused, setFocused] = useState(false);
  const suggestions = similar.filter((s) => s.item.id !== row.catalogItemId);
  const showSuggestions = focused && !row.catalogItemId && suggestions.length > 0;

  return (
    <tr className={`align-top ${selected ? "bg-primary-soft/40" : "hover:bg-muted/40"}`}>
      <td className="p-2">
        <input
          type="checkbox"
          aria-label={`Selecionar ${row.nome || "serviço"}`}
          checked={selected}
          onChange={(e) => onSelect(e.target.checked)}
        />
      </td>
      <td className="p-1.5">
        <select
          value={row.categoria}
          onChange={(e) => onChange({ categoria: e.target.value as Categoria })}
          className="h-8 w-full rounded-md border border-input bg-background px-1.5 text-[12px] font-semibold"
        >
          {categoriaOrder.map((c) => (
            <option key={c} value={c}>
              {categoriaLabels[c]}
            </option>
          ))}
        </select>
      </td>
      <td className="relative p-1.5">
        <input
          value={row.nome}
          onChange={(e) => onChange({ nome: e.target.value, catalogItemId: undefined })}
          onPaste={onPaste}
          onFocus={() => setFocused(true)}
          onBlur={() => window.setTimeout(() => setFocused(false), 150)}
          placeholder="Ex.: Hemograma completo"
          className="h-8 w-full rounded-md border border-input bg-background px-2 text-[12.5px] font-bold outline-none focus:border-primary"
        />
        {row.catalogItemId && (
          <Check
            className="pointer-events-none absolute right-3 top-1/2 size-3.5 -translate-y-1/2 text-success"
            aria-label="Vinculado a um item do catálogo"
          />
        )}
        {showSuggestions && (
          <ul className="absolute left-1.5 top-full z-30 mt-1 w-64 overflow-hidden rounded-lg border border-border bg-card shadow-lg">
            <li className="border-b border-border bg-muted px-2 py-1 text-[10px] font-extrabold uppercase text-muted-foreground">
              Itens parecidos no catálogo
            </li>
            {suggestions.map(({ item }) => (
              <li key={item.id}>
                <button
                  type="button"
                  className="block w-full px-2 py-1.5 text-left text-[12px] font-semibold hover:bg-primary-soft"
                  onClick={() =>
                    onChange({
                      nome: item.nome,
                      catalogItemId: item.id,
                      ...(item.especialidade ? { especialidade: item.especialidade } : {}),
                    })
                  }
                >
                  {item.nome}
                </button>
              </li>
            ))}
          </ul>
        )}
      </td>
      <td className="p-1.5">
        <input
          value={row.especialidade}
          onChange={(e) => onChange({ especialidade: e.target.value })}
          placeholder="—"
          className="h-8 w-full rounded-md border border-input bg-background px-2 text-[12.5px] outline-none focus:border-primary"
        />
      </td>
      <td className="p-1.5">
        <input
          value={row.precoDeTabela}
          onChange={(e) => onChange({ precoDeTabela: e.target.value })}
          inputMode="decimal"
          placeholder="opcional"
          className="h-8 w-24 rounded-md border border-input bg-background px-2 text-[12.5px] outline-none focus:border-primary"
        />
      </td>
      <td className="p-1.5">
        <input
          value={row.preco}
          onChange={(e) => onChange({ preco: e.target.value })}
          inputMode="decimal"
          placeholder="0,00"
          className={`h-8 w-24 rounded-md border bg-background px-2 text-[12.5px] font-extrabold text-accent outline-none focus:border-primary ${
            row.preco ? "border-input" : "border-destructive/60"
          }`}
        />
      </td>
      <td className="p-1.5">
        <input
          value={row.prazoResultado}
          onChange={(e) => onChange({ prazoResultado: e.target.value })}
          disabled={!isExameCategoria(row.categoria)}
          placeholder={isExameCategoria(row.categoria) ? "até 24 horas" : "não se aplica"}
          className="h-8 w-full rounded-md border border-input bg-background px-2 text-[12.5px] outline-none focus:border-primary disabled:bg-muted disabled:text-muted-foreground"
        />
      </td>
      <td className="p-1.5">
        <SheetToggle checked={row.ativo} onChange={(checked) => onChange({ ativo: checked })} />
      </td>
      <td className="p-1.5">
        <Button
          variant="ghost"
          size="sm"
          className="h-8 px-2 text-destructive"
          onClick={onRemove}
          aria-label="Remover linha"
        >
          <Trash2 className="size-3.5" />
        </Button>
      </td>
    </tr>
  );
}

export function SheetToggle({
  checked,
  onChange,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`inline-flex h-5 w-9 shrink-0 items-center rounded-full border transition-colors ${
        checked ? "border-primary bg-primary" : "border-input bg-muted"
      }`}
    >
      <span
        className={`ml-0.5 size-4 rounded-full bg-background shadow transition-transform ${
          checked ? "translate-x-4" : "translate-x-0"
        }`}
      />
    </button>
  );
}
