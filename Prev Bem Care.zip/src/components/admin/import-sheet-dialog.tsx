import { useMemo, useRef, useState } from "react";
import { AlertTriangle, Download, FileSpreadsheet, Upload } from "lucide-react";
import { toast } from "sonner";

import {
  downloadTemplate,
  parseSpreadsheetFile,
  parseSpreadsheetText,
  rawToOfferingRow,
  validateRow,
  type RawSheetRow,
} from "@/lib/service-sheet";
import type { OfferingRow } from "@/context/catalog-admin";
import { categoriaLabels, categoriaOrder } from "@/data/catalog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export function ImportSheetDialog({
  open,
  onOpenChange,
  onImport,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onImport: (rows: OfferingRow[]) => void;
}) {
  const [rows, setRows] = useState<RawSheetRow[] | null>(null);
  const [text, setText] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  const validations = useMemo(
    () => (rows ?? []).map((row) => validateRow(row)),
    [rows],
  );
  const validCount = validations.filter((v) => v.errors.length === 0).length;
  const errorCount = validations.length - validCount;
  const selectedCount = (rows ?? []).filter((r) => r.selected).length;

  const load = (parsed: RawSheetRow[]) => {
    if (parsed.length === 0) {
      toast.error("Nenhuma linha foi encontrada na planilha.");
      return;
    }
    setRows(
      parsed.map((row) => ({ ...row, selected: validateRow(row).errors.length === 0 })),
    );
  };

  const update = (id: string, patch: Partial<RawSheetRow>) =>
    setRows((prev) =>
      (prev ?? []).map((row) => {
        if (row.id !== id) return row;
        const next = { ...row, ...patch };
        if (!("selected" in patch)) {
          next.selected = validateRow(next).errors.length === 0 ? next.selected || true : false;
        }
        return next;
      }),
    );

  const reset = () => {
    setRows(null);
    setText("");
  };

  const confirm = () => {
    const chosen = (rows ?? []).filter(
      (row) => row.selected && validateRow(row).errors.length === 0,
    );
    if (chosen.length === 0) {
      toast.error("Selecione ao menos uma linha válida.");
      return;
    }
    onImport(chosen.map(rawToOfferingRow));
    reset();
    onOpenChange(false);
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) reset();
        onOpenChange(next);
      }}
    >
      <DialogContent className="max-h-[90vh] overflow-hidden sm:max-w-5xl">
        <DialogHeader>
          <DialogTitle className="text-base">
            {rows ? "Prévia da importação" : "Importar planilha Excel/CSV"}
          </DialogTitle>
        </DialogHeader>

        {!rows && (
          <div className="space-y-3 text-[13px]">
            <p className="rounded-lg bg-muted p-3 text-[11.5px] font-semibold text-muted-foreground">
              Colunas esperadas, nesta ordem: Categoria · Nome do Serviço · Especialidade · Preço de
              Tabela · Preço Prev Bem · Prazo de Resultado. Baixe o modelo para garantir o formato.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                className="h-9 gap-1.5 text-[12px]"
                onClick={() => downloadTemplate("xlsx")}
              >
                <Download className="size-3.5" /> Baixar modelo (.xlsx)
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="h-9 gap-1.5 text-[12px]"
                onClick={() => downloadTemplate("csv")}
              >
                <Download className="size-3.5" /> Modelo em .csv
              </Button>
              <Button
                variant="cta"
                size="sm"
                className="h-9 gap-1.5 text-[12px]"
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="size-3.5" /> Importar planilha preenchida
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv,.tsv,.txt"
                className="hidden"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  e.target.value = "";
                  if (!file) return;
                  try {
                    load(await parseSpreadsheetFile(file));
                  } catch {
                    toast.error("Não foi possível ler esse arquivo.");
                  }
                }}
              />
            </div>
            <div className="space-y-1.5">
              <p className="text-[11.5px] font-bold text-muted-foreground">
                Ou cole aqui as linhas copiadas do Excel
              </p>
              <Textarea
                rows={6}
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="font-mono text-[11.5px]"
                placeholder={"Exame de laboratório\tHemograma completo\tHematologia\t80\t32\taté 24 horas"}
              />
              <Button
                variant="soft"
                size="sm"
                className="h-8 gap-1.5 text-[12px]"
                disabled={!text.trim()}
                onClick={() => load(parseSpreadsheetText(text))}
              >
                <FileSpreadsheet className="size-3.5" /> Ler linhas coladas
              </Button>
            </div>
          </div>
        )}

        {rows && (
          <div className="space-y-3 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 rounded-lg bg-muted px-3 py-2">
              <p className="text-[12.5px] font-extrabold">
                <span className="text-success">{validCount} linhas válidas</span> prontas para
                importar,{" "}
                <span className={errorCount ? "text-destructive" : "text-muted-foreground"}>
                  {errorCount} linhas com erro
                </span>
                <span className="font-semibold text-muted-foreground">
                  {" "}
                  · {selectedCount} selecionadas
                </span>
              </p>
              <Button variant="ghost" size="sm" className="h-7 text-[12px]" onClick={reset}>
                Escolher outro arquivo
              </Button>
            </div>

            <div className="max-h-[52vh] overflow-auto rounded-lg border border-border">
              <table className="w-full min-w-[1000px] text-left text-[12px]">
                <thead className="sticky top-0 z-10 border-b border-border bg-muted text-[10.5px] uppercase tracking-wide text-muted-foreground">
                  <tr>
                    <th className="p-2 font-bold">
                      <input
                        type="checkbox"
                        aria-label="Selecionar todas as linhas válidas"
                        checked={validCount > 0 && selectedCount === validCount}
                        onChange={(e) =>
                          setRows((prev) =>
                            (prev ?? []).map((row) => ({
                              ...row,
                              selected:
                                e.target.checked && validateRow(row).errors.length === 0,
                            })),
                          )
                        }
                      />
                    </th>
                    <th className="p-2 font-bold">Categoria</th>
                    <th className="p-2 font-bold">Nome do serviço</th>
                    <th className="p-2 font-bold">Especialidade</th>
                    <th className="p-2 font-bold">Preço tabela</th>
                    <th className="p-2 font-bold">Preço Prev Bem</th>
                    <th className="p-2 font-bold">Prazo</th>
                    <th className="p-2 font-bold">Validação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {rows.map((row, index) => {
                    const validation = validations[index]!;
                    const invalid = validation.errors.length > 0;
                    return (
                      <tr
                        key={row.id}
                        className={invalid ? "bg-destructive/8" : "hover:bg-muted/40"}
                      >
                        <td className="p-2">
                          <input
                            type="checkbox"
                            aria-label={`Importar linha ${index + 1}`}
                            checked={row.selected}
                            disabled={invalid}
                            onChange={(e) => update(row.id, { selected: e.target.checked })}
                          />
                        </td>
                        <td className="p-1.5">
                          <select
                            value={validation.categoria ?? ""}
                            onChange={(e) => update(row.id, { categoria: e.target.value })}
                            className={`h-8 w-full rounded-md border bg-background px-1.5 text-[12px] font-semibold ${
                              validation.categoria ? "border-input" : "border-destructive"
                            }`}
                          >
                            <option value="">Selecione…</option>
                            {categoriaOrder.map((c) => (
                              <option key={c} value={c}>
                                {categoriaLabels[c]}
                              </option>
                            ))}
                          </select>
                        </td>
                        <PreviewCell
                          value={row.nome}
                          bold
                          invalid={!row.nome.trim()}
                          onChange={(v) => update(row.id, { nome: v })}
                        />
                        <PreviewCell
                          value={row.especialidade}
                          onChange={(v) => update(row.id, { especialidade: v })}
                        />
                        <PreviewCell
                          value={row.precoDeTabela}
                          width="w-24"
                          onChange={(v) => update(row.id, { precoDeTabela: v })}
                        />
                        <PreviewCell
                          value={row.preco}
                          width="w-24"
                          bold
                          invalid={validation.errors.some((e) => e.includes("Preço Prev Bem"))}
                          onChange={(v) => update(row.id, { preco: v })}
                        />
                        <PreviewCell
                          value={row.prazoResultado}
                          onChange={(v) => update(row.id, { prazoResultado: v })}
                        />
                        <td className="p-2 align-middle">
                          {invalid ? (
                            <span className="inline-flex items-start gap-1 text-[11px] font-bold text-destructive">
                              <AlertTriangle className="mt-0.5 size-3 shrink-0" />
                              {validation.errors.join(" · ")}
                            </span>
                          ) : (
                            <span className="text-[11px] font-bold text-success">OK</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" size="sm" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          {rows && (
            <Button variant="cta" size="sm" onClick={confirm} disabled={selectedCount === 0}>
              Confirmar importação ({selectedCount})
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function PreviewCell({
  value,
  onChange,
  invalid,
  bold,
  width = "w-full",
}: {
  value: string;
  onChange: (value: string) => void;
  invalid?: boolean;
  bold?: boolean;
  width?: string;
}) {
  return (
    <td className="p-1.5">
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`h-8 ${width} rounded-md border bg-background px-2 text-[12px] outline-none focus:border-primary ${
          invalid ? "border-destructive" : "border-input"
        } ${bold ? "font-bold" : ""}`}
      />
    </td>
  );
}
