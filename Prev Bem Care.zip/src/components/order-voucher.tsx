import { forwardRef } from "react";
import { CalendarDays, HeartHandshake, MapPin } from "lucide-react";

import { formatPrice } from "@/data/mock";
import type { Order } from "@/context/orders";

export const OrderVoucher = forwardRef<HTMLDivElement, { order: Order }>(
  function OrderVoucher({ order }, ref) {
    const createdAt = new Date(order.createdAt);

    return (
      <div
        ref={ref}
        id="prevbem-guia"
        className="overflow-hidden rounded-3xl border border-border bg-card shadow-card print:shadow-none"
      >
        <div className="brand-gradient flex items-start justify-between gap-4 p-6 text-primary-foreground">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-primary-foreground/75">
              Guia digital de agendamento
            </p>
            <p className="mt-1 text-2xl font-extrabold">Prev Bem</p>
          </div>
          <div className="text-right">
            <p className="text-xs font-bold uppercase tracking-wide text-primary-foreground/75">
              Pedido
            </p>
            <p className="text-xl font-extrabold">{order.number}</p>
          </div>
        </div>

        <div className="space-y-5 p-6">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                Paciente
              </p>
              <p className="text-base font-extrabold">
                {order.forWhom === "other" && order.beneficiaryName
                  ? order.beneficiaryName
                  : order.patientName}
              </p>
              {order.forWhom === "other" && (
                <p className="text-xs font-semibold text-muted-foreground">
                  Agendado por {order.patientName}
                </p>
              )}
              <p className="text-xs font-semibold text-muted-foreground">{order.phone}</p>
            </div>
            <div className="sm:text-right">
              <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                Emitida em
              </p>
              <p className="inline-flex items-center gap-1.5 text-base font-extrabold">
                <CalendarDays className="size-4 text-primary" />
                {createdAt.toLocaleDateString("pt-BR")} às{" "}
                {createdAt.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
              </p>
              <span className="mt-1 inline-block rounded-full bg-accent-soft px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-accent">
                Aguardando confirmação de pagamento
              </span>
            </div>
          </div>

          <div className="divide-y divide-border rounded-2xl border border-border">
            {order.items.map((item, i) => (
              <div key={`${item.name}-${i}`} className="flex items-start justify-between gap-4 p-4">
                <div className="space-y-1">
                  <p className="text-sm font-extrabold">{item.name}</p>
                  <p className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                    <MapPin className="size-3.5 text-primary" /> {item.clinic}
                  </p>
                  {item.qty > 1 && (
                    <p className="text-xs font-bold text-muted-foreground">
                      {item.qty} × {formatPrice(item.unitPrice)}
                    </p>
                  )}
                </div>
                <p className="shrink-0 text-sm font-extrabold text-primary">
                  {formatPrice(item.unitPrice * item.qty)}
                </p>
              </div>
            ))}
          </div>

          <div className="flex items-baseline justify-between rounded-2xl bg-secondary/60 px-5 py-4">
            <span className="text-sm font-extrabold">Valor total</span>
            <span className="text-2xl font-extrabold text-accent">{formatPrice(order.total)}</span>
          </div>

          {order.notes && (
            <p className="text-xs font-semibold text-muted-foreground">
              Observações: {order.notes}
            </p>
          )}

          <p className="inline-flex items-start gap-2 rounded-2xl bg-primary-soft px-4 py-3 text-xs font-semibold text-primary">
            <HeartHandshake className="mt-0.5 size-4 shrink-0" />
            O pagamento é combinado diretamente com a equipe Prev Bem pelo WhatsApp (PIX ou cartão).
            Nenhum valor é cobrado por este site.
          </p>
        </div>
      </div>
    );
  },
);
