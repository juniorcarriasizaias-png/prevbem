import type { ReactNode } from "react";

import { cn } from "@/lib/utils";
import type { OrderStatus } from "@/context/orders";

export function PartnerCard({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("rounded-2xl border border-primary/12 bg-card shadow-soft", className)}>
      {children}
    </div>
  );
}

export function PartnerSectionTitle({
  title,
  action,
}: {
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex items-center justify-between gap-3">
      <h2 className="text-[13px] font-extrabold uppercase tracking-wider text-primary">{title}</h2>
      {action}
    </div>
  );
}

const statusStyles: Record<OrderStatus, string> = {
  "Aguardando pagamento": "bg-accent-soft text-accent",
  Confirmado: "bg-primary-soft text-primary",
  Concluído: "bg-success/12 text-success",
  Cancelado: "bg-destructive/10 text-destructive",
};

export function StatusPill({ status }: { status: OrderStatus }) {
  return (
    <span
      className={cn(
        "inline-block rounded-full px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide",
        statusStyles[status],
      )}
    >
      {status}
    </span>
  );
}
