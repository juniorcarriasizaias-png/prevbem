import { Link } from "@tanstack/react-router";
import { Cookie } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";

const STORAGE_KEY = "prevbem:cookie-consent";

export function CookieConsent() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    try {
      if (!window.localStorage.getItem(STORAGE_KEY)) setVisible(true);
    } catch {
      /* localStorage indisponível */
    }
  }, []);

  const decide = (value: "all" | "essential") => {
    try {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ value, date: new Date().toISOString() }),
      );
    } catch {
      /* ignore */
    }
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div
      data-print-hide
      className="fixed inset-x-0 bottom-0 z-[60] px-4 pb-24 md:pb-6"
      role="dialog"
      aria-label="Consentimento de cookies"
    >
      <div className="surface-card mx-auto flex w-full max-w-4xl flex-col gap-4 p-5 sm:flex-row sm:items-center">
        <span className="flex size-11 shrink-0 items-center justify-center rounded-2xl bg-primary-soft text-primary">
          <Cookie className="size-5" />
        </span>
        <div className="flex-1 text-sm font-semibold text-muted-foreground">
          <p className="font-extrabold text-foreground">A gente usa cookies</p>
          <p className="mt-1 leading-relaxed">
            Usamos cookies essenciais para o site funcionar e, com a sua permissão, cookies para
            entender como você navega e melhorar sua experiência. Você pode mudar de ideia quando
            quiser. Saiba mais na{" "}
            <Link to="/privacidade" className="font-extrabold text-primary underline">
              Política de Privacidade
            </Link>
            .
          </p>
        </div>
        <div className="flex shrink-0 flex-col gap-2 sm:flex-row">
          <Button variant="soft" onClick={() => decide("essential")}>
            Só os essenciais
          </Button>
          <Button variant="cta" onClick={() => decide("all")}>
            Aceitar todos
          </Button>
        </div>
      </div>
    </div>
  );
}
