import { useState } from "react";
import { Star } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { findServiceIdByName, useReviews, type Review } from "@/context/reviews";

export function StarRow({ rating, className = "" }: { rating: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-0.5 ${className}`} aria-hidden>
      {[1, 2, 3, 4, 5].map((n) => (
        <Star
          key={n}
          className={
            n <= Math.round(rating)
              ? "size-3.5 fill-accent text-accent"
              : "size-3.5 text-muted-foreground/40"
          }
        />
      ))}
    </span>
  );
}

export function ReviewDialog({
  appointmentId,
  serviceName,
  clinic,
  patientName,
  existing,
}: {
  appointmentId: string;
  serviceName: string;
  clinic: string;
  patientName: string;
  existing?: Review | undefined;
}) {
  const { addReview } = useReviews();
  const [open, setOpen] = useState(false);
  const [rating, setRating] = useState(existing?.rating ?? 0);
  const [comment, setComment] = useState(existing?.comment ?? "");

  const submit = () => {
    if (rating === 0) {
      toast.error("Escolha de 1 a 5 estrelas para enviar sua avaliação.");
      return;
    }
    addReview({
      appointmentId,
      serviceId: findServiceIdByName(serviceName),
      serviceName,
      clinic,
      patientName,
      rating,
      comment: comment.trim().slice(0, 240),
    });
    setOpen(false);
    toast.success(existing ? "Avaliação atualizada" : "Obrigado pela sua avaliação!", {
      description: `${serviceName} · ${clinic}`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant={existing ? "outline" : "cta"} size="sm">
          <Star className={existing ? "" : "fill-current"} />
          {existing ? "Editar avaliação" : "Avaliar atendimento"}
        </Button>
      </DialogTrigger>
      <DialogContent className="rounded-3xl sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Como foi seu atendimento?</DialogTitle>
          <DialogDescription>
            {serviceName} · {clinic}
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-center gap-2 py-2">
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setRating(n)}
              aria-label={`${n} estrela${n > 1 ? "s" : ""}`}
              className="rounded-full p-1 transition-transform hover:scale-110"
            >
              <Star
                className={
                  n <= rating ? "size-8 fill-accent text-accent" : "size-8 text-muted-foreground/40"
                }
              />
            </button>
          ))}
        </div>

        <Textarea
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          maxLength={240}
          rows={3}
          placeholder="Conte em poucas palavras como foi (opcional)"
          className="rounded-2xl font-semibold"
        />
        <p className="text-xs font-semibold text-muted-foreground">
          Sua avaliação ajuda outros pacientes a escolherem com segurança.
        </p>

        <DialogFooter>
          <Button variant="cta" onClick={submit}>
            Enviar avaliação
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
