import { HeartHandshake, ShieldCheck } from "lucide-react";

import { Logo } from "@/components/brand/logo";

/** QR code apenas decorativo (visual), gerado de forma determinística a partir do texto. */
function DecorativeQr({ value, className }: { value: string; className?: string }) {
  const size = 21;
  let seed = 0;
  for (let i = 0; i < value.length; i++) seed = (seed * 31 + value.charCodeAt(i)) % 100000;

  const cells: { x: number; y: number }[] = [];
  let state = seed || 7;
  const isFinder = (x: number, y: number) =>
    (x < 7 && y < 7) || (x >= size - 7 && y < 7) || (x < 7 && y >= size - 7);

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      state = (state * 1103515245 + 12345) % 2147483648;
      if (isFinder(x, y)) continue;
      if (state % 100 < 48) cells.push({ x, y });
    }
  }

  const finder = (ox: number, oy: number) => (
    <g key={`f-${ox}-${oy}`}>
      <rect x={ox} y={oy} width={7} height={7} rx={1.2} fill="currentColor" />
      <rect x={ox + 1} y={oy + 1} width={5} height={5} rx={0.8} fill="var(--card)" />
      <rect x={ox + 2} y={oy + 2} width={3} height={3} rx={0.5} fill="currentColor" />
    </g>
  );

  return (
    <svg
      viewBox={`0 0 ${size} ${size}`}
      className={className}
      role="img"
      aria-label="QR code decorativo da carteirinha"
    >
      <rect width={size} height={size} fill="var(--card)" />
      {finder(0, 0)}
      {finder(size - 7, 0)}
      {finder(0, size - 7)}
      {cells.map((c) => (
        <rect key={`${c.x}-${c.y}`} x={c.x} y={c.y} width={1} height={1} fill="currentColor" />
      ))}
    </svg>
  );
}

export function PatientCard({
  name,
  memberId,
  since,
  plan = "Paciente particular",
}: {
  name: string;
  memberId: string;
  since: string;
  plan?: string;
}) {
  return (
    <div className="overflow-hidden rounded-3xl border border-border shadow-card">
      <div className="brand-gradient relative p-6 text-primary-foreground">
        <div className="absolute -right-10 -top-10 size-40 rounded-full bg-primary-foreground/10" />
        <div className="absolute -bottom-14 -left-6 size-36 rounded-full bg-primary-foreground/10" />
        <div className="relative flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest text-primary-foreground/75">
              Carteirinha digital
            </p>
            <p className="mt-1 text-2xl font-extrabold">Prev Bem</p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-primary-foreground/15 px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide">
            <ShieldCheck className="size-3.5" /> Ativa
          </span>
        </div>

        <div className="relative mt-6 flex items-end justify-between gap-5">
          <div className="min-w-0 space-y-3">
            <div>
              <p className="text-[11px] font-bold uppercase tracking-wide text-primary-foreground/70">
                Paciente
              </p>
              <p className="truncate text-lg font-extrabold">{name}</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wide text-primary-foreground/70">
                  Identificação
                </p>
                <p className="font-extrabold tabular-nums">{memberId}</p>
              </div>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wide text-primary-foreground/70">
                  Membro desde
                </p>
                <p className="font-extrabold">
                  {new Date(since).toLocaleDateString("pt-BR", {
                    month: "2-digit",
                    year: "numeric",
                  })}
                </p>
              </div>
            </div>
          </div>
          <div className="shrink-0 rounded-2xl bg-card p-2">
            <DecorativeQr value={memberId + name} className="size-24 text-primary" />
          </div>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 bg-card px-6 py-4">
        <p className="inline-flex items-center gap-2 text-xs font-semibold text-muted-foreground">
          <HeartHandshake className="size-4 text-accent" /> {plan} · apresente na recepção da
          clínica parceira
        </p>
        <div className="hidden sm:flex">
          <Logo />
        </div>

      </div>
    </div>
  );
}
