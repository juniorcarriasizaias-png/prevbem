import { Link } from "@tanstack/react-router";
import { Instagram, Mail, MessageCircle, Phone } from "lucide-react";

import { Logo } from "@/components/brand/logo";
import { useSiteSettings } from "@/context/site-settings";

const columns = [
  {
    title: "Plataforma",
    links: [
      { to: "/servicos", label: "Consultas e exames" },
      { to: "/clube", label: "Clube de Vantagens" },
      { to: "/indicacao", label: "Indique e ganhe" },
      { to: "/como-funciona", label: "Como funciona" },
      { to: "/carrinho", label: "Meu carrinho" },
      { to: "/minha-conta", label: "Área do paciente" },
    ],
  },
  {
    title: "Institucional",
    links: [
      { to: "/sobre", label: "Sobre a Prev Bem" },
      { to: "/contato", label: "Contato" },
      { to: "/contato", label: "Dúvidas frequentes" },
      { to: "/privacidade", label: "Política de Privacidade" },
      { to: "/termos", label: "Termos de Uso" },
    ],
  },
] as const;

export function SiteFooter() {
  const { settings, whatsappDisplay } = useSiteSettings();
  return (
    <footer data-print-hide className="mt-24 border-t border-border bg-primary-soft/60">
      <div className="mx-auto grid w-full max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-4 lg:px-8">
        <div className="space-y-4 lg:col-span-2">
          <Logo />
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
            A {settings.nome_site} conecta pacientes particulares a clínicas e laboratórios parceiros com preços
            justos, transparência total e agendamento em poucos cliques — sem convênio, sem
            burocracia.
          </p>
          <div className="flex flex-wrap gap-3 text-sm font-bold text-primary">
            <span className="inline-flex items-center gap-2 rounded-full bg-background px-4 py-2 shadow-soft">
              <Phone className="size-4" /> {whatsappDisplay}
            </span>
            <span className="inline-flex items-center gap-2 rounded-full bg-background px-4 py-2 shadow-soft">
              <MessageCircle className="size-4" /> WhatsApp
            </span>
          </div>
        </div>

        {columns.map((col) => (
          <div key={col.title}>
            <h3 className="text-sm font-extrabold uppercase tracking-wide text-primary">
              {col.title}
            </h3>
            <ul className="mt-4 space-y-3">
              {col.links.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.to}
                    className="text-sm font-semibold text-muted-foreground transition-colors hover:text-primary"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="border-t border-border/70">
        <div className="mx-auto flex w-full max-w-7xl flex-col gap-3 px-4 py-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between sm:px-6 lg:px-8">
          <p className="whitespace-pre-line">{settings.texto_rodape}</p>
          <div className="flex items-center gap-4 font-semibold">
            <span className="inline-flex items-center gap-1.5">
              <Mail className="size-3.5" /> contato@prevbem.com.br
            </span>
            <span className="inline-flex items-center gap-1.5">
              <Instagram className="size-3.5" /> @prevbem
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
