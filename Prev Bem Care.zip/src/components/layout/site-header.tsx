import { Link, useNavigate } from "@tanstack/react-router";
import {
  Menu,
  ShoppingCart,
  UserRound,
  Search,
  X,
  ShieldCheck,
  LayoutDashboard,
  CalendarCheck,
  LogOut,
  ChevronDown,
} from "lucide-react";
import { useState } from "react";

import { Logo } from "@/components/brand/logo";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useCart } from "@/context/cart";
import { useAuth } from "@/context/auth";

const navItems = [
  { to: "/servicos", label: "Consultas e exames" },
  { to: "/clube", label: "Clube de Vantagens" },
  { to: "/como-funciona", label: "Como funciona" },
  { to: "/contato", label: "Dúvidas" },
] as const;

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const { count } = useCart();
  const { user, isAdmin, signOut, ready } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await signOut();
    void navigate({ to: "/", replace: true });
  };

  return (
    <header data-print-hide className="sticky top-0 z-50 border-b border-border/70 bg-background/90 backdrop-blur-md">
      <div className="mx-auto flex h-18 w-full max-w-7xl items-center gap-6 px-4 sm:px-6 lg:px-8">
        <Logo />

        <nav className="hidden flex-1 items-center gap-1 lg:flex">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className="rounded-full px-4 py-2 text-sm font-bold text-muted-foreground transition-colors hover:bg-secondary hover:text-primary"
              activeProps={{ className: "bg-secondary text-primary" }}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="icon" asChild className="hidden sm:inline-flex">
            <Link to="/servicos" aria-label="Buscar serviços">
              <Search />
            </Link>
          </Button>
          <Button variant="ghost" size="icon" asChild className="relative">
            <Link to="/carrinho" aria-label="Carrinho">
              <ShoppingCart />
              <span className="absolute -right-0.5 -top-0.5 flex size-5 items-center justify-center rounded-full bg-accent text-[11px] font-extrabold text-accent-foreground">
                {count}
              </span>
            </Link>
          </Button>

          {/* Desktop user menu */}
          {user && ready ? (
            <div className="hidden items-center gap-2 sm:flex">
              {isAdmin && (
                <Button variant="ghost" size="icon" asChild className="relative text-primary" aria-label="Painel Administrativo">
                  <Link to="/admin">
                    <ShieldCheck className="size-5" />
                  </Link>
                </Button>
              )}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="soft"
                    className="hidden h-10 gap-2 pl-4 pr-3 sm:inline-flex"
                    aria-label="Menu do usuário"
                  >
                    <UserRound className="size-4" />
                    <span className="max-w-[120px] truncate">{user.name.split(" ")[0]}</span>
                    <ChevronDown className="size-3.5 opacity-70" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="min-w-[200px]">
                  <DropdownMenuItem asChild className="cursor-pointer gap-2">
                    <Link to="/minha-conta">
                      <LayoutDashboard className="size-4" />
                      Minha conta
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild className="cursor-pointer gap-2">
                    <Link to="/minha-conta">
                      <CalendarCheck className="size-4" />
                      Meus agendamentos
                    </Link>
                  </DropdownMenuItem>
                  {isAdmin && (
                    <DropdownMenuItem asChild className="cursor-pointer gap-2 text-primary focus:text-primary">
                      <Link to="/admin">
                        <ShieldCheck className="size-4" />
                        Painel Administrativo
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => void handleSignOut()}
                    className="cursor-pointer gap-2 text-destructive focus:text-destructive"
                  >
                    <LogOut className="size-4" />
                    Sair
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          ) : (
            <Button variant="soft" asChild className="hidden sm:inline-flex">
              <Link to="/entrar">
                <UserRound />
                Entrar
              </Link>
            </Button>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Fechar menu" : "Abrir menu"}
          >
            {open ? <X /> : <Menu />}
          </Button>
        </div>
      </div>

      {/* Mobile hamburger menu */}
      {open && (
        <div className="border-t border-border bg-background lg:hidden">
          <nav className="mx-auto flex w-full max-w-7xl flex-col gap-1 px-4 py-4">
            {[...navItems, { to: "/sobre", label: "Sobre a Prev Bem" } as const].map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="rounded-2xl px-4 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
              >
                {item.label}
              </Link>
            ))}

            {user && ready ? (
              <>
                <div className="my-2 h-px bg-border" />
                <Link
                  to="/minha-conta"
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
                >
                  <LayoutDashboard className="size-4" />
                  Minha conta
                </Link>
                <Link
                  to="/minha-conta"
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold text-foreground transition-colors hover:bg-secondary"
                >
                  <CalendarCheck className="size-4" />
                  Meus agendamentos
                </Link>
                {isAdmin && (
                  <Link
                    to="/admin"
                    onClick={() => setOpen(false)}
                    className="flex items-center gap-2 rounded-2xl px-4 py-3 text-sm font-bold text-primary transition-colors hover:bg-secondary"
                  >
                    <ShieldCheck className="size-4" />
                    Painel Administrativo
                  </Link>
                )}
                <button
                  onClick={() => {
                    setOpen(false);
                    void handleSignOut();
                  }}
                  className="flex items-center gap-2 rounded-2xl px-4 py-3 text-left text-sm font-bold text-destructive transition-colors hover:bg-secondary"
                >
                  <LogOut className="size-4" />
                  Sair
                </button>
              </>
            ) : (
              <Button variant="cta" asChild className="mt-2">
                <Link to="/entrar" onClick={() => setOpen(false)}>
                  Entrar ou criar conta
                </Link>
              </Button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
