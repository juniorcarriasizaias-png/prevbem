import { Link } from "@tanstack/react-router";
import { Home, Search, ShoppingCart, CalendarCheck, UserRound } from "lucide-react";

const tabs = [
  { to: "/", label: "Início", icon: Home },
  { to: "/servicos", label: "Buscar", icon: Search },
  { to: "/carrinho", label: "Carrinho", icon: ShoppingCart },
  { to: "/minha-conta", label: "Agenda", icon: CalendarCheck },
  { to: "/contato", label: "Ajuda", icon: UserRound },
] as const;

export function MobileTabBar() {
  return (
    <nav data-print-hide className="fixed inset-x-0 bottom-0 z-50 border-t border-border bg-background/95 pb-[env(safe-area-inset-bottom)] backdrop-blur md:hidden">
      <ul className="mx-auto flex max-w-md items-stretch justify-between px-2 py-1.5">
        {tabs.map(({ to, label, icon: Icon }) => (
          <li key={to} className="flex-1">
            <Link
              to={to}
              className="flex flex-col items-center gap-1 rounded-2xl px-1 py-2 text-[11px] font-bold text-muted-foreground transition-colors"
              activeProps={{ className: "text-primary bg-secondary" }}
              activeOptions={{ exact: to === "/" }}
            >
              <Icon className="size-5" />
              {label}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}
