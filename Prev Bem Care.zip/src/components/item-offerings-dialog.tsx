import { Link } from "@tanstack/react-router";
import { Check, Clock, FileClock, MapPin, Phone, ShoppingCart, Star } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useCart } from "@/context/cart";
import {
  categoryLabels,
  clinicById,
  formatPrice,
  offeringsByCatalogItem,
  type CatalogItem,
} from "@/data/mock";

export function ItemOfferingsDialog({
  item,
  open,
  onOpenChange,
}: {
  item: CatalogItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const { add, has } = useCart();
  if (!item) return null;
  const offers = offeringsByCatalogItem(item.id);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[88vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader className="text-left">
          <span className="w-fit rounded-full bg-secondary px-3 py-1 text-[11px] font-extrabold uppercase tracking-wide text-primary">
            {categoryLabels[item.categoria]}
            {item.especialidade ? ` · ${item.especialidade}` : ""}
          </span>
          <DialogTitle className="text-xl leading-snug">{item.nome}</DialogTitle>
          {item.descricao && (
            <DialogDescription className="text-sm font-medium leading-relaxed">
              {item.descricao}
            </DialogDescription>
          )}
        </DialogHeader>

        {item.preparoNecessario && (
          <div className="rounded-2xl bg-secondary/60 p-4">
            <p className="text-xs font-extrabold uppercase tracking-wide text-primary">
              Preparo necessário
            </p>
            <p className="mt-1 text-sm font-semibold text-muted-foreground">
              {item.preparoNecessario}
            </p>
          </div>
        )}

        <div className="space-y-3">
          <div className="flex items-baseline justify-between gap-3">
            <h3 className="text-sm font-extrabold uppercase tracking-wide text-primary">
              Escolha a clínica
            </h3>
            <span className="text-xs font-bold text-muted-foreground">
              {offers.length} {offers.length === 1 ? "oferta" : "ofertas"} · menor preço primeiro
            </span>
          </div>

          {offers.map((offering, index) => {
            const clinic = clinicById[offering.clinicaId];
            if (!clinic) return null;
            const inCart = has(offering.id);
            return (
              <article
                key={offering.id}
                className="rounded-2xl border border-border p-4 shadow-sm"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1.5">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-extrabold text-foreground">{clinic.name}</p>
                      {index === 0 && offers.length > 1 && (
                        <span className="rounded-full bg-success/10 px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide text-success">
                          Menor preço
                        </span>
                      )}
                      {offering.avaliacao && (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-muted-foreground">
                          <Star className="size-3.5 fill-accent text-accent" />
                          {offering.avaliacao.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <p className="flex items-start gap-1.5 text-xs font-semibold text-muted-foreground">
                      <MapPin className="mt-0.5 size-3.5 shrink-0 text-primary" />
                      {clinic.endereco}
                    </p>
                    {clinic.telefone && (
                      <p className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                        <Phone className="size-3.5 text-primary" /> {clinic.telefone}
                      </p>
                    )}
                    {offering.prazoResultado ? (
                      <p className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                        <FileClock className="size-3.5 text-primary" /> Resultado{" "}
                        {offering.prazoResultado}
                      </p>
                    ) : item.duracao ? (
                      <p className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground">
                        <Clock className="size-3.5 text-primary" /> {item.duracao}
                      </p>
                    ) : null}
                  </div>

                  <div className="text-right">
                    {offering.precoDeTabela && offering.precoDeTabela > offering.preco && (
                      <p className="text-xs font-semibold text-muted-foreground line-through">
                        {formatPrice(offering.precoDeTabela)}
                      </p>
                    )}
                    <p className="text-xl font-extrabold text-accent">
                      {formatPrice(offering.preco)}
                    </p>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-2">
                  <Button
                    variant={inCart ? "soft" : "cta"}
                    size="sm"
                    className="flex-1"
                    onClick={() => {
                      add(offering.id);
                      toast.success(
                        inCart ? "Já está no carrinho" : "Adicionado ao carrinho",
                        { description: `${item.nome} — ${clinic.name}` },
                      );
                    }}
                  >
                    {inCart ? <Check /> : <ShoppingCart />}
                    {inCart ? "No carrinho" : "Adicionar ao carrinho"}
                  </Button>
                  <Button variant="ghost" size="sm" asChild>
                    <Link
                      to="/servicos/$serviceId"
                      params={{ serviceId: offering.id }}
                      onClick={() => onOpenChange(false)}
                    >
                      Ver detalhes
                    </Link>
                  </Button>
                </div>
              </article>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
