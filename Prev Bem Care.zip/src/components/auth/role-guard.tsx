import { useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { toast } from "sonner";

import { useAuth, type UserRole } from "@/context/auth";

/**
 * Protege áreas internas (/admin, /parceiro).
 * Sem sessão ou sem o papel exigido em profiles.role → volta para a home com "Acesso restrito".
 */
export function RoleGuard({
  allow,
  children,
}: {
  allow: UserRole[];
  children: React.ReactNode;
}) {
  const { user, ready } = useAuth();
  const navigate = useNavigate();
  const allowed = !!user && allow.includes(user.role);

  useEffect(() => {
    if (!ready) return;
    if (!allowed) {
      toast.error("Acesso restrito");
      void navigate({ to: "/", replace: true });
    }
  }, [ready, allowed, navigate]);

  if (!ready || !allowed) {
    return (
      <div className="grid min-h-screen place-items-center px-4">
        <p className="text-sm font-bold text-muted-foreground">Verificando acesso…</p>
      </div>
    );
  }

  return <>{children}</>;
}
