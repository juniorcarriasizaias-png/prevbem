export type Categoria =
  | "exame_laboratorial"
  | "exame_imagem"
  | "consulta"
  | "cirurgia";

export const categoriaLabels: Record<Categoria, string> = {
  exame_laboratorial: "Exame de laboratório",
  exame_imagem: "Exame de imagem",
  consulta: "Consulta",
  cirurgia: "Cirurgia",
};

/** Rótulos usados nas abas do catálogo. */
export const categoriaTabLabels: Record<Categoria, string> = {
  exame_laboratorial: "Exames de Laboratório",
  exame_imagem: "Exames de Imagem",
  consulta: "Consultas",
  cirurgia: "Cirurgias",
};

export const categoriaSearchPlaceholders: Record<Categoria, string> = {
  exame_laboratorial: "Buscar exame de laboratório...",
  exame_imagem: "Buscar exame de imagem...",
  consulta: "Buscar consulta ou especialidade...",
  cirurgia: "Buscar cirurgia ou procedimento...",
};

export const categoriaOrder: Categoria[] = [
  "exame_laboratorial",
  "exame_imagem",
  "consulta",
  "cirurgia",
];

/** Item do catálogo central: o serviço em si, independente da clínica. */
export type CatalogItem = {
  id: string;
  nome: string;
  categoria: Categoria;
  /** Principalmente para consultas e cirurgias */
  especialidade?: string;
  descricao?: string;
  /** Instruções de jejum etc, quando aplicável */
  preparoNecessario?: string;
  /** Duração média do atendimento */
  duracao?: string;
  /** Marcado como "mais procurado" */
  destaque?: boolean;
  /** Quanto maior, mais procurado */
  demanda: number;
  ativo: boolean;
};

/** Oferta: um item do catálogo ofertado por uma clínica específica, com preço próprio. */
export type Offering = {
  id: string;
  catalogItemId: string;
  clinicaId: string;
  preco: number;
  /** Preço "riscado" (tabela particular) */
  precoDeTabela?: number;
  /** "24h úteis", só para exames */
  prazoResultado?: string;
  avaliacao?: number;
  avaliacoes?: number;
  ativo: boolean;
};

export type Clinica = {
  id: string;
  nome: string;
  endereco: string;
  telefone?: string;
  especialidadesAtendidas: string[];
  /** Partes do endereço, usadas na UI */
  address: string;
  neighborhood: string;
  city: string;
};

export const clinicas: Clinica[] = [
  {
    id: "vida-plena",
    nome: "Clínica Vida Plena",
    endereco: "Av. Frei Serafim, 2340 — Centro, Teresina, PI",
    address: "Av. Frei Serafim, 2340",
    neighborhood: "Centro",
    city: "Teresina, PI",
    telefone: "(86) 3200-1000",
    especialidadesAtendidas: [],
  },
  {
    id: "aurora",
    nome: "Centro Médico Aurora",
    endereco: "R. Álvaro Mendes, 1180 — Centro, Teresina, PI",
    address: "R. Álvaro Mendes, 1180",
    neighborhood: "Centro",
    city: "Teresina, PI",
    telefone: "(86) 3207-1137",
    especialidadesAtendidas: [],
  },
  {
    id: "saude-bem",
    nome: "Instituto Saúde Bem",
    endereco: "Av. Raul Lopes, 470 — Jóquei, Teresina, PI",
    address: "Av. Raul Lopes, 470",
    neighborhood: "Jóquei",
    city: "Teresina, PI",
    telefone: "(86) 3214-1274",
    especialidadesAtendidas: [],
  },
  {
    id: "novalab",
    nome: "Laboratório NovaLab",
    endereco: "R. Simplício Mendes, 905 — Ilhotas, Teresina, PI",
    address: "R. Simplício Mendes, 905",
    neighborhood: "Ilhotas",
    city: "Teresina, PI",
    telefone: "(86) 3221-1411",
    especialidadesAtendidas: [],
  },
  {
    id: "ipe",
    nome: "Hospital Dia Ipê",
    endereco: "Av. Dom Severino, 1620 — Fátima, Teresina, PI",
    address: "Av. Dom Severino, 1620",
    neighborhood: "Fátima",
    city: "Teresina, PI",
    telefone: "(86) 3228-1548",
    especialidadesAtendidas: [],
  },
];

/**
 * Sementes compactas do catálogo: 15 itens por categoria.
 * [id, nome, especialidade, preçoBase, descrição, preparo?, prazoResultado?]
 */
type Seed = {
  id: string;
  nome: string;
  especialidade?: string;
  preco: number;
  descricao: string;
  preparo?: string;
  prazo?: string;
  duracao?: string;
  demanda: number;
};

const jejum8 = "Jejum de 8 horas. Manter hidratação com água.";
const jejum12 = "Jejum de 12 horas. Evitar bebida alcoólica nas 72h anteriores.";
const labSeeds: Seed[] = [
  { id: "hemograma-completo", nome: "Hemograma completo", especialidade: "Hematologia", preco: 32, descricao: "Avaliação das células do sangue (hemácias, leucócitos e plaquetas). Exame base para check-ups e investigação de anemias e infecções.", prazo: "até 24 horas", demanda: 98 },
  { id: "glicemia-jejum", nome: "Glicemia de jejum", especialidade: "Endocrinologia", preco: 22, descricao: "Dosagem da glicose no sangue em jejum, usada no rastreio de diabetes e pré-diabetes.", preparo: jejum8, prazo: "até 24 horas", demanda: 93 },
  { id: "colesterol-total-fracoes", nome: "Colesterol total e frações", especialidade: "Cardiologia", preco: 38, descricao: "Perfil lipídico com HDL, LDL e colesterol total para avaliação do risco cardiovascular.", preparo: jejum12, prazo: "até 24 horas", demanda: 90 },
  { id: "triglicerides", nome: "Triglicerídeos", especialidade: "Cardiologia", preco: 26, descricao: "Dosagem de triglicerídeos, importante no acompanhamento de dislipidemias.", preparo: jejum12, prazo: "até 24 horas", demanda: 76 },
  { id: "tsh-t4-livre", nome: "TSH e T4 livre", especialidade: "Endocrinologia", preco: 54, descricao: "Avaliação da função da tireoide, indicada em casos de cansaço, queda de cabelo e variação de peso.", prazo: "até 36 horas", demanda: 88 },
  { id: "hemoglobina-glicada", nome: "Hemoglobina glicada (HbA1c)", especialidade: "Endocrinologia", preco: 44, descricao: "Mostra a média da glicose dos últimos três meses. Padrão no controle do diabetes.", prazo: "até 36 horas", demanda: 80 },
  { id: "vitamina-d", nome: "Vitamina D (25-OH)", especialidade: "Endocrinologia", preco: 79, descricao: "Dosagem de vitamina D, relacionada à saúde óssea e imunidade.", prazo: "até 48 horas", demanda: 84 },
  { id: "vitamina-b12", nome: "Vitamina B12", especialidade: "Hematologia", preco: 62, descricao: "Avaliação de deficiência de B12, comum em vegetarianos e após cirurgia bariátrica.", prazo: "até 48 horas", demanda: 61 },
  { id: "ferritina", nome: "Ferritina", especialidade: "Hematologia", preco: 48, descricao: "Mede as reservas de ferro do organismo, útil na investigação de anemia e queda de cabelo.", prazo: "até 36 horas", demanda: 64 },
  { id: "creatinina-ureia", nome: "Creatinina e ureia", especialidade: "Nefrologia", preco: 34, descricao: "Marcadores da função dos rins, usados em check-ups e no controle de hipertensão.", preparo: jejum8, prazo: "até 24 horas", demanda: 58 },
  { id: "acido-urico", nome: "Ácido úrico", especialidade: "Reumatologia", preco: 24, descricao: "Dosagem de ácido úrico, relacionada a crises de gota e cálculos renais.", preparo: jejum8, prazo: "até 24 horas", demanda: 52 },
  { id: "psa-total-livre", nome: "PSA total e livre", especialidade: "Urologia", preco: 68, descricao: "Rastreio de alterações da próstata, recomendado a partir dos 45 anos.", preparo: "Evitar relação sexual e exercícios intensos nas 48h anteriores.", prazo: "até 48 horas", demanda: 66 },
  { id: "beta-hcg", nome: "Beta HCG quantitativo", especialidade: "Ginecologia", preco: 42, descricao: "Confirmação e acompanhamento inicial de gravidez por dosagem sanguínea.", prazo: "até 24 horas", demanda: 70 },
  { id: "urina-tipo-1", nome: "Urina tipo 1 (EAS)", especialidade: "Nefrologia", preco: 20, descricao: "Análise da urina para investigar infecção urinária e alterações renais.", preparo: "Colher a primeira urina da manhã após higiene local.", prazo: "até 24 horas", demanda: 74 },
  { id: "check-up-basico", nome: "Check-up básico (8 exames)", especialidade: "Clínica médica", preco: 159, descricao: "Pacote com hemograma, glicemia, perfil lipídico, TSH, ureia, creatinina, ácido úrico e urina tipo 1.", preparo: jejum12, prazo: "até 48 horas", demanda: 96 },
];

const imagemSeeds: Seed[] = [
  { id: "ultrassom-abdominal", nome: "Ultrassonografia de abdômen total", especialidade: "Radiologia", preco: 175, descricao: "Avaliação de fígado, vias biliares, pâncreas, baço e rins por ultrassom.", preparo: "Jejum de 8 horas e bexiga cheia no momento do exame.", prazo: "laudo em até 48 horas", demanda: 92 },
  { id: "ultrassom-tireoide", nome: "Ultrassonografia de tireoide", especialidade: "Radiologia", preco: 145, descricao: "Análise do tamanho e da presença de nódulos na tireoide.", prazo: "laudo em até 48 horas", demanda: 71 },
  { id: "ultrassom-transvaginal", nome: "Ultrassonografia transvaginal", especialidade: "Ginecologia", preco: 165, descricao: "Avaliação do útero, ovários e endométrio com maior definição.", preparo: "Bexiga vazia. Informar a data da última menstruação.", prazo: "laudo em até 48 horas", demanda: 77 },
  { id: "ultrassom-obstetrico", nome: "Ultrassonografia obstétrica", especialidade: "Ginecologia", preco: 189, descricao: "Acompanhamento do desenvolvimento do bebê durante a gestação.", prazo: "laudo no mesmo dia", demanda: 68 },
  { id: "ultrassom-mamas", nome: "Ultrassonografia de mamas", especialidade: "Mastologia", preco: 179, descricao: "Complementa a mamografia na investigação de nódulos mamários.", preparo: "Não usar desodorante ou talco na região no dia do exame.", prazo: "laudo em até 48 horas", demanda: 63 },
  { id: "raio-x-torax", nome: "Raio-X de tórax", especialidade: "Radiologia", preco: 79, descricao: "Imagem dos pulmões e coração, usada em avaliações respiratórias e pré-operatórias.", prazo: "laudo em até 24 horas", demanda: 82 },
  { id: "raio-x-coluna", nome: "Raio-X de coluna lombar", especialidade: "Ortopedia", preco: 95, descricao: "Avaliação óssea da coluna lombar em casos de dor e limitação de movimento.", prazo: "laudo em até 24 horas", demanda: 59 },
  { id: "mamografia-digital", nome: "Mamografia digital bilateral", especialidade: "Mastologia", preco: 219, descricao: "Rastreio de câncer de mama recomendado anualmente a partir dos 40 anos.", preparo: "Não usar desodorante, creme ou talco nas mamas e axilas.", prazo: "laudo em até 72 horas", demanda: 86 },
  { id: "densitometria-ossea", nome: "Densitometria óssea", especialidade: "Reumatologia", preco: 199, descricao: "Mede a densidade dos ossos para diagnóstico de osteopenia e osteoporose.", prazo: "laudo em até 48 horas", demanda: 55 },
  { id: "tomografia-cranio", nome: "Tomografia computadorizada de crânio", especialidade: "Radiologia", preco: 449, descricao: "Imagem detalhada do cérebro e estruturas ósseas do crânio.", prazo: "laudo em até 48 horas", demanda: 51 },
  { id: "tomografia-torax", nome: "Tomografia computadorizada de tórax", especialidade: "Radiologia", preco: 489, descricao: "Avaliação detalhada dos pulmões e mediastino.", preparo: "Jejum de 4 horas quando houver uso de contraste.", prazo: "laudo em até 48 horas", demanda: 48 },
  { id: "ressonancia-joelho", nome: "Ressonância magnética de joelho", especialidade: "Ortopedia", preco: 699, descricao: "Análise de ligamentos, meniscos e cartilagens do joelho.", preparo: "Retirar objetos metálicos. Informar próteses ou marca-passo.", prazo: "laudo em até 72 horas", demanda: 57 },
  { id: "eletrocardiograma", nome: "Eletrocardiograma (ECG)", especialidade: "Cardiologia", preco: 69, descricao: "Registro da atividade elétrica do coração, exame rápido e indolor.", prazo: "laudo no mesmo dia", demanda: 88 },
  { id: "ecocardiograma", nome: "Ecocardiograma com doppler", especialidade: "Cardiologia", preco: 289, descricao: "Ultrassom do coração que avalia válvulas, câmaras e função cardíaca.", prazo: "laudo no mesmo dia", demanda: 64 },
  { id: "mapeamento-retina", nome: "Mapeamento de retina", especialidade: "Oftalmologia", preco: 139, descricao: "Exame do fundo do olho para avaliação da retina e do nervo óptico.", preparo: "Ir acompanhado: a pupila é dilatada com colírio.", prazo: "laudo no mesmo dia", demanda: 53 },
];

const consultaSeeds: Seed[] = [
  { id: "consulta-clinico-geral", nome: "Consulta com clínico geral", especialidade: "Clínica médica", preco: 99, descricao: "Avaliação geral de saúde, pedido de exames e orientação de tratamento.", duracao: "30 min", demanda: 99 },
  { id: "consulta-cardiologia", nome: "Consulta com cardiologista", especialidade: "Cardiologia", preco: 189, descricao: "Avaliação do coração, pressão arterial e risco cardiovascular.", duracao: "40 min", demanda: 90 },
  { id: "consulta-dermatologia", nome: "Consulta com dermatologista", especialidade: "Dermatologia", preco: 179, descricao: "Cuidados com pele, cabelo e unhas, incluindo avaliação de manchas e acne.", duracao: "30 min", demanda: 91 },
  { id: "consulta-pediatria", nome: "Consulta com pediatra", especialidade: "Pediatria", preco: 149, descricao: "Acompanhamento do crescimento e da saúde de crianças e adolescentes.", duracao: "40 min", demanda: 87 },
  { id: "consulta-ginecologia", nome: "Consulta com ginecologista", especialidade: "Ginecologia", preco: 185, descricao: "Saúde da mulher, prevenção e acompanhamento de exames de rotina.", duracao: "40 min", demanda: 89 },
  { id: "consulta-ortopedia", nome: "Consulta com ortopedista", especialidade: "Ortopedia", preco: 189, descricao: "Avaliação de dores articulares, lesões e problemas de coluna.", duracao: "30 min", demanda: 78 },
  { id: "consulta-endocrinologia", nome: "Consulta com endocrinologista", especialidade: "Endocrinologia", preco: 199, descricao: "Tireoide, diabetes, obesidade e distúrbios hormonais.", duracao: "40 min", demanda: 82 },
  { id: "consulta-oftalmologia", nome: "Consulta com oftalmologista", especialidade: "Oftalmologia", preco: 169, descricao: "Avaliação da visão, prescrição de óculos e triagem de doenças oculares.", duracao: "30 min", demanda: 74 },
  { id: "consulta-otorrino", nome: "Consulta com otorrinolaringologista", especialidade: "Otorrinolaringologia", preco: 179, descricao: "Ouvido, nariz e garganta: rinite, sinusite, ronco e zumbido.", duracao: "30 min", demanda: 66 },
  { id: "consulta-urologia", nome: "Consulta com urologista", especialidade: "Urologia", preco: 189, descricao: "Saúde do homem, próstata e vias urinárias.", duracao: "30 min", demanda: 61 },
  { id: "consulta-neurologia", nome: "Consulta com neurologista", especialidade: "Neurologia", preco: 239, descricao: "Dores de cabeça, tonturas, memória e distúrbios do sono.", duracao: "40 min", demanda: 58 },
  { id: "consulta-gastroenterologia", nome: "Consulta com gastroenterologista", especialidade: "Gastroenterologia", preco: 209, descricao: "Sintomas digestivos, refluxo, gastrite e intestino.", duracao: "40 min", demanda: 60 },
  { id: "consulta-psiquiatria", nome: "Consulta com psiquiatra", especialidade: "Psiquiatria", preco: 249, descricao: "Avaliação de ansiedade, depressão e acompanhamento medicamentoso.", duracao: "50 min", demanda: 72 },
  { id: "consulta-nutricao", nome: "Consulta com nutricionista", especialidade: "Nutrição", preco: 129, descricao: "Plano alimentar individualizado com avaliação corporal.", duracao: "50 min", demanda: 69 },
  { id: "consulta-reumatologia", nome: "Consulta com reumatologista", especialidade: "Reumatologia", preco: 219, descricao: "Doenças articulares, artrite, fibromialgia e autoimunes.", duracao: "40 min", demanda: 47 },
];

const cirurgiaSeeds: Seed[] = [
  { id: "cirurgia-catarata", nome: "Cirurgia de catarata (por olho)", especialidade: "Oftalmologia", preco: 3890, descricao: "Facectomia com implante de lente intraocular, em regime de hospital-dia.", preparo: "Jejum de 8 horas e avaliação pré-anestésica prévia.", duracao: "1h", demanda: 74 },
  { id: "cirurgia-pterigio", nome: "Cirurgia de pterígio", especialidade: "Oftalmologia", preco: 2290, descricao: "Remoção do pterígio com enxerto conjuntival.", preparo: "Jejum de 8 horas.", duracao: "45 min", demanda: 41 },
  { id: "cirurgia-vasectomia", nome: "Vasectomia", especialidade: "Urologia", preco: 2490, descricao: "Procedimento definitivo de contracepção masculina, com anestesia local.", preparo: "Tricotomia local e jejum de 6 horas.", duracao: "40 min", demanda: 58 },
  { id: "cirurgia-fimose", nome: "Postectomia (cirurgia de fimose)", especialidade: "Urologia", preco: 3290, descricao: "Correção cirúrgica da fimose em adultos e adolescentes.", preparo: "Jejum de 8 horas.", duracao: "1h", demanda: 46 },
  { id: "cirurgia-hernia-inguinal", nome: "Herniorrafia inguinal", especialidade: "Cirurgia geral", preco: 5490, descricao: "Correção de hérnia inguinal com colocação de tela.", preparo: "Jejum de 8 horas e exames pré-operatórios recentes.", duracao: "1h30", demanda: 52 },
  { id: "cirurgia-hernia-umbilical", nome: "Herniorrafia umbilical", especialidade: "Cirurgia geral", preco: 4790, descricao: "Correção de hérnia umbilical em regime de hospital-dia.", preparo: "Jejum de 8 horas.", duracao: "1h20", demanda: 44 },
  { id: "cirurgia-vesicula", nome: "Colecistectomia videolaparoscópica", especialidade: "Cirurgia geral", preco: 7890, descricao: "Retirada da vesícula biliar por videolaparoscopia.", preparo: "Jejum de 8 horas e avaliação cardiológica quando indicada.", duracao: "2h", demanda: 63 },
  { id: "cirurgia-lipoma", nome: "Exérese de lipoma", especialidade: "Cirurgia geral", preco: 1290, descricao: "Retirada de lipoma com anestesia local e exame anatomopatológico.", duracao: "40 min", demanda: 39 },
  { id: "cirurgia-nodulo-pele", nome: "Exérese de nódulo ou cisto de pele", especialidade: "Dermatologia", preco: 990, descricao: "Remoção de lesão de pele com envio para análise laboratorial.", duracao: "30 min", demanda: 48 },
  { id: "cirurgia-unha-encravada", nome: "Cirurgia de unha encravada", especialidade: "Dermatologia", preco: 690, descricao: "Cantoplastia definitiva com anestesia local.", duracao: "30 min", demanda: 55 },
  { id: "cirurgia-amigdalas", nome: "Amigdalectomia", especialidade: "Otorrinolaringologia", preco: 6490, descricao: "Retirada das amígdalas em casos de infecções de repetição.", preparo: "Jejum de 8 horas e avaliação pré-anestésica.", duracao: "1h30", demanda: 43 },
  { id: "cirurgia-septoplastia", nome: "Septoplastia", especialidade: "Otorrinolaringologia", preco: 7290, descricao: "Correção do desvio de septo nasal para melhorar a respiração.", preparo: "Jejum de 8 horas e tomografia de seios da face recente.", duracao: "2h", demanda: 45 },
  { id: "cirurgia-tunel-carpo", nome: "Cirurgia de túnel do carpo", especialidade: "Ortopedia", preco: 4290, descricao: "Descompressão do nervo mediano no punho.", preparo: "Jejum de 8 horas.", duracao: "1h", demanda: 42 },
  { id: "cirurgia-artroscopia-joelho", nome: "Artroscopia de joelho", especialidade: "Ortopedia", preco: 8490, descricao: "Procedimento minimamente invasivo para tratamento de lesões de menisco.", preparo: "Jejum de 8 horas e ressonância recente.", duracao: "2h", demanda: 40 },
  { id: "cirurgia-laqueadura", nome: "Laqueadura tubária", especialidade: "Ginecologia", preco: 5990, descricao: "Procedimento definitivo de contracepção feminina por videolaparoscopia.", preparo: "Jejum de 8 horas e exames pré-operatórios.", duracao: "1h30", demanda: 47 },
];

/** Quais clínicas ofertam cada categoria (perfil de cada parceiro). */
const clinicasPorCategoria: Record<Categoria, string[]> = {
  exame_laboratorial: ["novalab", "saude-bem", "vida-plena", "aurora"],
  exame_imagem: ["saude-bem", "ipe", "vida-plena", "aurora"],
  consulta: ["vida-plena", "aurora", "saude-bem", "ipe"],
  cirurgia: ["ipe", "aurora", "vida-plena"],
};

/** Multiplicador de preço por clínica (posicionamento comercial). */
const fatorClinica: Record<string, number> = {
  novalab: 0.94,
  "saude-bem": 1,
  "vida-plena": 1.08,
  aurora: 1.15,
  ipe: 1.05,
};

const round = (value: number) =>
  value >= 1000 ? Math.round(value / 10) * 10 : Math.round(value);

function buildItems(seeds: Seed[], categoria: Categoria): CatalogItem[] {
  return seeds.map((seed) => ({
    id: seed.id,
    nome: seed.nome,
    categoria,
    ...(seed.especialidade ? { especialidade: seed.especialidade } : {}),
    descricao: seed.descricao,
    ...(seed.preparo ? { preparoNecessario: seed.preparo } : {}),
    ...(seed.duracao ? { duracao: seed.duracao } : {}),
    ...(seed.demanda >= 85 ? { destaque: true } : {}),
    demanda: seed.demanda,
    ativo: true,
  }));
}

const seedsByCategoria: Record<Categoria, Seed[]> = {
  exame_laboratorial: labSeeds,
  exame_imagem: imagemSeeds,
  consulta: consultaSeeds,
  cirurgia: cirurgiaSeeds,
};

export const catalogItems: CatalogItem[] = categoriaOrder.flatMap((categoria) =>
  buildItems(seedsByCategoria[categoria], categoria),
);

const seedById = Object.fromEntries(
  categoriaOrder.flatMap((c) => seedsByCategoria[c].map((s) => [s.id, s] as const)),
) as Record<string, Seed>;

/** Gera as ofertas: 2 a 4 clínicas por item, com preços diferentes. */
export const offerings: Offering[] = catalogItems.flatMap((item, index) => {
  const pool = clinicasPorCategoria[item.categoria];
  const quantidade = Math.min(pool.length, 2 + (index % 3));
  const seed = seedById[item.id]!;
  return Array.from({ length: quantidade }, (_, slot) => {
    const clinicaId = pool[(index + slot) % pool.length]!;
    const variacao = 1 + ((index * 7 + slot * 11) % 9) / 100;
    const preco = round(seed.preco * (fatorClinica[clinicaId] ?? 1) * variacao);
    const precoDeTabela = round(preco * (1.75 + ((index + slot) % 4) / 10));
    return {
      id: `${item.id}--${clinicaId}`,
      catalogItemId: item.id,
      clinicaId,
      preco,
      precoDeTabela,
      ...(seed.prazo ? { prazoResultado: seed.prazo } : {}),
      avaliacao: Number((4.5 + ((index + slot * 3) % 5) / 10).toFixed(1)),
      avaliacoes: 40 + ((index * 13 + slot * 29) % 320),
      ativo: true,
    } satisfies Offering;
  });
});

export const catalogItemById = Object.fromEntries(
  catalogItems.map((i) => [i.id, i]),
) as Record<string, CatalogItem>;

export const clinicaById = Object.fromEntries(
  clinicas.map((c) => [c.id, c]),
) as Record<string, Clinica>;

/** Especialidades atendidas por clínica, derivadas das ofertas ativas. */
for (const offering of offerings) {
  const clinica = clinicaById[offering.clinicaId];
  const item = catalogItemById[offering.catalogItemId];
  if (!clinica || !item?.especialidade) continue;
  if (!clinica.especialidadesAtendidas.includes(item.especialidade)) {
    clinica.especialidadesAtendidas.push(item.especialidade);
  }
}

export const offeringsByCatalogItem = (catalogItemId: string) =>
  offerings
    .filter((o) => o.ativo && o.catalogItemId === catalogItemId)
    .sort((a, b) => a.preco - b.preco);

export const activeCatalogItemsByCategoria = (categoria: Categoria) =>
  catalogItems.filter((i) => i.ativo && i.categoria === categoria);
