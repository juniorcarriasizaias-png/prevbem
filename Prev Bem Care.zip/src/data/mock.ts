/**
 * Camada de apresentação: junta CatalogItem + Offering + Clinica em um
 * "Service" plano, que é o formato consumido pelas telas.
 * A fonte da verdade é `src/data/catalog.ts`.
 */
import {
  activeCatalogItemsByCategoria,
  categoriaOrder,
  categoriaSearchPlaceholders,
  categoriaTabLabels,
  catalogItems,
  catalogItemById,
  clinicaById,
  clinicas,
  categoriaLabels,
  offerings,
  offeringsByCatalogItem,
  type Categoria,
  type CatalogItem,
  type Clinica,
  type Offering,
} from "@/data/catalog";

export {
  activeCatalogItemsByCategoria,
  categoriaOrder,
  categoriaSearchPlaceholders,
  categoriaTabLabels,
  catalogItems,
  catalogItemById,
  clinicaById,
  clinicas,
  offerings,
  offeringsByCatalogItem,
};
export type { Categoria, CatalogItem, Offering, Clinica };

/** Alias mantido para compatibilidade com as telas existentes. */
export type ServiceCategory = Categoria;

export type Clinic = Clinica & { name: string };

export type Service = {
  id: string;
  /** Oferta que originou este serviço */
  offeringId: string;
  catalogItemId: string;
  name: string;
  category: ServiceCategory;
  specialty: string;
  clinicId: string;
  /** Preço de tabela (particular, sem Prev Bem) */
  listPrice: number;
  /** Preço Prev Bem */
  price: number;
  rating: number;
  reviews: number;
  duration: string;
  /** Tempo médio de retorno do resultado (exames/procedimentos) */
  resultTime?: string;
  prep?: string;
  popular?: boolean;
  /** Quanto maior, mais procurado */
  demand: number;
  description: string;
};

export const categoryLabels = categoriaLabels;

export const clinics: Clinic[] = clinicas.map((c) => ({ ...c, name: c.nome }));

export const clinicById = Object.fromEntries(clinics.map((c) => [c.id, c])) as Record<
  string,
  Clinic
>;

export const getClinic = (service: Service): Clinic => clinicById[service.clinicId]!;

const toService = (offering: Offering, item: CatalogItem): Service => ({
  id: offering.id,
  offeringId: offering.id,
  catalogItemId: item.id,
  name: item.nome,
  category: item.categoria,
  specialty: item.especialidade ?? categoriaLabels[item.categoria],
  clinicId: offering.clinicaId,
  listPrice: offering.precoDeTabela ?? offering.preco,
  price: offering.preco,
  rating: offering.avaliacao ?? 4.8,
  reviews: offering.avaliacoes ?? 0,
  duration: item.duracao ?? "30 min",
  ...(offering.prazoResultado ? { resultTime: offering.prazoResultado } : {}),
  ...(item.preparoNecessario ? { prep: item.preparoNecessario } : {}),
  ...(item.destaque ? { popular: item.destaque } : {}),
  demand: item.demanda,
  description: item.descricao ?? "",
});

export const services: Service[] = offerings.flatMap((offering) => {
  const item = catalogItemById[offering.catalogItemId];
  if (!item || !item.ativo || !offering.ativo) return [];
  return [toService(offering, item)];
});

export const serviceById = Object.fromEntries(services.map((s) => [s.id, s])) as Record<
  string,
  Service
>;

/** Outras clínicas que ofertam o mesmo item do catálogo (comparação de preços). */
export const alternativesFor = (service: Service): Service[] =>
  services
    .filter((s) => s.catalogItemId === service.catalogItemId && s.id !== service.id)
    .sort((a, b) => a.price - b.price);

/** Menor preço disponível para um item do catálogo. */
export const bestPriceFor = (catalogItemId: string): Service | undefined =>
  services
    .filter((s) => s.catalogItemId === catalogItemId)
    .sort((a, b) => a.price - b.price)[0];

export const specialties = Array.from(
  new Set(catalogItems.map((i) => i.especialidade).filter((s): s is string => !!s)),
).sort((a, b) => a.localeCompare(b, "pt-BR"));

export const sortOptions = [
  { value: "relevancia", label: "Relevância" },
  { value: "procurados", label: "Mais procurados" },
  { value: "preco", label: "Menor preço" },
] as const;

export type SortOption = (typeof sortOptions)[number]["value"];

export const initialCart = [
  "consulta-cardiologia--aurora",
  "check-up-basico--novalab",
].filter((id) => services.some((s) => s.id === id));

export type AppointmentStatus =
  | "Confirmado"
  | "Aguardando pagamento"
  | "Concluído"
  | "Cancelado";

export type Appointment = {
  id: string;
  service: string;
  clinic: string;
  address: string;
  date: string;
  time: string;
  price: number;
  status: AppointmentStatus;
  note?: string;
};

export const upcomingAppointments: Appointment[] = [
  {
    id: "ag-1",
    service: "Consulta com Cardiologista",
    clinic: "Centro Médico Aurora",
    address: "Av. Frei Serafim, 1420 — Centro, Teresina-PI",
    date: "12/09/2026",
    time: "09:20",
    price: 180,
    status: "Confirmado",
  },
  {
    id: "ag-2",
    service: "Check-up Básico (8 exames)",
    clinic: "Laboratório NovaLab",
    address: "R. Simplício Mendes, 305 — Jóquei, Teresina-PI",
    date: "18/09/2026",
    time: "08:00",
    price: 149,
    status: "Aguardando pagamento",
    note: "Jejum de 8 horas necessário.",
  },
  {
    id: "ag-3",
    service: "Ultrassonografia de Abdômen Total",
    clinic: "Hospital Dia Ipê",
    address: "Av. Raul Lopes, 780 — Fátima, Teresina-PI",
    date: "26/09/2026",
    time: "15:40",
    price: 210,
    status: "Confirmado",
  },
];

export const pastAppointments: Appointment[] = [
  {
    id: "hist-1",
    service: "Consulta com Dermatologista",
    clinic: "Instituto Saúde Bem",
    address: "R. Coelho de Resende, 910 — Centro, Teresina-PI",
    date: "03/06/2026",
    time: "14:30",
    price: 170,
    status: "Concluído",
  },
  {
    id: "hist-2",
    service: "Hemograma Completo",
    clinic: "Laboratório NovaLab",
    address: "R. Simplício Mendes, 305 — Jóquei, Teresina-PI",
    date: "28/04/2026",
    time: "07:40",
    price: 32,
    status: "Concluído",
    note: "Resultado disponível para download.",
  },
  {
    id: "hist-3",
    service: "Raio-X de Tórax",
    clinic: "Hospital Dia Ipê",
    address: "Av. Raul Lopes, 780 — Fátima, Teresina-PI",
    date: "15/02/2026",
    time: "11:00",
    price: 95,
    status: "Cancelado",
    note: "Cancelado pelo paciente.",
  },
];

export type NotificationKind = "lembrete" | "pagamento" | "promocao" | "resultado";

export const notifications: {
  id: string;
  kind: NotificationKind;
  title: string;
  body: string;
  time: string;
  unread: boolean;
}[] = [
  {
    id: "n1",
    kind: "resultado",
    title: "Resultado de exame disponível",
    body: "Seu Hemograma Completo do Laboratório NovaLab já está pronto para download.",
    time: "há 2 horas",
    unread: true,
  },
  {
    id: "n2",
    kind: "pagamento",
    title: "Pagamento pendente do pedido PB-000123",
    body: "Combine o PIX ou cartão com a equipe pelo WhatsApp para confirmar seu check-up.",
    time: "há 6 horas",
    unread: true,
  },
  {
    id: "n3",
    kind: "lembrete",
    title: "Lembrete de preparo",
    body: "Seu Check-up Básico de 18/09 exige jejum de 8 horas.",
    time: "há 1 dia",
    unread: true,
  },
  {
    id: "n4",
    kind: "promocao",
    title: "Semana do coração: 20% off",
    body: "Consulta com Cardiologista a partir de R$ 144 nas clínicas parceiras de Teresina.",
    time: "há 3 dias",
    unread: false,
  },
  {
    id: "n5",
    kind: "lembrete",
    title: "Agendamento confirmado",
    body: "Consulta com Cardiologista confirmada no Centro Médico Aurora para 12/09 às 09:20.",
    time: "há 4 dias",
    unread: false,
  },
];


export const formatPrice = (value: number) =>
  value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
