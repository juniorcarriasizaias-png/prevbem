import type { Order, OrderStatus } from "@/context/orders";
import { getClinic, services } from "@/data/mock";
import { catalogItemById, clinicaById, offeringsByCatalogItem } from "@/data/catalog";

/** Identidade exibida em notas internas. O acesso é controlado por profiles.role no banco. */
export const ADMIN_IDENTITY = {
  name: "Equipe Prev Bem",
  role: "Atendimento",
};

const daysAgo = (days: number, hour = 10, minute = 15) => {
  const d = new Date();
  d.setDate(d.getDate() - days);
  d.setHours(hour, minute, 0, 0);
  return d.toISOString();
};

/** Monta um item de pedido a partir do catálogo (com fallback tolerante). */
const line = (id: string, qty = 1) => {
  const s = services.find((x) => x.id === id);
  if (s) {
    return { name: s.name, clinic: getClinic(s).name, clinicId: s.clinicId, unitPrice: s.price, qty };
  }
  const item = catalogItemById[id];
  const offering = offeringsByCatalogItem(id)[0];
  return {
    name: item?.nome ?? id,
    clinic: offering ? clinicaById[offering.clinicaId]?.nome ?? "Clínica parceira" : "Clínica parceira",
    ...(offering ? { clinicId: offering.clinicaId } : {}),
    unitPrice: offering?.preco ?? 0,
    qty,
  };
};


const build = (
  n: number,
  patientName: string,
  phone: string,
  items: { name: string; clinic: string; clinicId?: string; unitPrice: number; qty: number }[],
  status: OrderStatus,
  createdAt: string,
  extra?: Partial<Order>,
): Order => ({
  id: `mock-${n}`,
  number: `PB-${String(n).padStart(6, "0")}`,
  patientName,
  phone,
  forWhom: "self",
  items,
  total: items.reduce((sum, i) => sum + i.unitPrice * i.qty, 0),
  createdAt,
  status,
  ...extra,
});

/** Pedidos fictícios já existentes na operação (coerentes com o catálogo). */
export const mockOrders: Order[] = [
  build(
    112,
    "Maria Souza",
    "(86) 98888-1234",
    [line("consulta-cardiologia"), line("eletrocardiograma")],
    "Confirmado",
    daysAgo(21, 9, 40),
    {
      internalNotes: [
        { text: "PIX recebido, comprovante enviado no WhatsApp.", author: "Equipe Prev Bem", at: daysAgo(21, 10, 5) },
      ],
    },
  ),
  build(114, "João Batista Lima", "(86) 99120-4477", [line("check-up-basico")], "Concluído", daysAgo(18, 8, 5)),
  build(115, "Ana Cláudia Ferreira", "(86) 98450-9911", [line("mamografia-digital")], "Concluído", daysAgo(15, 14, 20)),
  build(
    116,
    "Rafael Mendes",
    "(86) 99631-2020",
    [line("tomografia-torax")],
    "Cancelado",
    daysAgo(12, 16, 45),
    {
      internalNotes: [
        { text: "Paciente pediu para remarcar no próximo mês.", author: "Equipe Prev Bem", at: daysAgo(12, 17, 0) },
      ],
    },
  ),
  build(
    117,
    "Luciana Portela",
    "(86) 98111-7788",
    [line("consulta-dermatologia"), line("hemograma-completo", 2)],
    "Confirmado",
    daysAgo(7, 11, 30),
  ),
  build(118, "Carlos Eduardo Nunes", "(86) 99777-3311", [line("ecocardiograma")], "Aguardando pagamento", daysAgo(3, 15, 10)),
  build(
    119,
    "Fernanda Rocha",
    "(86) 98322-6600",
    [line("ultrassom-abdominal"), line("glicemia-jejum")],
    "Aguardando pagamento",
    daysAgo(1, 9, 5),
  ),
  build(120, "Patrícia Gomes", "(86) 99555-1414", [line("consulta-pediatria")], "Confirmado", daysAgo(0, 8, 30)),
  build(121, "Marcos Vinícius Alves", "(86) 98404-2323", [line("tsh-t4-livre"), line("consulta-endocrinologia")], "Aguardando pagamento", daysAgo(0, 10, 50)),
  build(122, "Helena Cardoso", "(86) 99010-8080", [line("mapeamento-retina")], "Aguardando pagamento", daysAgo(0, 13, 25)),
  build(108, "Sandra Regina Melo", "(86) 98700-4545", [line("consulta-ginecologia"), line("ultrassom-transvaginal")], "Concluído", daysAgo(26, 10, 15)),
  build(110, "Débora Nascimento", "(86) 99233-1919", [line("cirurgia-laqueadura")], "Concluído", daysAgo(20, 15, 40)),
  build(113, "Antônio Ribeiro", "(86) 98567-3030", [line("consulta-clinico-geral"), line("raio-x-torax")], "Confirmado", daysAgo(9, 9, 20)),
  build(123, "Juliana Castro", "(86) 99401-5566", [line("consulta-clinico-geral")], "Aguardando pagamento", daysAgo(2, 14, 10)),
  build(124, "Bruno Sales", "(86) 98120-7744", [line("consulta-ginecologia")], "Confirmado", daysAgo(0, 11, 5)),
  build(125, "Vera Lúcia Matos", "(86) 99688-2211", [line("consulta-otorrino"), line("consulta-otorrino")], "Confirmado", daysAgo(4, 8, 45)),
];

export const orderStatuses: OrderStatus[] = [
  "Aguardando pagamento",
  "Confirmado",
  "Concluído",
  "Cancelado",
];
