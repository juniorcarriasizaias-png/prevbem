import { clinics } from "@/data/mock";

/**
 * Contas de acesso ao portal do parceiro (mockadas).
 * Modelo multi-clínica: cada conta está sempre vinculada a UMA clínica (clinicId),
 * e a clínica só enxerga os serviços e agendamentos dela.
 */
export type PartnerAccount = {
  email: string;
  clinicId: string;
  contactName: string;
  role: string;
};

const shortSlug = (id: string) => id.replace(/[^a-z0-9]/g, "");

export const partnerAccounts: PartnerAccount[] = clinics.map((clinic, index) => ({
  email: `${shortSlug(clinic.id)}@parceiro.prevbem.com`,
  clinicId: clinic.id,
  contactName: index === 0 ? "Recepção Vida Plena" : `Recepção ${clinic.name.split(" ").slice(-1)[0]}`,
  role: "Gestão da clínica",
}));
