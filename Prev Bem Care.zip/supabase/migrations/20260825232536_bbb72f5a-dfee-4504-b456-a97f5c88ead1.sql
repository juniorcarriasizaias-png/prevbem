DROP POLICY "site_settings_admin_insert" ON public.site_settings;
DROP POLICY "site_settings_admin_update" ON public.site_settings;

CREATE POLICY "site_settings_admin_insert" ON public.site_settings
FOR INSERT TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

CREATE POLICY "site_settings_admin_update" ON public.site_settings
FOR UPDATE TO authenticated
USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'))
WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP FUNCTION IF EXISTS public.is_admin(uuid);