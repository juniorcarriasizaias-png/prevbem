CREATE OR REPLACE FUNCTION public.is_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND role = 'admin');
$$;

REVOKE EXECUTE ON FUNCTION public.is_admin(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated, service_role;

CREATE TABLE public.site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  cor_primaria text NOT NULL DEFAULT '#5B3F8C',
  cor_destaque text NOT NULL DEFAULT '#E8650A',
  logo_url text,
  nome_site text NOT NULL DEFAULT 'Prev Bem',
  whatsapp_numero text NOT NULL DEFAULT '5586999990000',
  texto_rodape text NOT NULL DEFAULT '© 2026 Prev Bem. Todos os direitos reservados. CNPJ 00.000.000/0001-00',
  criado_em timestamptz NOT NULL DEFAULT now(),
  atualizado_em timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.site_settings TO anon;
GRANT SELECT, INSERT, UPDATE ON public.site_settings TO authenticated;
GRANT ALL ON public.site_settings TO service_role;

ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "site_settings_public_read" ON public.site_settings
FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "site_settings_admin_insert" ON public.site_settings
FOR INSERT TO authenticated WITH CHECK (public.is_admin(auth.uid()));

CREATE POLICY "site_settings_admin_update" ON public.site_settings
FOR UPDATE TO authenticated USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

CREATE OR REPLACE FUNCTION public.set_atualizado_em()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.atualizado_em = now();
  RETURN NEW;
END;
$$;

CREATE TRIGGER site_settings_set_atualizado_em
BEFORE UPDATE ON public.site_settings
FOR EACH ROW EXECUTE FUNCTION public.set_atualizado_em();

INSERT INTO public.site_settings (cor_primaria, cor_destaque, nome_site, whatsapp_numero, texto_rodape)
VALUES ('#5B3F8C', '#E8650A', 'Prev Bem', '5586999990000', '© 2026 Prev Bem. Todos os direitos reservados. CNPJ 00.000.000/0001-00');